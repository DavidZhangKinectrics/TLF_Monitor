﻿public static class glbData
{
    public static int ValueToShare;
   // public static byte[] gbyteWriteBuf= new byte[200];
   // public static byte[] gbyteReadBuf = new byte[200];
   
}