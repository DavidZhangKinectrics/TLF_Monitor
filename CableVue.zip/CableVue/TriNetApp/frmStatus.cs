﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ModbusTCP;
using System.Windows.Forms.DataVisualization.Charting;

namespace TriNet
{
    public partial class frmStatus : Form
    {
        public frmStatus()
        {
            InitializeComponent();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void tmrTaskTick_Tick(object sender, EventArgs e)
        {
            float mfTemp;

            //if (GlbByte.GbyteLoggedIn == 1)
            //   btnBackGroundCancellation.Visible = true;
            GlbByte.GbyteReadInputRegRequest = 1;

            textBox1.Text = GlbByte.giMeas1.ToString();
            //textBox2.Text = GlbByte.giMeas2.ToString();
            mfTemp = (float)GlbByte.giMeas2 / 10;
            textBox2.Text = mfTemp.ToString("F1");

            textBox3.Text = GlbByte.giComp1.ToString();
            textBox4.Text = GlbByte.giComp2.ToString();
            //textBox5.Text = GlbByte.giOffset.ToString();

            textBox6.Text = GlbByte.giGammaCnt.ToString();
            mfTemp = (float) GlbByte.gsBodyTemp / 10;
            textBox7.Text = mfTemp.ToString("F1");
            //textBox7.Text = GlbByte.gsBodyTemp.ToString();
            

            //mfTemp = (float)GlbByte.gsFilterUsage / 10;
            //textBox8.Text = mfTemp.ToString("F1");


            //mfTemp = (float)GlbByte.gsCompRH / 10;
            //textBox9.Text = mfTemp.ToString("F1");



            //mfTemp = (float)GlbByte.giMiKPa/ 1000;
            //textBox10.Text = mfTemp.ToString("F3");


            //mfTemp = (float)GlbByte.giCiKPa / 1000;
            //textBox11.Text = mfTemp.ToString("F3");


            //mfTemp = (float)GlbByte.gsDpKPa/ 1000;
            //textBox12.Text = mfTemp.ToString("F3");



        }

        private void frmStatus_Load(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {
            chart1.Visible = true;     // Gamma Raw count
            showChart(5);
        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void label23_Click(object sender, EventArgs e)
        {
            chart1.Visible = true;
            showChart(10);

        }

        private void label1_Click(object sender, EventArgs e)
        {
            chart1.Visible = true;
            showChart(1);
        }

        private void showChart(byte byteSeriesNum)
        {
            int i;
            String strSeriesName = System.String.Empty;
            int iTotalPoints;
            DateTime[] mdtData = new DateTime[86400];
            //int[] TrendData = new int[86400];
            double[] TrendData = new double[86400];

            iTotalPoints = 1;
            //        public static int giSavedDataPointer;
            //public static bool gbSavedDataFull;
            //public static DateTime[] gdtBuf = new DateTime[86400];
            //public static int[] giTritium = new int[86400];
            //public static int[] giGamma = new int[86400];
            //public static int[] giMeasCnt1 = new int[86400];

         
            chart1.Series.Clear();
            chart1.Titles.Clear();


            switch (byteSeriesNum)
            {
                case 1:
                    chart1.Titles.Add("System  Status");
                    strSeriesName = "Unsigned Short";
                    if (GlbByte.gbSavedDataFull == false)
                    {
                        for(i = 0; i < GlbByte.giSavedDataPointer; i++)
                        {
                            mdtData[i] = GlbByte.gdtBuf[i];
                            TrendData[i] = GlbByte.giMeasCnt1[i];
                        }
                        iTotalPoints = GlbByte.giSavedDataPointer;
                    }
                    else
                    {
                        for (i = GlbByte.giSavedDataPointer; i < 86400; i++)
                        {
                            mdtData[i - GlbByte.giSavedDataPointer] = GlbByte.gdtBuf[i];
                            TrendData[i- GlbByte.giSavedDataPointer] = GlbByte.giMeasCnt1[i];
                        }
                        for (i = 0; i < GlbByte.giSavedDataPointer; i++)
                        {
                            mdtData[86400 - GlbByte.giSavedDataPointer + i] = GlbByte.gdtBuf[i];
                            TrendData[86400 - GlbByte.giSavedDataPointer+i] = GlbByte.giMeasCnt1[i];
                        }
                        iTotalPoints = 86400;
                    }
                    
                    break;
                case 2:
                    chart1.Titles.Add("Current Temperature");
                    strSeriesName = "°C";
                    if (GlbByte.gbSavedDataFull == false)
                    {
                        for (i = 0; i < GlbByte.giSavedDataPointer; i++)
                        {
                            //mdtData[i] = GlbByte.gdtBuf[i];
                            //TrendData[i] = GlbByte.giMeasCnt2[i];
                            mdtData[i] = GlbByte.gdtBuf[i];
                            TrendData[i] = (double)GlbByte.giMeasCnt2[i] / 10.0;
                        }
                        iTotalPoints = GlbByte.giSavedDataPointer;
                    }
                    else
                    {
                        for (i = GlbByte.giSavedDataPointer; i < 86400; i++)
                        {
                            mdtData[i - GlbByte.giSavedDataPointer] = GlbByte.gdtBuf[i];
                            TrendData[i - GlbByte.giSavedDataPointer] = (double)GlbByte.giMeasCnt2[i]/10.0;
                        }
                        for (i = 0; i < GlbByte.giSavedDataPointer; i++)
                        {
                            mdtData[86400 - GlbByte.giSavedDataPointer + i] = GlbByte.gdtBuf[i];
                            TrendData[86400 - GlbByte.giSavedDataPointer + i] = (double)GlbByte.giMeasCnt2[i]/10.0;
                        }
                        iTotalPoints = 86400;
                    }
                    break;
                case 3:
                    chart1.Titles.Add("Fan #1 Speed");
                    strSeriesName = "RPM";
                    if (GlbByte.gbSavedDataFull == false)
                    {
                        for (i = 0; i < GlbByte.giSavedDataPointer; i++)
                        {
                            mdtData[i] = GlbByte.gdtBuf[i];
                            TrendData[i] = GlbByte.giCompCnt1[i];
                        }
                        iTotalPoints = GlbByte.giSavedDataPointer;
                    }
                    else
                    {
                        for (i = GlbByte.giSavedDataPointer; i < 86400; i++)
                        {
                            mdtData[i - GlbByte.giSavedDataPointer] = GlbByte.gdtBuf[i];
                            TrendData[i - GlbByte.giSavedDataPointer] = GlbByte.giCompCnt1[i];
                        }
                        for (i = 0; i < GlbByte.giSavedDataPointer; i++)
                        {
                            mdtData[86400 - GlbByte.giSavedDataPointer + i] = GlbByte.gdtBuf[i];
                            TrendData[86400 - GlbByte.giSavedDataPointer + i] = GlbByte.giCompCnt1[i];
                        }
                        iTotalPoints = 86400;
                    }
                    break;
                case 4:
                  
                    chart1.Titles.Add("Fan #2 Speed");
                        
                    strSeriesName = "RPM";
                    if (GlbByte.gbSavedDataFull == false)
                    {
                        for (i = 0; i < GlbByte.giSavedDataPointer; i++)
                        {
                            mdtData[i] = GlbByte.gdtBuf[i];
                            TrendData[i] = GlbByte.giCompCnt2[i];
                        }
                        iTotalPoints = GlbByte.giSavedDataPointer;
                    }
                    else
                    {
                        for (i = GlbByte.giSavedDataPointer; i < 86400; i++)
                        {
                            mdtData[i - GlbByte.giSavedDataPointer] = GlbByte.gdtBuf[i];
                            TrendData[i - GlbByte.giSavedDataPointer] = GlbByte.giCompCnt2[i];
                        }
                        for (i = 0; i < GlbByte.giSavedDataPointer; i++)
                        {
                            mdtData[86400 - GlbByte.giSavedDataPointer + i] = GlbByte.gdtBuf[i];
                            TrendData[86400 - GlbByte.giSavedDataPointer + i] = GlbByte.giCompCnt2[i];
                        }
                        iTotalPoints = 86400;
                    }
                    break;
                case 5:    // Gamma Raw Count
                    chart1.Titles.Add("Fan #3 Speed");

                    strSeriesName = "RPM";
                    if (GlbByte.gbSavedDataFull == false)
                    {
                        for (i = 0; i < GlbByte.giSavedDataPointer; i++)
                        {
                            mdtData[i] = GlbByte.gdtBuf[i];
                            TrendData[i] = GlbByte.giGMCnt[i];
                        }
                        iTotalPoints = GlbByte.giSavedDataPointer;
                    }
                    else
                    {
                        for (i = GlbByte.giSavedDataPointer; i < 86400; i++)
                        {
                            mdtData[i - GlbByte.giSavedDataPointer] = GlbByte.gdtBuf[i];
                            TrendData[i - GlbByte.giSavedDataPointer] = GlbByte.giGMCnt[i];
                        }
                        for (i = 0; i < GlbByte.giSavedDataPointer; i++)
                        {
                            mdtData[86400 - GlbByte.giSavedDataPointer + i] = GlbByte.gdtBuf[i];
                            TrendData[86400 - GlbByte.giSavedDataPointer + i] = GlbByte.giGMCnt[i];
                        }
                        iTotalPoints = 86400;
                    }
                    break;
                case 6:
                    chart1.Titles.Add("Fan Control PWM");

                    strSeriesName = "%";
                    if (GlbByte.gbSavedDataFull == false)
                    {
                        for (i = 0; i < GlbByte.giSavedDataPointer; i++)
                        {
                            mdtData[i] = GlbByte.gdtBuf[i];
                            TrendData[i] =(double)GlbByte.giBodyTmp[i]/10.0;
                        }
                        iTotalPoints = GlbByte.giSavedDataPointer;
                    }
                    else
                    {
                        for (i = GlbByte.giSavedDataPointer; i < 86400; i++)
                        {
                            mdtData[i - GlbByte.giSavedDataPointer] = GlbByte.gdtBuf[i];
                            TrendData[i - GlbByte.giSavedDataPointer] = (double)GlbByte.giBodyTmp[i] / 10.0;
                        }
                        for (i = 0; i < GlbByte.giSavedDataPointer; i++)
                        {
                            mdtData[86400 - GlbByte.giSavedDataPointer + i] = GlbByte.gdtBuf[i];
                            TrendData[86400 - GlbByte.giSavedDataPointer + i] = (double)GlbByte.giBodyTmp[i] / 10.0;
                        }
                        iTotalPoints = 86400;
                    }
                    break;
                case 7:
                    chart1.Titles.Add("Compensation Chamber Humidity %RH");

                    strSeriesName = "%RH";
                    if (GlbByte.gbSavedDataFull == false)
                    {
                        for (i = 0; i < GlbByte.giSavedDataPointer; i++)
                        {
                            mdtData[i] = GlbByte.gdtBuf[i];
                            TrendData[i] = (double)GlbByte.giCmpRH[i] / 10.0;
                        }
                        iTotalPoints = GlbByte.giSavedDataPointer;
                    }
                    else
                    {
                        for (i = GlbByte.giSavedDataPointer; i < 86400; i++)
                        {
                            mdtData[i - GlbByte.giSavedDataPointer] = GlbByte.gdtBuf[i];
                            TrendData[i - GlbByte.giSavedDataPointer] = (double)GlbByte.giCmpRH[i] / 10.0;
                        }
                        for (i = 0; i < GlbByte.giSavedDataPointer; i++)
                        {
                            mdtData[86400 - GlbByte.giSavedDataPointer + i] = GlbByte.gdtBuf[i];
                            TrendData[86400 - GlbByte.giSavedDataPointer + i] = (double)GlbByte.giCmpRH[i] / 10.0;
                        }
                        iTotalPoints = 86400;
                    }
                    break;
                case 8:
                    chart1.Titles.Add("Measuring Chamber Pressure KPa");

                    strSeriesName = "KPa";
                    if (GlbByte.gbSavedDataFull == false)
                    {
                        for (i = 0; i < GlbByte.giSavedDataPointer; i++)
                        {
                            mdtData[i] = GlbByte.gdtBuf[i];
                            TrendData[i] = (double)GlbByte.giMiPre[i]/ 1000.0;
                        }
                        iTotalPoints = GlbByte.giSavedDataPointer;
                    }
                    else
                    {
                        for (i = GlbByte.giSavedDataPointer; i < 86400; i++)
                        {
                            mdtData[i - GlbByte.giSavedDataPointer] = GlbByte.gdtBuf[i];
                            TrendData[i - GlbByte.giSavedDataPointer] = (double)GlbByte.giMiPre[i] / 1000.0;
                        }
                        for (i = 0; i < GlbByte.giSavedDataPointer; i++)
                        {
                            mdtData[86400 - GlbByte.giSavedDataPointer + i] = GlbByte.gdtBuf[i];
                            TrendData[86400 - GlbByte.giSavedDataPointer + i] = (double)GlbByte.giMiPre[i] / 1000.0;
                        }
                        iTotalPoints = 86400;
                    }
                    break;

                case 9:
                    chart1.Titles.Add("Compensation Chamber Pressure KPa");

                    strSeriesName = "KPa";
                    if (GlbByte.gbSavedDataFull == false)
                    {
                        for (i = 0; i < GlbByte.giSavedDataPointer; i++)
                        {
                            mdtData[i] = GlbByte.gdtBuf[i];
                            TrendData[i] = (double)GlbByte.giCiPre[i]/1000.0;
                        }
                        iTotalPoints = GlbByte.giSavedDataPointer;
                    }
                    else
                    {
                        for (i = GlbByte.giSavedDataPointer; i < 86400; i++)
                        {
                            mdtData[i - GlbByte.giSavedDataPointer] = GlbByte.gdtBuf[i];
                            TrendData[i - GlbByte.giSavedDataPointer] = (double)GlbByte.giCiPre[i] / 1000.0;
                        }
                        for (i = 0; i < GlbByte.giSavedDataPointer; i++)
                        {
                            mdtData[86400 - GlbByte.giSavedDataPointer + i] = GlbByte.gdtBuf[i];
                            TrendData[86400 - GlbByte.giSavedDataPointer + i] = (double)GlbByte.giCiPre[i] / 1000.0;
                        }
                        iTotalPoints = 86400;
                    }
                    break;
                case 10:
                    chart1.Titles.Add("Differential Pressure KPa");

                    strSeriesName = "KPa";
                    if (GlbByte.gbSavedDataFull == false)
                    {
                        for (i = 0; i < GlbByte.giSavedDataPointer; i++)
                        {
                            mdtData[i] = GlbByte.gdtBuf[i];
                            TrendData[i] = (double)GlbByte.giDpPre[i]/1000.0;
                        }
                        iTotalPoints = GlbByte.giSavedDataPointer;
                    }
                    else
                    {
                        for (i = GlbByte.giSavedDataPointer; i < 86400; i++)
                        {
                            mdtData[i - GlbByte.giSavedDataPointer] = GlbByte.gdtBuf[i];
                            TrendData[i - GlbByte.giSavedDataPointer] = (double)GlbByte.giDpPre[i] / 1000.0;
                        }
                        for (i = 0; i < GlbByte.giSavedDataPointer; i++)
                        {
                            mdtData[86400 - GlbByte.giSavedDataPointer + i] = GlbByte.gdtBuf[i];
                            TrendData[86400 - GlbByte.giSavedDataPointer + i] = (double)GlbByte.giDpPre[i] / 1000.0;
                        }
                        iTotalPoints = 86400;
                    }
                    break;
                case 11:
                    chart1.Titles.Add("Flow Rate L/M");

                    strSeriesName = "L/M";
                    if (GlbByte.gbSavedDataFull == false)
                    {
                        for (i = 0; i < GlbByte.giSavedDataPointer; i++)
                        {
                            mdtData[i] = GlbByte.gdtBuf[i];
                            TrendData[i] = (double)GlbByte.giFlowRate[i] / 10.0;
                        }
                        iTotalPoints = GlbByte.giSavedDataPointer;
                    }
                    else
                    {
                        for (i = GlbByte.giSavedDataPointer; i < 86400; i++)
                        {
                            mdtData[i - GlbByte.giSavedDataPointer] = GlbByte.gdtBuf[i];
                            TrendData[i - GlbByte.giSavedDataPointer] = (double)GlbByte.giFlowRate[i] / 10.0;
                        }
                        for (i = 0; i < GlbByte.giSavedDataPointer; i++)
                        {
                            mdtData[86400 - GlbByte.giSavedDataPointer + i] = GlbByte.gdtBuf[i];
                            TrendData[86400 - GlbByte.giSavedDataPointer + i] = (double)GlbByte.giFlowRate[i] / 10.0;
                        }
                        iTotalPoints = 86400;
                    }
                    break;
            }


            //chart1.ChartAreas[0].BackColor = Color.Black;
            //chart1.ChartAreas[0].AxisX.MajorGrid.LineColor = Color.DarkGreen;//Color.LawnGreen;
            //chart1.ChartAreas[0].AxisY.MajorGrid.LineColor = Color.DarkGreen; //Color.Gray;//Color.LawnGreen;


            chart1.ChartAreas[0].CursorX.IsUserEnabled = true;
            chart1.ChartAreas[0].CursorX.IsUserSelectionEnabled = true;
            chart1.ChartAreas[0].CursorY.IsUserEnabled = true;
            chart1.ChartAreas[0].CursorY.IsUserSelectionEnabled = true;

            chart1.ChartAreas[0].CursorX.Interval = 0;
            chart1.ChartAreas[0].CursorY.Interval = 0;
            chart1.ChartAreas[0].AxisX.ScaleView.Zoomable = true;
            chart1.ChartAreas[0].AxisY.ScaleView.Zoomable = true;

            chart1.ChartAreas[0].CursorX.LineColor = Color.Brown; //Color.MediumTurquoise;//Color.Black;
            chart1.ChartAreas[0].CursorX.LineWidth = 1;
            chart1.ChartAreas[0].CursorX.LineDashStyle = ChartDashStyle.Dot;
       
            chart1.ChartAreas[0].CursorX.Interval = 10 / 86400;// 0.0002;// 1000/86400;// 100 seconds, the format of date is x.yyyyy x is the day number from 1900;


            chart1.ChartAreas[0].CursorY.LineColor = Color.Brown; //Color.LightGray; // Color.MediumTurquoise;
            chart1.ChartAreas[0].CursorY.LineWidth = 1;
            chart1.ChartAreas[0].CursorY.LineDashStyle = ChartDashStyle.Dot;
            chart1.ChartAreas[0].CursorY.Interval = 2;// 0;


            chart1.ChartAreas[0].AxisX.ScrollBar.Enabled = true;
            // Set scrollbar size
            chart1.ChartAreas[0].AxisX.ScrollBar.Size = 20;
            chart1.ChartAreas[0].AxisY.ScrollBar.Size = 20;

            // Show small scroll buttons only          
            // chart1.ChartAreas[0].AxisX.ScrollBar.ButtonStyle = ScrollBarButtonStyles.SmallScroll;
            // Scrollbars position
            chart1.ChartAreas[0].AxisX.ScrollBar.IsPositionedInside = true;


            //chart1.ChartAreas[0].CursorX.IsUserEnabled = true;
            //chart1.ChartAreas[0].CursorX.IsUserSelectionEnabled = true;
            //chart1.ChartAreas[0].CursorY.IsUserEnabled = true;
            //chart1.ChartAreas[0].CursorY.IsUserSelectionEnabled = true;

            //chart1.ChartAreas[0].CursorX.Interval = 0;
            //chart1.ChartAreas[0].CursorY.Interval = 0;
            //chart1.ChartAreas[0].AxisX.ScaleView.Zoomable = true;
            //chart1.ChartAreas[0].AxisY.ScaleView.Zoomable = true;

            //chart1.ChartAreas[0].CursorX.LineColor = Color.Black;
            //chart1.ChartAreas[0].CursorX.LineWidth = 1;
            //chart1.ChartAreas[0].CursorX.LineDashStyle = ChartDashStyle.Dot;
            //chart1.ChartAreas[0].CursorX.Interval = 0;
            //chart1.ChartAreas[0].CursorY.LineColor = Color.Black;
            //chart1.ChartAreas[0].CursorY.LineWidth = 1;
            //chart1.ChartAreas[0].CursorY.LineDashStyle = ChartDashStyle.Dot;
            //chart1.ChartAreas[0].CursorY.Interval = 0;


            //chart1.ChartAreas[0].AxisX.ScrollBar.Enabled = true;
            //// Set scrollbar size
            //chart1.ChartAreas[0].AxisX.ScrollBar.Size = 20;
            //chart1.ChartAreas[0].AxisY.ScrollBar.Size = 20;

            //// Show small scroll buttons only          
            //// chart1.ChartAreas[0].AxisX.ScrollBar.ButtonStyle = ScrollBarButtonStyles.SmallScroll;
            //// Scrollbars position
            //chart1.ChartAreas[0].AxisX.ScrollBar.IsPositionedInside = true;

            // Change scrollbar colors
            chart1.ChartAreas[0].AxisX.ScrollBar.BackColor = Color.LightGray;
            chart1.ChartAreas[0].AxisX.ScrollBar.ButtonColor = Color.Gray;
            chart1.ChartAreas[0].AxisX.ScrollBar.LineColor = Color.Black;




            //chart1.Titles[0].Font = new System.Drawing.Font("Arial", 14, FontStyle.Bold);
            chart1.ChartAreas[0].AxisX.LabelStyle.Format = "yyyy-MM-dd HH:mm:ss";
            /*
            chart1.ChartAreas[0].AxisX.ScrollBar.Enabled = true;
            // Set scrollbar size
            chart1.ChartAreas[0].AxisX.ScrollBar.Size = 20;
            chart1.ChartAreas[0].AxisY.ScrollBar.Size = 20;

            // Show small scroll buttons only          
            // chart1.ChartAreas[0].AxisX.ScrollBar.ButtonStyle = ScrollBarButtonStyles.SmallScroll;
            // Scrollbars position
            chart1.ChartAreas[0].AxisX.ScrollBar.IsPositionedInside = true;

            // Change scrollbar colors
            chart1.ChartAreas[0].AxisX.ScrollBar.BackColor = Color.LightGray;
            chart1.ChartAreas[0].AxisX.ScrollBar.ButtonColor = Color.Red; //color.Gray;
            chart1.ChartAreas[0].AxisX.ScrollBar.LineColor = Color.Black;

            chart1.Titles[0].Font = new System.Drawing.Font("Arial", 14, FontStyle.Bold);
            chart1.ChartAreas[0].AxisX.LabelStyle.Format = "yyyy-MM-dd HH:mm:ss";

            // Create cursor object
            System.Windows.Forms.DataVisualization.Charting.Cursor cursor = null;

            // Set cursor object
            cursor = chart1.ChartAreas[0].CursorY;

            // Set cursor properties 
            cursor.LineWidth = 10;//2;
            cursor.LineDashStyle = ChartDashStyle.DashDot;
            cursor.LineColor = Color.Red;
            cursor.SelectionColor = Color.Yellow;
            //cursor.IsUserEnabled = true;
            cursor.IsUserSelectionEnabled = true;


            chart1.ChartAreas[0].AxisX.ScaleView.SizeType = DateTimeIntervalType.Seconds; ;
            chart1.ChartAreas[0].AxisX.ScaleView.SmallScrollMinSizeType = DateTimeIntervalType.Seconds;
            chart1.ChartAreas[0].AxisX.ScaleView.SmallScrollMinSize = 1;

            // Set cursor selection color of X axis cursor
            chart1.ChartAreas[0].CursorX.SelectionColor = Color.Yellow;
            // chart1.ChartAreas[0].CursorX.IsUserEnabled = true;
            chart1.ChartAreas[0].CursorX.IsUserSelectionEnabled = true;
            */
            Series series1 = chart1.Series.Add(strSeriesName);
            series1.ChartType = SeriesChartType.Line;//SeriesChartType.Spline;
            series1.BorderWidth = 3;
            series1.Color = Color.Blue;
            
            //series1.Font = new System.Drawing.Font("Arial", 14, FontStyle.Bold);
            for (i = 0; i < iTotalPoints; i++)
            {
                series1.Points.AddXY(mdtData[i], TrendData[i]);

            }
            
        }



       
        private void label2_Click(object sender, EventArgs e)
        {
            chart1.Visible = true;
            showChart(2);
        }

        private void chart1_DoubleClick(object sender, EventArgs e)
        {
            chart1.Visible = false;
        }

        private void label3_Click(object sender, EventArgs e)
        {
            chart1.Visible = true;
            showChart(3);

        }

        private void label4_Click(object sender, EventArgs e)
        {
            chart1.Visible = true;
            showChart(4);

        }

        

        private void label13_Click(object sender, EventArgs e)
        {
            chart1.Visible = true;
            showChart(6);

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void label17_Click(object sender, EventArgs e)
        {
            chart1.Visible = true;
            showChart(7);
        }

        private void label19_Click(object sender, EventArgs e)
        {
            chart1.Visible = true;
            showChart(8);

        }

        private void label21_Click(object sender, EventArgs e)
        {
            chart1.Visible = true;
            showChart(9);
        }

        private void label26_Click(object sender, EventArgs e)
        {
           
        }

        private void label25_Click(object sender, EventArgs e)
        {
            chart1.Visible = true;
            showChart(11);
        }

        private void label28_Click(object sender, EventArgs e)
        {

        }

        private void btnBackGroundCancellation_Click(object sender, EventArgs e)
        {

        }

        private void btnBackGroundCancellation_MouseDown(object sender, MouseEventArgs e)
        {
            //GlbByte.GbyteWriteBuf[0] = 0x55;
            //GlbByte.GbyteWriteBuf[1] |= 0x40;  // request for background cancellation
            //GlbByte.GbyteWriteBuf[2] = 1;
            //GlbByte.GbyteWriteBuf[3] = 0;
            //GlbByte.GbyteWriteBuf[4] = 0;
            //GlbByte.GbyteWriteBuf[5] = 1;

            //GlbByte.GbyteWriteBuf[6] = 0;
            //GlbByte.GbyteWriteBuf[7] = 2;

            //GlbByte.GbyteWriteBuf[8] = 0;
            //GlbByte.GbyteWriteBuf[9] = 3;

         

            GlbByte.gByteTCPWriteReq = 1;
            GlbByte.gByteTCPWriteReq_InBackGroundCancellation = 1;
        }

        private void btnBackGroundCancellation_MouseUp(object sender, MouseEventArgs e)
        {
            //GlbByte.GbyteWriteBuf[0] = 0x55;
            //GlbByte.GbyteWriteBuf[1] &= 0xbF;  // request for background cancellation           
            //GlbByte.gByteTCPWriteReq = 1;
            //tmrBackGroundCancellationDelayOff.Enabled = true;

        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void tmrBackGroundCancellationDelayOff_Tick(object sender, EventArgs e)
        {
            GlbByte.gByteTCPWriteReq_InBackGroundCancellation = 0;
            tmrBackGroundCancellationDelayOff.Enabled = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void frmStatus_FormClosing(object sender, FormClosingEventArgs e)
        {
            GlbByte.giFormStatusOpened = 0;
        }
    }
    
}
