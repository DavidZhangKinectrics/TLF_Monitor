﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ModbusTCP;
using TriNet;
using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Explicit)]
struct IntByte_array
{
    [FieldOffset(0)]
    public byte byte1;
    [FieldOffset(1)]
    public byte byte2;
    [FieldOffset(2)]
    public byte byte3;
    [FieldOffset(3)]
    public byte byte4;
    [FieldOffset(0)]
    public int iIntData;
}

namespace TriNet
{
    public partial class frmInstrumentSetup : Form
    {

        //private ModbusTCP.Master MBmaster;
        private bool pbLoggedIn;
        private int piSelectedItemIndex;
        private int piPreSelectedItemIndex;
        private IntByte_array UnionInt;

        private int iTextBoxSelectedIndex;

        public frmInstrumentSetup()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lblTemperatureSet_Click(object sender, EventArgs e)
        {

        }

        private void frmInstrumentSetup_Load(object sender, EventArgs e)
        {
            int i,j;
            pbLoggedIn = true;// false;
            piSelectedItemIndex = 0;
            iTextBoxSelectedIndex = 0;
            for (i = 0; i < 54; i++)
                GlbByte.GbyteWriteBuf[i] = 0;
            /*
            textBox2.Text = GlbByte.giLocationTimmingArry[0].ToString();
            textBox3.Text = GlbByte.giLocationTimmingArry[1].ToString();
            textBox4.Text = GlbByte.giLocationTimmingArry[2].ToString();
            textBox5.Text = GlbByte.giLocationTimmingArry[3].ToString();
            textBox6.Text = GlbByte.giLocationTimmingArry[4].ToString();
            */
            dgrdHoldingRegTable.RowCount = 28;
            dgrdHoldingRegTable.ColumnCount = 3;
            dgrdHoldingRegTable.Columns[0].Width = 100;
            dgrdHoldingRegTable.Columns[0].Name= "Address";
            dgrdHoldingRegTable.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgrdHoldingRegTable.Columns[0].ReadOnly = true;
            dgrdHoldingRegTable.Columns[1].Width = 100;
            dgrdHoldingRegTable.Columns[1].Name = "Value";
            dgrdHoldingRegTable.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgrdHoldingRegTable.Columns[2].Width = 950;
            dgrdHoldingRegTable.Columns[2].Name = "Description";
            dgrdHoldingRegTable.Columns[2].ReadOnly = true;
            foreach (DataGridViewColumn Col in dgrdHoldingRegTable.Columns)
                Col.SortMode = DataGridViewColumnSortMode.NotSortable;
            for(j = 0; j < 28; j++)
            {
                dgrdHoldingRegTable.Rows[j].Cells[0].Value = 40001 + j;
                dgrdHoldingRegTable.Rows[j].Cells[1].Value = 0;
            }
            dgrdHoldingRegTable.Rows[0].Cells[2].Value = "Enable Device's Power - Bit 0: RF Relay, Bit 1: IDA, Bit 2: Oscillascope";
            dgrdHoldingRegTable.Rows[1].Cells[2].Value = "Temperature Setting in unit of 0.1 C: value of 351 will set to 35.1C";
            dgrdHoldingRegTable.Rows[2].Cells[2].Value = "IDA Relay Trigger: Bit 0: UST,Bit 1 GST, will be reset to 0 after 50mS by Firmware";
            dgrdHoldingRegTable.Rows[3].Cells[2].Value = "Fan Control mode : 0 Auto by PID loop, 1 Manual by PWM setting    ";
            dgrdHoldingRegTable.Rows[4].Cells[2].Value = "Fan Control Spare parameter : 0 as default - Not Used ";
            dgrdHoldingRegTable.Rows[5].Cells[2].Value = "Fan Control PWM setting : in unit of percentage, set to 50 to set PWM 50%";
            dgrdHoldingRegTable.Rows[6].Cells[2].Value = "Power LED  Conrol Mode: 0 OFF, 1 ON, 2 Pulse Mode ";
            dgrdHoldingRegTable.Rows[7].Cells[2].Value = "Power LED Pulse Period : In Unit of mS, 1000 will set to 1000mS ";
            dgrdHoldingRegTable.Rows[8].Cells[2].Value = "Power LED Pulse On Duty: in unit of percentage, set to 50 to set ON for 50%";
            dgrdHoldingRegTable.Rows[9].Cells[2].Value = "LFDS_PDC LED  Conrol Mode: 0 OFF, 1 ON, 2 Pulse Mode ";
            dgrdHoldingRegTable.Rows[10].Cells[2].Value = "LFDS_PDC LED Pulse Period : In Unit of mS, 1000 will set to 1000mS ";
            dgrdHoldingRegTable.Rows[11].Cells[2].Value = "LFDS_PDC LED Pulse On Duty: in unit of percentage, set to 50 to set ON for 50%";
            dgrdHoldingRegTable.Rows[12].Cells[2].Value = "TDR_FDR LED  Conrol Mode: 0 OFF, 1 ON, 2 Pulse Mode ";
            dgrdHoldingRegTable.Rows[13].Cells[2].Value = "TDR_FDR LED Pulse Period : In Unit of mS, 1000 will set to 1000mS ";
            dgrdHoldingRegTable.Rows[14].Cells[2].Value = "TDR_FDR LED Pulse On Duty: in unit of percentage, set to 50 to set ON for 50%";
            dgrdHoldingRegTable.Rows[15].Cells[2].Value = "ERROR LED  Conrol Mode: 0 OFF, 1 ON, 2 Pulse Mode ";
            dgrdHoldingRegTable.Rows[16].Cells[2].Value = "ERROR LED Pulse Period : In Unit of mS, 1000 will set to 1000mS ";
            dgrdHoldingRegTable.Rows[17].Cells[2].Value = "ERROR LED Pulse On Duty: in unit of percentage, set to 50 to set ON for 50%";
            dgrdHoldingRegTable.Rows[18].Cells[2].Value = "Beeper  Conrol Mode: 0 OFF, 1 ON, 2 Pulse Mode ";
            dgrdHoldingRegTable.Rows[19].Cells[2].Value = "Beeper Pulse Period : In Unit of mS, 1000 will set to 1000mS ";
            dgrdHoldingRegTable.Rows[20].Cells[2].Value = "Beeper Pulse On Duty: in unit of percentage, set to 50 to set ON for 50%";
            dgrdHoldingRegTable.Rows[21].Cells[2].Value = "Modbus Node Address (Retained): 0 -247, 0 is broadcast node for reseting Node address when forget";
            dgrdHoldingRegTable.Rows[21].DefaultCellStyle.BackColor = Color.Yellow;
            dgrdHoldingRegTable.Rows[22].Cells[2].Value = "Fan PID Kp (Retained):In Unit of 0.001, set 500 will set Kp to 0.5";
            dgrdHoldingRegTable.Rows[22].DefaultCellStyle.BackColor = Color.Yellow;
            dgrdHoldingRegTable.Rows[23].Cells[2].Value = "Fan PID Ki (Retained):In Unit of 0.001, set 100 will set Ki to 0.1";
            dgrdHoldingRegTable.Rows[23].DefaultCellStyle.BackColor = Color.Yellow;
            dgrdHoldingRegTable.Rows[24].Cells[2].Value = "Fan PID Kd (Retained):In Unit of 0.001, set 10 will set Kd to 0.01";
            dgrdHoldingRegTable.Rows[24].DefaultCellStyle.BackColor = Color.Yellow;
            dgrdHoldingRegTable.Rows[25].Cells[2].Value = "Fan PID Preload (Retained):In Unit of 0.1%, set 300 will set Preload to 30.0%";
            dgrdHoldingRegTable.Rows[25].DefaultCellStyle.BackColor = Color.Yellow;
            dgrdHoldingRegTable.Rows[26].Cells[2].Value = "Fan PID Low Limit (Retained):In Unit of 0.1%, set 1 will set Low limit to 0.1%";
            dgrdHoldingRegTable.Rows[26].DefaultCellStyle.BackColor = Color.Yellow;
            dgrdHoldingRegTable.Rows[27].Cells[2].Value = "Fan PID High Limit (Retained):In Unit of 0.1%, set 900 will set High Limit to 90%";
            dgrdHoldingRegTable.Rows[27].DefaultCellStyle.BackColor = Color.Yellow;

            ReadHoldingRegs();

        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            
            int i, j;
            double dblTemp;
            DateTime dtTemp;
            try
            {
                if (pbLoggedIn == false)
                {
                    if (GlbByte.giPassword == Int32.Parse(txtBoxInput.Text))
                    {
                        pbLoggedIn = true;
                        GlbByte.GbyteLoggedIn = 1;
                        piSelectedItemIndex = 1;
                        piPreSelectedItemIndex = piSelectedItemIndex;
                        lblLocation.BackColor = Color.Turquoise;
                        //panel1.Visible = true;
                        lblRequest.Text = "Enter Instrument Unit ID:";
                        lblRequest.BackColor = Color.LightGray;
                        lblHelpInfo.Text = "Range from 0 to 255";
                        txtBoxInput.Text = "";
                        //button2.Visible = true;
                        //button3.Visible = true;

                    }
                    else
                    {
                        MessageBox.Show("Incorrect Password!");
                    }
                }
                else
                {   /*
                    switch (piSelectedItemIndex)
                    {
                        case 1:    // Location
                            if (txtBoxInput.Text != "")
                            {
                                //i = Int32.Parse(txtBoxInput.Text);
                                //if (i < 0)
                                //    i = 0;
                                //if (i > 255)
                                //    i = 255;


                                //j = Int32.Parse(textBox2.Text);
                                //if (j < 0)
                                //    j = 0;
                                //if (j > 60000)
                                //    j = 60000;
                                //GlbByte.giLocationTimmingArry[0] = j;

                                //j = Int32.Parse(textBox3.Text);
                                //if (j < 0)
                                //    j = 0;
                                //if (j > 60000)
                                //    j = 60000;
                                //GlbByte.giLocationTimmingArry[1] = j;

                                //j = Int32.Parse(textBox4.Text);
                                //if (j < 0)
                                //    j = 0;
                                //if (j > 60000)
                                //    j = 60000;
                                //GlbByte.giLocationTimmingArry[2] = j;

                                //j = Int32.Parse(textBox5.Text);
                                //if (j < 0)
                                //    j = 0;
                                //if (j > 60000)
                                //    j = 60000;
                                //GlbByte.giLocationTimmingArry[3] = j;

                                //j = Int32.Parse(textBox6.Text);
                                //if (j < 0)
                                //    j = 0;
                                //if (j > 60000)
                                //    j = 60000;
                                //GlbByte.giLocationTimmingArry[4] = j;


                                //GlbByte.giLocationSelect = i;

                                //writeLinesToFile();
                                //GlbByte.GbyteWriteBuf[0] = 0x55;
                                //GlbByte.GbyteWriteBuf[1] |= 0x20;  // request for change Location
                                //GlbByte.GbyteWriteBuf[13] = 0;
                                //GlbByte.GbyteWriteBuf[14] = 0;
                                //GlbByte.GbyteWriteBuf[15] = 0;
                                //GlbByte.GbyteWriteBuf[16] = (byte)i;


                                //j = GlbByte.giLocationTimmingArry[0];
                                //i = j / 256;
                                //j = j % 256;
                                //GlbByte.GbyteWriteBuf[41] = (byte)i;
                                //GlbByte.GbyteWriteBuf[42] = (byte)j;

                                //j = GlbByte.giLocationTimmingArry[1];
                                //i = j / 256;
                                //j = j % 256;
                                //GlbByte.GbyteWriteBuf[43] = (byte)i;
                                //GlbByte.GbyteWriteBuf[44] = (byte)j;

                                //j = GlbByte.giLocationTimmingArry[2];
                                //i = j / 256;
                                //j = j % 256;
                                //GlbByte.GbyteWriteBuf[45] = (byte)i;
                                //GlbByte.GbyteWriteBuf[46] = (byte)j;

                                //j = GlbByte.giLocationTimmingArry[3];
                                //i = j / 256;
                                //j = j % 256;
                                //GlbByte.GbyteWriteBuf[47] = (byte)i;
                                //GlbByte.GbyteWriteBuf[48] = (byte)j;

                                //j = GlbByte.giLocationTimmingArry[4];
                                //i = j / 256;
                                //j = j % 256;
                                //GlbByte.GbyteWriteBuf[49] = (byte)i;
                                //GlbByte.GbyteWriteBuf[50] = (byte)j;
                                i = Int32.Parse(textBox7.Text);
                                i = i - 40001;
                                if (i < 0)
                                    i = 0;
                                if (i > 28)
                                    i = 28;                              
                                GlbByte.gsModbusStartReg = (short)i;

                                i = Int32.Parse(textBox8.Text);                                
                                if (i < 0)
                                    i = 1;
                                if (i > 28)
                                    i = 28;
                                GlbByte.gsModbusNumberReg = (short)i;

                                GlbByte.gByteTCPWriteReq = 1;


                               
                            }
                            break;

                        case 2:  // Tritium Alarm
                            if (txtBoxInput.Text != "")
                            {
                                //i = Int32.Parse(txtBoxInput.Text);
                                //if (i < 0)
                                //    i = 0;
                                //if (i > 1000000)
                                //    i = 1000000;

                                //textBox1.Text = iTextBoxSelectedIndex.ToString();
                                //dblTemp = (double)GlbByte.giTritiumAlarmSetting * GlbByte.gdblEngUnitFactor[GlbByte.giEngineeringUnitSelected];
                                dblTemp = Double.Parse(txtBoxInput.Text);
                                if (dblTemp < 0.0)
                                    dblTemp = 0.0;
                                i = (int)(dblTemp / GlbByte.gdblEngUnitFactor[GlbByte.giEngineeringUnitSelected]) +1;

                                GlbByte.GbyteWriteBuf[0] = 0x55;
                                GlbByte.GbyteWriteBuf[1] |= 0x10;  // request for change Tritium Alarm

                                UnionInt.iIntData = i;
                                GlbByte.GbyteWriteBuf[17] = UnionInt.byte4;
                                GlbByte.GbyteWriteBuf[18] = UnionInt.byte3;
                                GlbByte.GbyteWriteBuf[19] = UnionInt.byte2;
                                GlbByte.GbyteWriteBuf[20] = UnionInt.byte1;
                                GlbByte.gByteTCPWriteReq = 1;
                            }
                            break;
                        case 3:  // Tritium Gain
                            if (txtBoxInput.Text != "")
                            {
                                //i = Int32.Parse(txtBoxInput.Text);
                                dblTemp = Double.Parse(txtBoxInput.Text);
                                if (dblTemp < 0.100)
                                    dblTemp = 0.100;
                                if (dblTemp > 9.999)
                                    dblTemp = 9.999;

                                i = (int)(dblTemp * 1000);
                                GlbByte.GbyteWriteBuf[0] = 0x55;
                                GlbByte.GbyteWriteBuf[1] |= 0x04;  // request for change Tritium Gain

                                UnionInt.iIntData = i;
                                GlbByte.GbyteWriteBuf[25] = UnionInt.byte4;
                                GlbByte.GbyteWriteBuf[26] = UnionInt.byte3;
                                GlbByte.GbyteWriteBuf[27] = UnionInt.byte2;
                                GlbByte.GbyteWriteBuf[28] = UnionInt.byte1;
                                GlbByte.gByteTCPWriteReq = 1;
                            }
                            break;

                        case 4:  // Date and Time
                            dtTemp = DateTime.Now;
                            dtTemp = dtTemp.AddSeconds(1);
                            GlbByte.GbyteWriteBuf[0] = 0x55;
                            GlbByte.GbyteWriteBuf[1] |= 0x80;  // request for change Date Time
                            i = dtTemp.Year;
                            if ((i < 2059) && (i > 2010))
                            {
                                i = i - 2000;
                                GlbByte.GbyteWriteBuf[3] = (byte)i;

                                i = dtTemp.Month;
                                GlbByte.GbyteWriteBuf[4] = (byte)i;

                                i = dtTemp.Day;
                                GlbByte.GbyteWriteBuf[5] = (byte)i;

                                i = dtTemp.Hour;
                                GlbByte.GbyteWriteBuf[6] = (byte)i;

                                i = dtTemp.Minute;
                                GlbByte.GbyteWriteBuf[7] = (byte)i;

                                i = dtTemp.Second;
                                GlbByte.GbyteWriteBuf[8] = (byte)i;

                                GlbByte.gByteTCPWriteReq = 1;
                            }
                            break;
                        case 5:  // Flow calibration
                            if (txtBoxInput.Text != "")
                            {
                                //i = Int32.Parse(txtBoxInput.Text);
                                dblTemp = Double.Parse(txtBoxInput.Text);
                                if ((dblTemp > 1.0) && (dblTemp > 30.0))
                                {
                                    i = (int)(dblTemp * 10);
                                    GlbByte.GbyteWriteBuf[0] = 0x55;
                                    GlbByte.GbyteWriteBuf[1] |= 0x00;  // request for change Tritium Gain
                                    GlbByte.GbyteWriteBuf[2] |= 0x80;  // request for change Tritium Gain

                                    UnionInt.iIntData = i;
                                    GlbByte.GbyteWriteBuf[33] = UnionInt.byte4;
                                    GlbByte.GbyteWriteBuf[34] = UnionInt.byte3;
                                    GlbByte.GbyteWriteBuf[35] = UnionInt.byte2;
                                    GlbByte.GbyteWriteBuf[36] = UnionInt.byte1;
                                    GlbByte.gByteTCPWriteReq = 1;

                                }

                            }
                            break;
                        case 6:  // Log interval
                            if (txtBoxInput.Text != "")
                            {
                                //i = Int32.Parse(txtBoxInput.Text);
                                //if (i < 0)
                                //    i = 1;
                                //if (i > 3600)
                                //    i = 3600;

                                dblTemp = Double.Parse(txtBoxInput.Text);
                                if (dblTemp < 0.0)
                                    dblTemp = 0.0;
                                i = (int)(dblTemp / GlbByte.gdblEngUnitFactor[GlbByte.giEngineeringUnitSelected])+1;


                                GlbByte.GbyteWriteBuf[0] = 0x55;
                                GlbByte.GbyteWriteBuf[1] |= 0x00;
                                GlbByte.GbyteWriteBuf[2] |= 0x20;

                                j = i / 256;
                                GlbByte.GbyteWriteBuf[41] = (byte)j;
                                j = i % 256;
                                GlbByte.GbyteWriteBuf[42] = (byte)j;

                                GlbByte.gByteTCPWriteReq = 1;
                            }
                            break;
                        case 7:  // Pump Speed
                            if (txtBoxInput.Text != "")
                            {
                                i = Int32.Parse(txtBoxInput.Text);
                                if (i < 0)
                                    i = 0;
                                if (i > 100)
                                    i = 100;

                                GlbByte.GbyteWriteBuf[0] = 0x55;
                                GlbByte.GbyteWriteBuf[1] |= 0x00;
                                GlbByte.GbyteWriteBuf[2] |= 0x08;


                                GlbByte.GbyteWriteBuf[43] = (byte)i;

                                GlbByte.gByteTCPWriteReq = 1;
                            }
                            break;
                        case 8:  // Gamma Alarm
                            if (txtBoxInput.Text != "")
                            {
                                dblTemp = Double.Parse(txtBoxInput.Text);

                                //i = (int)(dblTemp * 10);  // input is in mR
                                i = (int)(dblTemp);  // input is in uSv/H
                                if (i < 0)
                                    i = 0;
                                if (i > 999999)
                                    i = 999999;

                                GlbByte.GbyteWriteBuf[0] = 0x55;
                                GlbByte.GbyteWriteBuf[1] |= 0x08;  // request for change Gamma Alarm

                                UnionInt.iIntData = i;
                                GlbByte.GbyteWriteBuf[21] = UnionInt.byte4;
                                GlbByte.GbyteWriteBuf[22] = UnionInt.byte3;
                                GlbByte.GbyteWriteBuf[23] = UnionInt.byte2;
                                GlbByte.GbyteWriteBuf[24] = UnionInt.byte1;
                                GlbByte.gByteTCPWriteReq = 1;
                            }
                            break;
                        case 9:  // Tritium Gain
                            if (txtBoxInput.Text != "")
                            {
                                //i = Int32.Parse(txtBoxInput.Text);
                                dblTemp = Double.Parse(txtBoxInput.Text);
                                if (dblTemp < 0.100)
                                    dblTemp = 0.100;
                                if (dblTemp > 9.999)
                                    dblTemp = 9.999;

                                i = (int)(dblTemp * 1000);
                                GlbByte.GbyteWriteBuf[0] = 0x55;
                                GlbByte.GbyteWriteBuf[1] |= 0x02;  // request for change Tritium Gain

                                UnionInt.iIntData = i;
                                GlbByte.GbyteWriteBuf[45] = UnionInt.byte4;
                                GlbByte.GbyteWriteBuf[46] = UnionInt.byte3;
                                GlbByte.GbyteWriteBuf[47] = UnionInt.byte2;
                                GlbByte.GbyteWriteBuf[48] = UnionInt.byte1;
                                GlbByte.gByteTCPWriteReq = 1;
                            }
                            break;
                        case 10:  // Body Temperature
                            if (txtBoxInput.Text != "")
                            {
                                //i = Int32.Parse(txtBoxInput.Text);
                                dblTemp = Double.Parse(txtBoxInput.Text);
                                if (dblTemp < 0)
                                    dblTemp = 0;
                                if (dblTemp > 70.0)
                                    dblTemp = 70.0;


                                i = (int)(dblTemp * 10);
                                GlbByte.GbyteWriteBuf[0] = 0x55;
                                GlbByte.GbyteWriteBuf[1] |= 0x01;  // request for change Tritium Gain
                                GlbByte.GbyteWriteBuf[2] |= 0x00;  // request for change Tritium Gain


                                j = i / 256;
                                GlbByte.GbyteWriteBuf[37] = (byte)j;
                                j = i % 256;
                                GlbByte.GbyteWriteBuf[38] = (byte)j;
                                GlbByte.gByteTCPWriteReq = 1;

                            }
                            break;
                        case 11:  // Pressure Calibration
                            if (txtBoxInput.Text != "")
                            {
                                dblTemp = Double.Parse(txtBoxInput.Text);
                                if ((dblTemp > 80.0) && (dblTemp < 120.0))
                                {
                                    i = (int)(dblTemp*1000);
                                    GlbByte.GbyteWriteBuf[0] = 0x55;
                                    GlbByte.GbyteWriteBuf[1] |= 0x00;  // request for change Tritium Gain
                                    GlbByte.GbyteWriteBuf[2] |= 0x40;  // request for change Tritium Gain

                                    UnionInt.iIntData = i;
                                    GlbByte.GbyteWriteBuf[29] = UnionInt.byte4;
                                    GlbByte.GbyteWriteBuf[30] = UnionInt.byte3;
                                    GlbByte.GbyteWriteBuf[31] = UnionInt.byte2;
                                    GlbByte.GbyteWriteBuf[32] = UnionInt.byte1;
                                    GlbByte.gByteTCPWriteReq = 1;
                                }
                                else
                                {
                                    MessageBox.Show("Pressure input is out of range");
                                }

                            }
                            break;

                        case 12:  // Drier Failure
                            if (txtBoxInput.Text != "")
                            {
                                //i = Int32.Parse(txtBoxInput.Text);
                                dblTemp = Double.Parse(txtBoxInput.Text);
                                if (dblTemp < 0)
                                    dblTemp = 0;
                                if (dblTemp > 100.0)
                                    dblTemp = 100.0;


                                i = (int)(dblTemp);
                                GlbByte.GbyteWriteBuf[0] = 0x55;
                                GlbByte.GbyteWriteBuf[1] |= 0x00;  // request for change Tritium Gain
                                GlbByte.GbyteWriteBuf[2] |= 0x10;  // request for change Tritium Gain


                                j = i / 256;
                                GlbByte.GbyteWriteBuf[39] = (byte)j;
                                j = i % 256;
                                GlbByte.GbyteWriteBuf[40] = (byte)j;
                                GlbByte.gByteTCPWriteReq = 1;

                            }
                            break;

                        case 13:  // Pressure Compensation Enable/Disable
                            if (txtBoxInput.Text != "")
                            {
                                i = Int32.Parse(txtBoxInput.Text);
                                if (i < 0)
                                    i = 0;
                                if (i > 1)
                                    i = 1;

                                GlbByte.GbyteWriteBuf[0] = 0x55;
                                GlbByte.GbyteWriteBuf[1] |= 0x00;
                                GlbByte.GbyteWriteBuf[2] |= 0x04;

                                GlbByte.GbyteWriteBuf[44] = (byte)i;

                                GlbByte.gByteTCPWriteReq = 1;
                            }
                            break;

                        case 14:  // Engineering Unit
                            if (txtBoxInput.Text != "")
                            {
                                i = Int32.Parse(txtBoxInput.Text);
                                if (i < 0)
                                    i = 0;
                                if (i > 4)
                                    i = 4;

                                GlbByte.giEngineeringUnitSelected = i;

                                writeLinesToFile();
                                GlbByte.GbyteRealTimeTrendRefreshReq = 1;

                            }
                            break;
                    }
                    */
                    i = Int32.Parse(textBox7.Text);
                    i = i - 40001;
                    if (i < 0)
                        i = 0;
                    if (i > 27)
                        i = 27;
                    GlbByte.gsModbusStartReg = (short)i;

                    i = Int32.Parse(textBox8.Text);
                    if (i < 0)
                        i = 1;
                    if (i > 28)
                        i = 28;
                    GlbByte.gsModbusNumberReg = (short)i;

                    // prepare data to be sent
                    for (i = 0; i < (int)GlbByte.gsModbusNumberReg; i++)
                    {
                        j = Int32.Parse(dgrdHoldingRegTable.Rows[GlbByte.gsModbusStartReg + i].Cells[1].Value.ToString());
                        GlbByte.GbyteWriteBuf[2 * i] = (byte)(j / 256);
                        GlbByte.GbyteWriteBuf[2 * i+1] = (byte)(j % 256);
                    }


                    GlbByte.gByteTCPWriteReq = 1;
                }
            
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void tmrTaskTick_Tick(object sender, EventArgs e)
        {
            double dblTemp;
            int iTemp, i, j,k;
            if(pbLoggedIn == true)
            {
                lblRequest.BackColor = Color.LightGray;
            }

            if (GlbByte.gsHoldingRegTableUpdateReg != 0)
            {
                // write to Holding registers
                j = GlbByte.gsModbusStartReg;
                k = GlbByte.gsModbusNumberReg;

                for (i = 0; i < k; i++)
                {
                    dgrdHoldingRegTable.Rows[i + j].Cells[1].Value = (ushort)GlbByte.GbyteReadBuf[2 * i] * 256 + (ushort)GlbByte.GbyteReadBuf[2 * i + 1];

                }

                GlbByte.gsHoldingRegTableUpdateReg = 0;

            }
           
            //if (GlbByte.giLocationSelect != 0)
            lblLocationData.Text = GlbByte.giUnitID.ToString();
            //else
            //{
            //    lblLocationData.Text = "Loop Scan";
            //}
            //textBox2.Text = GlbByte.giLocationTimmingArry[0].ToString();
            //textBox3.Text = GlbByte.giLocationTimmingArry[1].ToString();
            //textBox4.Text = GlbByte.giLocationTimmingArry[2].ToString();
            //textBox5.Text = GlbByte.giLocationTimmingArry[3].ToString();
            //textBox6.Text = GlbByte.giLocationTimmingArry[4].ToString();

            textBox1.Text = iTextBoxSelectedIndex.ToString();
            dblTemp = (double)GlbByte.giTritiumAlarmSetting * GlbByte.gdblEngUnitFactor[GlbByte.giEngineeringUnitSelected];

            if (GlbByte.giEngineeringUnitSelected == 0)
                lblTritiumAlarmData.Text = dblTemp.ToString("F0");
            else
            {
                iTemp = (int)(dblTemp * 10);
                dblTemp = (float)iTemp * 0.1;
                lblTritiumAlarmData.Text = dblTemp.ToString("F1"); // LogInterval.ToString();
            }
            
            dblTemp = GlbByte.gsTritiumGain / 1000.0;
            lblTritiumGainData.Text = dblTemp.ToString("F3");

            lblDateTimeData.Text = GlbByte.gdtCurrent.ToString("yyyy-MM-dd HH:mm:ss");

            dblTemp = GlbByte.gsFlowFactor/ 1000.0;
            lblFlowCaliFactorData.Text = dblTemp.ToString("F3");

            dblTemp = (double)GlbByte.gsLogInterval * GlbByte.gdblEngUnitFactor[GlbByte.giEngineeringUnitSelected];
            if (GlbByte.giEngineeringUnitSelected == 0)
                lblLogIntervalData.Text = dblTemp.ToString("F0");
            else
            {
                iTemp = (int)(dblTemp * 10);
                dblTemp = (float)iTemp * 0.1;
                lblLogIntervalData.Text = dblTemp.ToString("F1"); // LogInterval.ToString();
            }

            iTemp = GlbByte.gbyteResponseBits1 & 0x7f;

            lblPumpSpeedData.Text = iTemp.ToString();


            //dblTemp = GlbByte.giGammaAlarmSetting / 10.0;     // mR/Hr        
            //lblGammaAlarmData.Text = dblTemp.ToString("F1");
            iTemp = GlbByte.giGammaAlarmSetting;  // uSv/H
            lblGammaAlarmData.Text = iTemp.ToString();

            dblTemp = GlbByte.gsGammaGain/ 1000.0;
            lblGammaGainData.Text = dblTemp.ToString("F3");

            dblTemp = GlbByte.gsBodyTempSetting / 10.0;
            lblTemperatureSettingData.Text = dblTemp.ToString("F1");

            dblTemp = GlbByte.gsMeasPressureFactor / 10000.0;
            lblMeasurePressureFactorData.Text = dblTemp.ToString("F3");

            dblTemp = GlbByte.gsCompPressureFactor / 10000.0;
            lblCompPressureFactorData.Text = dblTemp.ToString("F3");

            lblDrierRHSettingData.Text = GlbByte.gsDrierAlarm.ToString();

            if((GlbByte.gbyteResponseBits1 & 0x80) == 0)
            {
                lblPressureCompensationSelData.Text = "Disabled";
            }
            else
            {
                lblPressureCompensationSelData.Text = "Enabled";
            }

            lblEngUnit.Text = GlbByte.gstrEngUnit[GlbByte.giEngineeringUnitSelected];
              

        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void lblTritiumAlarm_Click(object sender, EventArgs e)
        {

            if (pbLoggedIn == true)
            {

                lblLocation.BackColor = Color.LightGray;
                panel1.Visible = false;
                lblTritiumAlarm.BackColor = Color.LightGray;
                lblTritiumGain.BackColor = Color.LightGray;
                lblInstrumentDateTime.BackColor = Color.LightGray;
                lblFlowCalFactor.BackColor = Color.LightGray;
                lblInstrumentLogInterval.BackColor = Color.LightGray;
                lblPumpSpeed.BackColor = Color.LightGray;
                lblGammaGain.BackColor = Color.LightGray;
                lblTempSetting.BackColor = Color.LightGray;
                lblPressureCalFactor.BackColor = Color.LightGray;
                lblDrierAlarm.BackColor = Color.LightGray;
                lblPressureCompEnable.BackColor = Color.LightGray;
                lblGammaAlarm.BackColor = Color.LightGray;
                label17.BackColor = Color.LightGray;

                piSelectedItemIndex = 2;
                piPreSelectedItemIndex = piSelectedItemIndex;
                lblTritiumAlarm.BackColor = Color.Turquoise;

                lblRequest.Text = "Enter The Tritium Alarm Level:";
                lblRequest.BackColor = Color.LightGray;

                //textBox1.Text = iTextBoxSelectedIndex.ToString();
                //dblTemp = (double)GlbByte.giTritiumAlarmSetting * GlbByte.gdblEngUnitFactor[GlbByte.giEngineeringUnitSelected];

                if(GlbByte.giEngineeringUnitSelected == 0)
                    lblHelpInfo.Text = "From 0 to entire range in µCi/m3";

                if (GlbByte.giEngineeringUnitSelected == 1)
                    lblHelpInfo.Text = "From 0.0 to entire range in MPC(a)";

                if (GlbByte.giEngineeringUnitSelected == 2)
                    lblHelpInfo.Text = "From 0 to entire range in MBq/m3";

                if (GlbByte.giEngineeringUnitSelected == 3)
                    lblHelpInfo.Text = "From 0.0 to entire range in DAC";

                if (GlbByte.giEngineeringUnitSelected == 4)
                    lblHelpInfo.Text = "From 0.0 to entire range in mRem/H";

                txtBoxInput.Text = "";
            }
        }

        private void lblLogIntervalData_Click(object sender, EventArgs e)
        {

        }

        private void lblMeasurePressureFactorData_Click(object sender, EventArgs e)
        {

        }

        private void lblLocation_Click(object sender, EventArgs e)
        {
            if (pbLoggedIn == true)
            {
                lblLocation.BackColor = Color.LightGray;
                panel1.Visible = false;
                lblTritiumAlarm.BackColor = Color.LightGray;
                lblTritiumGain.BackColor = Color.LightGray;
                lblInstrumentDateTime.BackColor = Color.LightGray;
                lblFlowCalFactor.BackColor = Color.LightGray;
                lblInstrumentLogInterval.BackColor = Color.LightGray;
                lblPumpSpeed.BackColor = Color.LightGray;
                lblGammaGain.BackColor = Color.LightGray;
                lblTempSetting.BackColor = Color.LightGray;
                lblPressureCalFactor.BackColor = Color.LightGray;
                lblDrierAlarm.BackColor = Color.LightGray;
                lblPressureCompEnable.BackColor = Color.LightGray;
                lblGammaAlarm.BackColor = Color.LightGray;
                label17.BackColor = Color.LightGray;

                piSelectedItemIndex = 1;
                piPreSelectedItemIndex = piSelectedItemIndex;
                lblLocation.BackColor = Color.Turquoise;
                //panel1.Visible = true;
                lblRequest.Text = "Enter Instrument ID.:";
                lblRequest.BackColor = Color.LightGray;
                lblHelpInfo.Text = "Range  from 0 to 255";
                txtBoxInput.Text = "";
            }
        }

        private void label8_Click(object sender, EventArgs e)
        {
            if (pbLoggedIn == true)
            {
                lblLocation.BackColor = Color.LightGray;
                panel1.Visible = false;
                lblTritiumAlarm.BackColor = Color.LightGray;
                lblTritiumGain.BackColor = Color.LightGray;
                lblInstrumentDateTime.BackColor = Color.LightGray;
                lblFlowCalFactor.BackColor = Color.LightGray;
                lblInstrumentLogInterval.BackColor = Color.LightGray;
                lblPumpSpeed.BackColor = Color.LightGray;
                lblGammaGain.BackColor = Color.LightGray;
                lblTempSetting.BackColor = Color.LightGray;
                lblPressureCalFactor.BackColor = Color.LightGray;
                lblDrierAlarm.BackColor = Color.LightGray;
                lblPressureCompEnable.BackColor = Color.LightGray;
                lblGammaAlarm.BackColor = Color.LightGray;
                label17.BackColor = Color.LightGray;

                piSelectedItemIndex = 7;
                piPreSelectedItemIndex = piSelectedItemIndex;
                lblPumpSpeed.BackColor = Color.Turquoise;

                lblRequest.Text = "Enter Percentage of Speed";
                lblRequest.BackColor = Color.LightGray;
                lblHelpInfo.Text = "Range from From 0 to 100";
                txtBoxInput.Text = "";
            }
        }

        private void lblGammaGain_Click(object sender, EventArgs e)
        {
            if (pbLoggedIn == true)
            {
                lblLocation.BackColor = Color.LightGray;
                panel1.Visible = false;
                lblTritiumAlarm.BackColor = Color.LightGray;
                lblTritiumGain.BackColor = Color.LightGray;
                lblInstrumentDateTime.BackColor = Color.LightGray;
                lblFlowCalFactor.BackColor = Color.LightGray;
                lblInstrumentLogInterval.BackColor = Color.LightGray;
                lblPumpSpeed.BackColor = Color.LightGray;
                lblGammaGain.BackColor = Color.LightGray;
                lblGammaAlarm.BackColor = Color.LightGray;
                lblTempSetting.BackColor = Color.LightGray;
                lblPressureCalFactor.BackColor = Color.LightGray;
                lblDrierAlarm.BackColor = Color.LightGray;
                lblPressureCompEnable.BackColor = Color.LightGray;
                label17.BackColor = Color.LightGray;

                piSelectedItemIndex = 9;
                piPreSelectedItemIndex = piSelectedItemIndex;
                lblGammaGain.BackColor = Color.Turquoise;

                lblRequest.Text = "Enter The Gamma Gain:";
                lblRequest.BackColor = Color.LightGray;
                lblHelpInfo.Text = "From 0.100 to 9.999";
                txtBoxInput.Text = "";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public void writeLinesToFile()
        {
            string msConfigFile;
            try
            {


                msConfigFile = GlbByte.msCurrentDirName + @"\SystemCfg.txt";
                //Pass the filepath and filename to the StreamWriter Constructor
                System.IO.StreamWriter sw = new System.IO.StreamWriter(msConfigFile);

                //Write a line of text
                sw.WriteLine(GlbByte.msIPAddress);
                sw.WriteLine(GlbByte.miHistSaveInterval.ToString());
                sw.WriteLine(GlbByte.giPassword.ToString());
                sw.WriteLine(GlbByte.giLocationSelect.ToString());
                sw.WriteLine(GlbByte.giLocationTimmingArry[0].ToString());
                sw.WriteLine(GlbByte.giLocationTimmingArry[1].ToString());
                sw.WriteLine(GlbByte.giLocationTimmingArry[2].ToString());
                sw.WriteLine(GlbByte.giLocationTimmingArry[3].ToString());
                sw.WriteLine(GlbByte.giLocationTimmingArry[4].ToString());                
                sw.WriteLine(GlbByte.giEngineeringUnitSelected.ToString());

                //Close the file
                sw.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.Message);
            }
            finally
            {
                Console.WriteLine("Executing finally block.");
            }
        }

        private void label12_Click(object sender, EventArgs e)
        {
            txtBoxInput.Text = "1";
        }

        private void label13_Click(object sender, EventArgs e)
        {
            txtBoxInput.Text = "2";
        }

        private void label14_Click(object sender, EventArgs e)
        {
            txtBoxInput.Text = "3";
        }

        private void label15_Click(object sender, EventArgs e)
        {
            txtBoxInput.Text = "4";
        }

        private void label16_Click(object sender, EventArgs e)
        {
            txtBoxInput.Text = "5";
        }

        private void lblTritiumGain_Click(object sender, EventArgs e)
        {
            if (pbLoggedIn == true)
            {
                lblLocation.BackColor = Color.LightGray;
                panel1.Visible = false;
                lblTritiumAlarm.BackColor = Color.LightGray;
                lblTritiumGain.BackColor = Color.LightGray;
                lblInstrumentDateTime.BackColor = Color.LightGray;
                lblFlowCalFactor.BackColor = Color.LightGray;
                lblInstrumentLogInterval.BackColor = Color.LightGray;
                lblPumpSpeed.BackColor = Color.LightGray;
                lblGammaGain.BackColor = Color.LightGray;
                lblTempSetting.BackColor = Color.LightGray;
                lblPressureCalFactor.BackColor = Color.LightGray;
                lblDrierAlarm.BackColor = Color.LightGray;
                lblPressureCompEnable.BackColor = Color.LightGray;
                lblGammaAlarm.BackColor = Color.LightGray;
                label17.BackColor = Color.LightGray;

                piSelectedItemIndex = 3;
                piPreSelectedItemIndex = piSelectedItemIndex;
                lblTritiumGain.BackColor = Color.Turquoise;

                lblRequest.Text = "Enter The Tritium Gain:";
                lblRequest.BackColor = Color.LightGray;
                lblHelpInfo.Text = "From 0.100 to 9.999";
                txtBoxInput.Text = "";
            }
        }

        private void lblInstrumentDateTime_Click(object sender, EventArgs e)
        {
            if (pbLoggedIn == true)
            {
                lblLocation.BackColor = Color.LightGray;
                panel1.Visible = false;
                lblTritiumAlarm.BackColor = Color.LightGray;
                lblTritiumGain.BackColor = Color.LightGray;
                lblInstrumentDateTime.BackColor = Color.LightGray;
                lblFlowCalFactor.BackColor = Color.LightGray;
                lblInstrumentLogInterval.BackColor = Color.LightGray;
                lblPumpSpeed.BackColor = Color.LightGray;
                lblGammaGain.BackColor = Color.LightGray;
                lblTempSetting.BackColor = Color.LightGray;
                lblPressureCalFactor.BackColor = Color.LightGray;
                lblDrierAlarm.BackColor = Color.LightGray;
                lblPressureCompEnable.BackColor = Color.LightGray;
                lblGammaAlarm.BackColor = Color.LightGray;
                label17.BackColor = Color.LightGray;

                piSelectedItemIndex = 4;
                piPreSelectedItemIndex = piSelectedItemIndex;
                lblInstrumentDateTime.BackColor = Color.Turquoise;

                lblRequest.Text = "Send the PC time to Controller ";
                lblRequest.BackColor = Color.LightGray;
                lblHelpInfo.Text = "Please make sure PC time is accurate! then Press Send Button";
                txtBoxInput.Text = "";
            }
        }

        private void lblFlowCalFactor_Click(object sender, EventArgs e)
        {
            if (pbLoggedIn == true)
            {
                lblLocation.BackColor = Color.LightGray;
                panel1.Visible = false;
                lblTritiumAlarm.BackColor = Color.LightGray;
                lblTritiumGain.BackColor = Color.LightGray;
                lblInstrumentDateTime.BackColor = Color.LightGray;
                lblFlowCalFactor.BackColor = Color.LightGray;
                lblInstrumentLogInterval.BackColor = Color.LightGray;
                lblPumpSpeed.BackColor = Color.LightGray;
                lblGammaGain.BackColor = Color.LightGray;
                lblTempSetting.BackColor = Color.LightGray;
                lblPressureCalFactor.BackColor = Color.LightGray;
                lblDrierAlarm.BackColor = Color.LightGray;
                lblPressureCompEnable.BackColor = Color.LightGray;
                lblGammaAlarm.BackColor = Color.LightGray;
                label17.BackColor = Color.LightGray;

                piSelectedItemIndex = 5;
                piPreSelectedItemIndex = piSelectedItemIndex;
                lblFlowCalFactor.BackColor = Color.Turquoise;

                lblRequest.Text = "Enter the Current Flow ";
                lblRequest.BackColor = Color.LightGray;
                lblHelpInfo.Text = "Measure the Fow at the inlet or Outlet and enter the value in L/M.  Range is from 1.0 to 30.0 L/M!";
                txtBoxInput.Text = "";
            }

        }

        private void lblInstrumentLogInterval_Click(object sender, EventArgs e)
        {
            if (pbLoggedIn == true)
            {
                lblLocation.BackColor = Color.LightGray;
                panel1.Visible = false;
                lblTritiumAlarm.BackColor = Color.LightGray;
                lblTritiumGain.BackColor = Color.LightGray;
                lblInstrumentDateTime.BackColor = Color.LightGray;
                lblFlowCalFactor.BackColor = Color.LightGray;
                lblInstrumentLogInterval.BackColor = Color.LightGray;
                lblPumpSpeed.BackColor = Color.LightGray;
                lblGammaGain.BackColor = Color.LightGray;
                lblTempSetting.BackColor = Color.LightGray;
                lblPressureCalFactor.BackColor = Color.LightGray;
                lblDrierAlarm.BackColor = Color.LightGray;
                lblPressureCompEnable.BackColor = Color.LightGray;
                lblGammaAlarm.BackColor = Color.LightGray;
                label17.BackColor = Color.LightGray;

                piSelectedItemIndex = 6;
                piPreSelectedItemIndex = piSelectedItemIndex;
                lblInstrumentLogInterval.BackColor = Color.Turquoise;

                //lblRequest.Text = "Enter the Data Log interval ";
                //lblRequest.BackColor = Color.LightGray;
                //lblHelpInfo.Text = "The period to save data in controller in unit of Second, Range from 1 to 36000";
                //txtBoxInput.Text = "";
                if (GlbByte.giEngineeringUnitSelected == 0)
                    lblHelpInfo.Text = "From 0 to entire range in µCi/m3";

                if (GlbByte.giEngineeringUnitSelected == 1)
                    lblHelpInfo.Text = "From 0.0 to entire range in MPC(a)";

                if (GlbByte.giEngineeringUnitSelected == 2)
                    lblHelpInfo.Text = "From 0 to entire range in MBq/m3";

                if (GlbByte.giEngineeringUnitSelected == 3)
                    lblHelpInfo.Text = "From 0.0 to entire range in DAC";

                if (GlbByte.giEngineeringUnitSelected == 4)
                    lblHelpInfo.Text = "From 0.0 to entire range in mRem/H";

                txtBoxInput.Text = "";

            }

        }

        private void lblGammaAlarm_Click(object sender, EventArgs e)
        {
            if (pbLoggedIn == true)
            {
                lblLocation.BackColor = Color.LightGray;
                panel1.Visible = false;
                lblTritiumAlarm.BackColor = Color.LightGray;
                lblTritiumGain.BackColor = Color.LightGray;
                lblInstrumentDateTime.BackColor = Color.LightGray;
                lblFlowCalFactor.BackColor = Color.LightGray;
                lblInstrumentLogInterval.BackColor = Color.LightGray;
                lblPumpSpeed.BackColor = Color.LightGray;
                lblGammaGain.BackColor = Color.LightGray;
                lblTempSetting.BackColor = Color.LightGray;
                lblPressureCalFactor.BackColor = Color.LightGray;
                lblDrierAlarm.BackColor = Color.LightGray;
                lblPressureCompEnable.BackColor = Color.LightGray;
                lblGammaAlarm.BackColor = Color.LightGray;
                label17.BackColor = Color.LightGray;

                piSelectedItemIndex = 8;
                piPreSelectedItemIndex = piSelectedItemIndex;
                lblGammaAlarm.BackColor = Color.Turquoise;

                lblRequest.Text = "Enter GM Gamma Alarm";
                lblRequest.BackColor = Color.LightGray;
                lblHelpInfo.Text = "The Alarm level in unit of mSv/H, Range from 1 to 999999";
                txtBoxInput.Text = "";
            }

        }

        private void label17_Click(object sender, EventArgs e)
        {
            if (pbLoggedIn == true)
            {
                lblLocation.BackColor = Color.LightGray;
                panel1.Visible = false;
                lblTritiumAlarm.BackColor = Color.LightGray;
                lblTritiumGain.BackColor = Color.LightGray;
                lblInstrumentDateTime.BackColor = Color.LightGray;
                lblFlowCalFactor.BackColor = Color.LightGray;
                lblInstrumentLogInterval.BackColor = Color.LightGray;
                lblPumpSpeed.BackColor = Color.LightGray;
                lblGammaGain.BackColor = Color.LightGray;
                lblTempSetting.BackColor = Color.LightGray;
                lblPressureCalFactor.BackColor = Color.LightGray;
                lblDrierAlarm.BackColor = Color.LightGray;
                lblPressureCompEnable.BackColor = Color.LightGray;
                lblGammaAlarm.BackColor = Color.LightGray;
                label17.BackColor = Color.LightGray;

                piSelectedItemIndex = 14;
                piPreSelectedItemIndex = piSelectedItemIndex;
                label17.BackColor = Color.Turquoise; //Color.Yellow;

                lblRequest.Text = "Select 0 to 4 for Engineering Unit ";
                lblRequest.BackColor = Color.LightGray; //Color.Yellow;
                lblHelpInfo.Text = "0 - µCi/m3, 1 - MPC(a), 2 - MBq/m, 3 - DAC, 4 - mRem/h";
                txtBoxInput.Text = "";
            }
              
        }

        private void lblTempSetting_Click(object sender, EventArgs e)
        {
            if (pbLoggedIn == true)
            {
                lblLocation.BackColor = Color.LightGray;
                panel1.Visible = false;
                lblTritiumAlarm.BackColor = Color.LightGray;
                lblTritiumGain.BackColor = Color.LightGray;
                lblInstrumentDateTime.BackColor = Color.LightGray;
                lblFlowCalFactor.BackColor = Color.LightGray;
                lblInstrumentLogInterval.BackColor = Color.LightGray;
                lblPumpSpeed.BackColor = Color.LightGray;
                lblGammaGain.BackColor = Color.LightGray;
                lblTempSetting.BackColor = Color.LightGray;
                lblPressureCalFactor.BackColor = Color.LightGray;
                lblDrierAlarm.BackColor = Color.LightGray;
                lblPressureCompEnable.BackColor = Color.LightGray;
                lblGammaAlarm.BackColor = Color.LightGray;
                label17.BackColor = Color.LightGray;

                piSelectedItemIndex = 10;
                piPreSelectedItemIndex = piSelectedItemIndex;
                lblTempSetting.BackColor = Color.Turquoise;

                lblRequest.Text = "Enter Temperature setting";
                lblRequest.BackColor = Color.LightGray;
                lblHelpInfo.Text = " Ion Chamber Baking Temperature in unit of °C, Range from 0.0 to 70.0";
                txtBoxInput.Text = "";
            }


        }

        private void lblPressureCalFactor_Click(object sender, EventArgs e)
        {
            if (pbLoggedIn == true)
            {
                lblLocation.BackColor = Color.LightGray;
                panel1.Visible = false;
                lblTritiumAlarm.BackColor = Color.LightGray;
                lblTritiumGain.BackColor = Color.LightGray;
                lblInstrumentDateTime.BackColor = Color.LightGray;
                lblFlowCalFactor.BackColor = Color.LightGray;
                lblInstrumentLogInterval.BackColor = Color.LightGray;
                lblPumpSpeed.BackColor = Color.LightGray;
                lblGammaGain.BackColor = Color.LightGray;
                lblTempSetting.BackColor = Color.LightGray;
                lblPressureCalFactor.BackColor = Color.LightGray;
                lblDrierAlarm.BackColor = Color.LightGray;
                lblPressureCompEnable.BackColor = Color.LightGray;
                lblGammaAlarm.BackColor = Color.LightGray;
                label17.BackColor = Color.LightGray;

                piSelectedItemIndex = 11;
                piPreSelectedItemIndex = piSelectedItemIndex;
                lblPressureCalFactor.BackColor = Color.Turquoise;

                lblRequest.Text = "Enter current atmosphere Pressure";
                lblRequest.BackColor = Color.LightGray;
                lblHelpInfo.Text = " Make sure the Pump is disconnected. Pressure input Range shall be from 80.0 to 120.0 Kpa";
                txtBoxInput.Text = "";
            }


        }

        private void lblDrierAlarm_Click(object sender, EventArgs e)
        {
            if (pbLoggedIn == true)
            {
                lblLocation.BackColor = Color.LightGray;
                panel1.Visible = false;
                lblTritiumAlarm.BackColor = Color.LightGray;
                lblTritiumGain.BackColor = Color.LightGray;
                lblInstrumentDateTime.BackColor = Color.LightGray;
                lblFlowCalFactor.BackColor = Color.LightGray;
                lblInstrumentLogInterval.BackColor = Color.LightGray;
                lblPumpSpeed.BackColor = Color.LightGray;
                lblGammaGain.BackColor = Color.LightGray;
                lblTempSetting.BackColor = Color.LightGray;
                lblPressureCalFactor.BackColor = Color.LightGray;
                lblDrierAlarm.BackColor = Color.LightGray;
                lblPressureCompEnable.BackColor = Color.LightGray;
                lblGammaAlarm.BackColor = Color.LightGray;
                label17.BackColor = Color.LightGray;

                piSelectedItemIndex = 12;
                piPreSelectedItemIndex = piSelectedItemIndex;
                lblDrierAlarm.BackColor = Color.Turquoise;

                lblRequest.Text = "Enter RH High Alarm setting";
                lblRequest.BackColor = Color.LightGray;
                lblHelpInfo.Text = "RH High = Drier failure,  Range from 0 to 100 %RH, 100%RH will disable this alarm";
                txtBoxInput.Text = "";
            }
        }

        private void lblPressureCompEnable_Click(object sender, EventArgs e)
        {
            if (pbLoggedIn == true)
            {
                lblLocation.BackColor = Color.LightGray;
                panel1.Visible = false;
                lblTritiumAlarm.BackColor = Color.LightGray;
                lblTritiumGain.BackColor = Color.LightGray;
                lblInstrumentDateTime.BackColor = Color.LightGray;
                lblFlowCalFactor.BackColor = Color.LightGray;
                lblInstrumentLogInterval.BackColor = Color.LightGray;
                lblPumpSpeed.BackColor = Color.LightGray;
                lblGammaGain.BackColor = Color.LightGray;
                lblTempSetting.BackColor = Color.LightGray;
                lblPressureCalFactor.BackColor = Color.LightGray;
                lblDrierAlarm.BackColor = Color.LightGray;
                lblPressureCompEnable.BackColor = Color.LightGray;
                lblGammaAlarm.BackColor = Color.LightGray;
                label17.BackColor = Color.LightGray;

                piSelectedItemIndex = 13;
                piPreSelectedItemIndex = piSelectedItemIndex;
                lblPressureCompEnable.BackColor = Color.Turquoise;

                lblRequest.Text = "Enable/Disable Pressure Compensation";
                lblRequest.BackColor = Color.LightGray;
                lblHelpInfo.Text = "0 = Disable,  1 to Enable";
                txtBoxInput.Text = "";
            }
        }

        private void lblPressureCompensationSelData_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //GlbByte.GbyteWriteBuf[0] = 0x55;
            //GlbByte.GbyteWriteBuf[1] = 0;
            //GlbByte.GbyteWriteBuf[2] = 0x1;
            // request for background cancellation
            //GlbByte.GbyteWriteBuf[2] = 0;
            //GlbByte.GbyteWriteBuf[3] = 0;
            //GlbByte.GbyteWriteBuf[4] = 0;
            //GlbByte.GbyteWriteBuf[5] = 1;

            //GlbByte.GbyteWriteBuf[6] = 0;
            //GlbByte.GbyteWriteBuf[7] = 2;

            //GlbByte.GbyteWriteBuf[8] = 0;
            //GlbByte.GbyteWriteBuf[9] = 3;



            GlbByte.gByteTCPWriteReq = 1;
            //timer1.Enabled = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //GlbByte.GbyteWriteBuf[0] = 0x55;
            //GlbByte.GbyteWriteBuf[1] = 0;
            //GlbByte.GbyteWriteBuf[2] = 0x0;
            //request for background cancellation


           //GlbByte.GbyteWriteBuf[2] = 0;
           //GlbByte.GbyteWriteBuf[3] = 0;
           // GlbByte.GbyteWriteBuf[4] = 0;
           // GlbByte.GbyteWriteBuf[5] = 0;

           // GlbByte.GbyteWriteBuf[6] = 0;
           // GlbByte.GbyteWriteBuf[7] = 2;

           // GlbByte.GbyteWriteBuf[8] = 0;
           // GlbByte.GbyteWriteBuf[9] = 0;





            GlbByte.gByteTCPWriteReq = 1;


            //timer1.Enabled = false;

        }

        private void timer1_Tick(object sender, EventArgs e)
        {

           // GlbByte.GbyteWriteBuf[0] = 0x55;
           // GlbByte.GbyteWriteBuf[1] |= 0;
           // GlbByte.GbyteWriteBuf[2] |= 0x1;
           // request for background cancellation

           //GlbByte.GbyteWriteBuf[2] = 0;
           //GlbByte.GbyteWriteBuf[3] = 0;
           // GlbByte.GbyteWriteBuf[4] = 0;
           // GlbByte.GbyteWriteBuf[5] = 1;

           // GlbByte.GbyteWriteBuf[6] = 0;
           // GlbByte.GbyteWriteBuf[7] = 2;

           // GlbByte.GbyteWriteBuf[8] = 0;
           // GlbByte.GbyteWriteBuf[9] = 3;



           // GlbByte.gByteTCPWriteReq = 1;

        }

        private void btn0_Click(object sender, EventArgs e)
        {
            string sTemp;
            sTemp = "0";

            if(panel1.Visible ==  false)
            {
                txtBoxInput.Text = txtBoxInput.Text + sTemp;
            }
            else
            {
                changeTextBox(sTemp);               
            }


        }

        private void changeTextBox(string sTxt)
        {
            switch(iTextBoxSelectedIndex)
            {
                case 0:
                    txtBoxInput.Text = txtBoxInput.Text + sTxt;
                    break;

                case 1:
                    textBox2.Text = textBox2.Text + sTxt;
                    break;

                case 2:
                    textBox3.Text = textBox3.Text + sTxt;
                    break;

                case 3:
                    textBox4.Text = textBox4.Text + sTxt;
                    break;
                case 4:
                    textBox5.Text = textBox5.Text + sTxt;
                    break;
                case 5:
                    textBox6.Text = textBox6.Text + sTxt;
                    break;



            }
        }

        private void txtBoxInput_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtBoxInput_MouseEnter(object sender, EventArgs e)
        {
            iTextBoxSelectedIndex = 0;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_MouseEnter(object sender, EventArgs e)
        {
            iTextBoxSelectedIndex = 1;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_MouseEnter(object sender, EventArgs e)
        {
            iTextBoxSelectedIndex = 2;
        }

        private void textBox4_MouseEnter(object sender, EventArgs e)
        {
            iTextBoxSelectedIndex = 3;
        }

        private void textBox5_MouseEnter(object sender, EventArgs e)
        {
            iTextBoxSelectedIndex = 4;

        }

        private void textBox6_MouseEnter(object sender, EventArgs e)
        {
            iTextBoxSelectedIndex = 5;
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            string sTemp;
            sTemp = "1";

            if (panel1.Visible == false)
            {
                txtBoxInput.Text = txtBoxInput.Text + sTemp;
            }
            else
            {
                changeTextBox(sTemp);
            }

        }

        private void btn2_Click(object sender, EventArgs e)
        {
            string sTemp;
            sTemp = "2";

            if (panel1.Visible == false)
            {
                txtBoxInput.Text = txtBoxInput.Text + sTemp;
            }
            else
            {
                changeTextBox(sTemp);
            }

        }

        private void btn3_Click(object sender, EventArgs e)
        {
            string sTemp;
            sTemp = "3";

            if (panel1.Visible == false)
            {
                txtBoxInput.Text = txtBoxInput.Text + sTemp;
            }
            else
            {
                changeTextBox(sTemp);
            }

        }

        private void btn4_Click(object sender, EventArgs e)
        {
            string sTemp;
            sTemp = "4";

            if (panel1.Visible == false)
            {
                txtBoxInput.Text = txtBoxInput.Text + sTemp;
            }
            else
            {
                changeTextBox(sTemp);
            }

        }

        private void btn5_Click(object sender, EventArgs e)
        {
            string sTemp;
            sTemp = "5";

            if (panel1.Visible == false)
            {
                txtBoxInput.Text = txtBoxInput.Text + sTemp;
            }
            else
            {
                changeTextBox(sTemp);
            }
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            string sTemp;
            sTemp = "6";

            if (panel1.Visible == false)
            {
                txtBoxInput.Text = txtBoxInput.Text + sTemp;
            }
            else
            {
                changeTextBox(sTemp);
            }
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            string sTemp;
            sTemp = "7";

            if (panel1.Visible == false)
            {
                txtBoxInput.Text = txtBoxInput.Text + sTemp;
            }
            else
            {
                changeTextBox(sTemp);
            }
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            string sTemp;
            sTemp = "8";

            if (panel1.Visible == false)
            {
                txtBoxInput.Text = txtBoxInput.Text + sTemp;
            }
            else
            {
                changeTextBox(sTemp);
            }
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            string sTemp;
            sTemp = "9";

            if (panel1.Visible == false)
            {
                txtBoxInput.Text = txtBoxInput.Text + sTemp;
            }
            else
            {
                changeTextBox(sTemp);
            }
        }

        private void btnDOT_Click(object sender, EventArgs e)
        {
            string sTemp;
            sTemp = ".";

            if (panel1.Visible == false)
            {
                txtBoxInput.Text = txtBoxInput.Text + sTemp;
            }
            else
            {
                changeTextBox(sTemp);
            }
        }

        private void btnCLR_Click(object sender, EventArgs e)
        {
            if (panel1.Visible == false)
            {
                txtBoxInput.Text = "";

            }
            else
            {
                switch (iTextBoxSelectedIndex)
                {
                    case 0:
                        txtBoxInput.Text = "";
                        break;

                    case 1:
                        textBox2.Text = "";
                        break;

                    case 2:
                        textBox3.Text = "";
                        break;

                    case 3:
                        textBox4.Text = "";
                        break;
                    case 4:
                        textBox5.Text = "";
                        break;
                    case 5:
                        textBox6.Text = "";
                        break;
                }

            }

        }

        private void lblHelpInfo_Click(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void dgrdHoldingRegTable_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            //int i;
            //i = Int32.Parse(textBox7.Text);
            //i = i - 40001;
            //if(i < 0)
            //     i = 0;
            //if(i > 27)
            //   i = 27;
            //GlbByte.gsModbusStartReg = (short)i;

            //i = Int32.Parse(textBox8.Text);
            //if (i < 0)
            //    i = 1;
            //if (i > 28)
            //    i = 28;
            //GlbByte.gsModbusNumberReg = (short)i;


            //GlbByte.GbyteTCPReadRequested = 1;

            ReadHoldingRegs();
        }

        private void ReadHoldingRegs()
        {
            int i;
            i = Int32.Parse(textBox7.Text);
            i = i - 40001;
            if (i < 0)
                i = 0;
            if (i > 27)
                i = 27;
            GlbByte.gsModbusStartReg = (short)i;

            i = Int32.Parse(textBox8.Text);
            if (i < 0)
                i = 1;
            if (i > 28)
                i = 28;
            GlbByte.gsModbusNumberReg = (short)i;


            GlbByte.GbyteTCPReadRequested = 1;


        }

        private void frmInstrumentSetup_FormClosing(object sender, FormClosingEventArgs e)
        {
            GlbByte.giFormSetupOpened = 0;
        }
    }
}
