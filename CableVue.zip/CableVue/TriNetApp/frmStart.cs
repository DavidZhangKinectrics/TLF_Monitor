using System;
using System.Net;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using ModbusTCP;
using TriNet;
using System.Data.OleDb;
using System.Media;
using System.Windows.Forms.DataVisualization.Charting;
using System.IO;

using System.Runtime.InteropServices;
[StructLayout(LayoutKind.Explicit)]
struct byte_array
{
    [FieldOffset(0)]
    public byte byte1;
    [FieldOffset(1)]
    public byte byte2;
    [FieldOffset(2)]
    public byte byte3;
    [FieldOffset(3)]
    public byte byte4;
    [FieldOffset(0)]
    public int iIntData;
}

[StructLayout(LayoutKind.Explicit)]
struct Short_array
{
    [FieldOffset(0)]
    public byte byte1;
    [FieldOffset(1)]
    public byte byte2;
    [FieldOffset(0)]
    public short sData;
}

namespace Modbus
{
    public class frmStart : System.Windows.Forms.Form
    {

        //public byte[] pbyteReadData = new byte[200];
        private ModbusTCP.Master MBmaster;
        private TextBox txtData;
        private Label labData;
        private byte[] data;

        private System.Windows.Forms.GroupBox grpData;
        private System.Windows.Forms.Button btnReadDisInp;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtSize;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtStartAdress;
        private System.Windows.Forms.Button btnReadCoils;
        private System.Windows.Forms.GroupBox grpExchange;
        private System.Windows.Forms.Button btnReadHoldReg;
        private System.Windows.Forms.Button btnReadInpReg;
        private System.Windows.Forms.Button btnWriteSingleCoil;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radBits;
        private System.Windows.Forms.RadioButton radBytes;
        private System.Windows.Forms.RadioButton radWord;
        private System.Windows.Forms.Button btnWriteSingleReg;
        private System.Windows.Forms.Button btnWriteMultipleCoils;
        private System.Windows.Forms.Button btnWriteMultipleReg;
        private Label label4;
        private TextBox txtUnit;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem controlToolStripMenuItem;
        private ToolStripMenuItem setupToolStripMenuItem;
        private ToolStripMenuItem helpToolStripMenuItem;
        private System.ComponentModel.IContainer components;
        
        private ToolStripMenuItem statusToolStripMenuItem;
        private ToolStripMenuItem controlToolStripMenuItem1;
        private Label label5;
       // public string msCurrentDirName;
        //public string msIPAddress;
       // public int miHistSaveInterval;
        private Timer TaskTick;

        private static DateTime psDataSavedTime;
        private bool pbChartSetup;
        private int piTCPFeedBackDelay;
        private byte pbyteStartupFlagForDataLog;
        private byte pbyteStartupFlagForRealTimeTrend;


        private int piDataLogTimeCnt;
        private bool mbTCPInConnection;
        //private OleDbConnection dbConnection = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source = C:\All Projects\TriNet\TriNetApp\bin\x86\Debug\TrinetData.mdb");

        private OleDbConnection dbConnection; // = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source = C:\All Projects\TriNet\TriNetApp\bin\x86\Debug\TrinetData.mdb");

        //private int piTrendDataCnt;
        private int piRealTimeDataCnt;
        private DateTime[] pdtTrendTime= new DateTime[86400];
        private byte[] pbyteTrendSeriesNum= new byte[86400];
        private double[] pdTrendData = new double[86400];
        private int piTrendMinuteSpan;
        private int piTrendHourSpan;

        private int piMouseDownX, piMouseDownY;
        private int piMouseUpX, piMouseUpY;

        private double pdblMouseDownXValue;
        private double pdblMouseUpXValue;
        private double pdblMouseDownYValue;
        private double pdblMouseUpYValue;
        private Label label7;
        private Label label8;
        private TextBox textBox15;
        private Timer tmrCursorDispOffDelay;
        private GroupBox groupBox2;
        private TextBox textBox17;
        private Label label11;
        private TextBox textBox16;
        private Label label10;
        private Label label19;
        private Label lblTritium;
        private Label lblLastCommunication;
        private Label label9;

        private byte pbyteAlarmBits, pbyteWarningBits;
        private Timer tmrWarnSoundPlay;
        private Timer tmrAlarmSoundPlay;
        private Label label13;
        private Label label14;
        private ToolStripMenuItem connectToPLCToolStripMenuItem;
        private Label label1;
        private Label label6;
        private Label label12;
        private ListBox listBox1;
        private Timer tmrWarningFlashing;
        private Timer tmrAlarmFlashing;
        private Label lblBackgroundCancellationInfo;

        private bool pbWarningToggleBit, pbAlarmToggleBit;
        private Label lblDateTimeData;
        private Timer tmrTCPCommandOnLifeTime;
        private Timer tmrTCPCommandOffLifeTime;
        private Button button5;
        
        private int piTCPConnectionTried;



        //private System.Media.SoundPlayer player1;// = new System.Media.SoundPlayer(GlbByte.msCurrentDirName + @"\Windows Error.wav");
        private System.Media.SoundPlayer player1;// = new System.Media.SoundPlayer(GlbByte.msCurrentDirName + @"\Alarm10.wav");
        private Label label16;


        private byte mbyteWarningBits_Saved;
        private Button btnSilent;
        private Button button1;
        private ToolStripMenuItem exitToWindowsToolStripMenuItem;
        private System.IO.Ports.SerialPort serialPort1;
        private byte mbyteAlarmBits_Saved;

        private byte mbyteSlaveAddress;

        private byte_array UnionData;
        private Timer tmrSerialDataReceivingEndDetection;
        private Short_array mShortUnion;

        private byte[] arrByteRXBuf = new byte[1000];
        private int piUartReceivedCnt;
        private bool pbUartReceived;
        private Chart chart1;
        private Panel panel1;
        private Label lblSent;
        private Label lblReceived;
        private Label lblSent2;
        private Label lblSent3;
        private int piUartReceivedCnt_SAVED;

        private frmInstrumentSetup frmInstrumentSetup1;
        private frmStatus frmStatus1;

        //private System.Media.SoundPlayer player2; //= new System.Media.SoundPlayer(GlbByte.msCurrentDirName + @"\Alarm10.wav");
        public frmStart()
        {
            InitializeComponent();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code
        /// <summary>
        /// Erforderliche Methode f�r die Designerunterst�tzung. 
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor ge�ndert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea5 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend5 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series5 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.grpData = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.grpExchange = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtUnit = new System.Windows.Forms.TextBox();
            this.btnWriteMultipleReg = new System.Windows.Forms.Button();
            this.btnWriteMultipleCoils = new System.Windows.Forms.Button();
            this.btnWriteSingleReg = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radWord = new System.Windows.Forms.RadioButton();
            this.radBytes = new System.Windows.Forms.RadioButton();
            this.label19 = new System.Windows.Forms.Label();
            this.btnWriteSingleCoil = new System.Windows.Forms.Button();
            this.btnReadInpReg = new System.Windows.Forms.Button();
            this.btnReadHoldReg = new System.Windows.Forms.Button();
            this.btnReadDisInp = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.txtSize = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtStartAdress = new System.Windows.Forms.TextBox();
            this.btnReadCoils = new System.Windows.Forms.Button();
            this.radBits = new System.Windows.Forms.RadioButton();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.controlToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.controlToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToWindowsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.setupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.connectToPLCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TaskTick = new System.Windows.Forms.Timer(this.components);
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.tmrCursorDispOffDelay = new System.Windows.Forms.Timer(this.components);
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lblTritium = new System.Windows.Forms.Label();
            this.lblLastCommunication = new System.Windows.Forms.Label();
            this.lblBackgroundCancellationInfo = new System.Windows.Forms.Label();
            this.tmrWarnSoundPlay = new System.Windows.Forms.Timer(this.components);
            this.tmrAlarmSoundPlay = new System.Windows.Forms.Timer(this.components);
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.tmrWarningFlashing = new System.Windows.Forms.Timer(this.components);
            this.tmrAlarmFlashing = new System.Windows.Forms.Timer(this.components);
            this.lblDateTimeData = new System.Windows.Forms.Label();
            this.tmrTCPCommandOnLifeTime = new System.Windows.Forms.Timer(this.components);
            this.tmrTCPCommandOffLifeTime = new System.Windows.Forms.Timer(this.components);
            this.button5 = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.btnSilent = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.tmrSerialDataReceivingEndDetection = new System.Windows.Forms.Timer(this.components);
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblSent = new System.Windows.Forms.Label();
            this.lblReceived = new System.Windows.Forms.Label();
            this.lblSent2 = new System.Windows.Forms.Label();
            this.lblSent3 = new System.Windows.Forms.Label();
            this.grpExchange.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.SuspendLayout();
            // 
            // grpData
            // 
            this.grpData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grpData.Location = new System.Drawing.Point(1115, 1);
            this.grpData.Name = "grpData";
            this.grpData.Size = new System.Drawing.Size(431, 56);
            this.grpData.TabIndex = 9;
            this.grpData.TabStop = false;
            this.grpData.Text = "``";
            this.grpData.Visible = false;
            this.grpData.Enter += new System.EventHandler(this.grpData_Enter);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Font = new System.Drawing.Font("Arial", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Purple;
            this.label5.Location = new System.Drawing.Point(253, 377);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(541, 32);
            this.label5.TabIndex = 9;
            this.label5.Text = "Connecting to Com Port ... Please Wait !";
            this.label5.Visible = false;
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // grpExchange
            // 
            this.grpExchange.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grpExchange.Controls.Add(this.label4);
            this.grpExchange.Controls.Add(this.txtUnit);
            this.grpExchange.Controls.Add(this.btnWriteMultipleReg);
            this.grpExchange.Controls.Add(this.btnWriteMultipleCoils);
            this.grpExchange.Controls.Add(this.btnWriteSingleReg);
            this.grpExchange.Controls.Add(this.groupBox1);
            this.grpExchange.Controls.Add(this.btnWriteSingleCoil);
            this.grpExchange.Controls.Add(this.btnReadInpReg);
            this.grpExchange.Controls.Add(this.btnReadHoldReg);
            this.grpExchange.Controls.Add(this.btnReadDisInp);
            this.grpExchange.Controls.Add(this.label3);
            this.grpExchange.Controls.Add(this.txtSize);
            this.grpExchange.Controls.Add(this.label2);
            this.grpExchange.Controls.Add(this.txtStartAdress);
            this.grpExchange.Controls.Add(this.btnReadCoils);
            this.grpExchange.Location = new System.Drawing.Point(1095, 12);
            this.grpExchange.Name = "grpExchange";
            this.grpExchange.Size = new System.Drawing.Size(431, 20);
            this.grpExchange.TabIndex = 12;
            this.grpExchange.TabStop = false;
            this.grpExchange.Text = "Data exhange";
            this.grpExchange.Visible = false;
            this.grpExchange.Enter += new System.EventHandler(this.grpExchange_Enter);
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(13, 27);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(17, 10);
            this.label4.TabIndex = 25;
            this.label4.Text = "Unit";
            // 
            // txtUnit
            // 
            this.txtUnit.Location = new System.Drawing.Point(87, 25);
            this.txtUnit.Name = "txtUnit";
            this.txtUnit.Size = new System.Drawing.Size(50, 20);
            this.txtUnit.TabIndex = 24;
            this.txtUnit.Text = "0";
            this.txtUnit.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnWriteMultipleReg
            // 
            this.btnWriteMultipleReg.Location = new System.Drawing.Point(573, 76);
            this.btnWriteMultipleReg.Name = "btnWriteMultipleReg";
            this.btnWriteMultipleReg.Size = new System.Drawing.Size(87, 44);
            this.btnWriteMultipleReg.TabIndex = 23;
            this.btnWriteMultipleReg.Text = "Write multiple register";
            this.btnWriteMultipleReg.Click += new System.EventHandler(this.btnWriteMultipleReg_Click);
            // 
            // btnWriteMultipleCoils
            // 
            this.btnWriteMultipleCoils.Location = new System.Drawing.Point(573, 28);
            this.btnWriteMultipleCoils.Name = "btnWriteMultipleCoils";
            this.btnWriteMultipleCoils.Size = new System.Drawing.Size(87, 42);
            this.btnWriteMultipleCoils.TabIndex = 22;
            this.btnWriteMultipleCoils.Text = "Write multiple coils";
            this.btnWriteMultipleCoils.Click += new System.EventHandler(this.btnWriteMultipleCoils_Click);
            // 
            // btnWriteSingleReg
            // 
            this.btnWriteSingleReg.Location = new System.Drawing.Point(473, 76);
            this.btnWriteSingleReg.Name = "btnWriteSingleReg";
            this.btnWriteSingleReg.Size = new System.Drawing.Size(87, 44);
            this.btnWriteSingleReg.TabIndex = 21;
            this.btnWriteSingleReg.Text = "Write single register";
            this.btnWriteSingleReg.Click += new System.EventHandler(this.btnWriteSingleReg_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radWord);
            this.groupBox1.Controls.Add(this.radBytes);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Location = new System.Drawing.Point(160, 21);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(87, 90);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Show as";
            // 
            // radWord
            // 
            this.radWord.Location = new System.Drawing.Point(13, 62);
            this.radWord.Name = "radWord";
            this.radWord.Size = new System.Drawing.Size(67, 21);
            this.radWord.TabIndex = 2;
            this.radWord.Text = "Word";
            this.radWord.CheckedChanged += new System.EventHandler(this.ShowAs);
            // 
            // radBytes
            // 
            this.radBytes.Location = new System.Drawing.Point(13, 42);
            this.radBytes.Name = "radBytes";
            this.radBytes.Size = new System.Drawing.Size(67, 20);
            this.radBytes.TabIndex = 1;
            this.radBytes.Text = "Bytes";
            this.radBytes.CheckedChanged += new System.EventHandler(this.ShowAs);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.White;
            this.label19.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(-33, -5);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(107, 22);
            this.label19.TabIndex = 82;
            this.label19.Text = "Location 3";
            // 
            // btnWriteSingleCoil
            // 
            this.btnWriteSingleCoil.Location = new System.Drawing.Point(473, 28);
            this.btnWriteSingleCoil.Name = "btnWriteSingleCoil";
            this.btnWriteSingleCoil.Size = new System.Drawing.Size(87, 42);
            this.btnWriteSingleCoil.TabIndex = 19;
            this.btnWriteSingleCoil.Text = "Write single coil";
            this.btnWriteSingleCoil.Click += new System.EventHandler(this.btnWriteSingleCoil_Click);
            // 
            // btnReadInpReg
            // 
            this.btnReadInpReg.Location = new System.Drawing.Point(373, 76);
            this.btnReadInpReg.Name = "btnReadInpReg";
            this.btnReadInpReg.Size = new System.Drawing.Size(87, 44);
            this.btnReadInpReg.TabIndex = 18;
            this.btnReadInpReg.Text = "Read input register";
            this.btnReadInpReg.Click += new System.EventHandler(this.btnReadInpReg_Click);
            // 
            // btnReadHoldReg
            // 
            this.btnReadHoldReg.Location = new System.Drawing.Point(373, 28);
            this.btnReadHoldReg.Name = "btnReadHoldReg";
            this.btnReadHoldReg.Size = new System.Drawing.Size(87, 42);
            this.btnReadHoldReg.TabIndex = 17;
            this.btnReadHoldReg.Text = "Read holding register";
            this.btnReadHoldReg.Click += new System.EventHandler(this.btnReadHoldReg_Click);
            // 
            // btnReadDisInp
            // 
            this.btnReadDisInp.Location = new System.Drawing.Point(273, 76);
            this.btnReadDisInp.Name = "btnReadDisInp";
            this.btnReadDisInp.Size = new System.Drawing.Size(87, 44);
            this.btnReadDisInp.TabIndex = 16;
            this.btnReadDisInp.Text = "Read discrete inputs";
            this.btnReadDisInp.Click += new System.EventHandler(this.btnReadDisInp_Click);
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(13, 78);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 14);
            this.label3.TabIndex = 15;
            this.label3.Text = "Size";
            // 
            // txtSize
            // 
            this.txtSize.Location = new System.Drawing.Point(87, 78);
            this.txtSize.Name = "txtSize";
            this.txtSize.Size = new System.Drawing.Size(50, 20);
            this.txtSize.TabIndex = 14;
            this.txtSize.Text = "100";
            this.txtSize.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(13, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 14);
            this.label2.TabIndex = 13;
            this.label2.Text = "Start Adress";
            // 
            // txtStartAdress
            // 
            this.txtStartAdress.Location = new System.Drawing.Point(87, 51);
            this.txtStartAdress.Name = "txtStartAdress";
            this.txtStartAdress.Size = new System.Drawing.Size(50, 20);
            this.txtStartAdress.TabIndex = 12;
            this.txtStartAdress.Text = "0";
            this.txtStartAdress.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnReadCoils
            // 
            this.btnReadCoils.Location = new System.Drawing.Point(273, 28);
            this.btnReadCoils.Name = "btnReadCoils";
            this.btnReadCoils.Size = new System.Drawing.Size(87, 42);
            this.btnReadCoils.TabIndex = 11;
            this.btnReadCoils.Text = "Read coils";
            this.btnReadCoils.CursorChanged += new System.EventHandler(this.btnReadCoils_Click);
            this.btnReadCoils.Click += new System.EventHandler(this.btnReadCoils_Click);
            // 
            // radBits
            // 
            this.radBits.Location = new System.Drawing.Point(1064, 8);
            this.radBits.Name = "radBits";
            this.radBits.Size = new System.Drawing.Size(11, 21);
            this.radBits.TabIndex = 0;
            this.radBits.Text = "Bits";
            this.radBits.Visible = false;
            this.radBits.CheckedChanged += new System.EventHandler(this.ShowAs);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.controlToolStripMenuItem,
            this.setupToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1695, 30);
            this.menuStrip1.TabIndex = 13;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked_2);
            // 
            // controlToolStripMenuItem
            // 
            this.controlToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.statusToolStripMenuItem,
            this.controlToolStripMenuItem1,
            this.exitToWindowsToolStripMenuItem});
            this.controlToolStripMenuItem.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.controlToolStripMenuItem.Name = "controlToolStripMenuItem";
            this.controlToolStripMenuItem.Size = new System.Drawing.Size(140, 26);
            this.controlToolStripMenuItem.Text = "Status/Setup";
            // 
            // statusToolStripMenuItem
            // 
            this.statusToolStripMenuItem.Name = "statusToolStripMenuItem";
            this.statusToolStripMenuItem.Size = new System.Drawing.Size(260, 26);
            this.statusToolStripMenuItem.Text = "Status of Controller";
            this.statusToolStripMenuItem.Click += new System.EventHandler(this.statusToolStripMenuItem_Click);
            // 
            // controlToolStripMenuItem1
            // 
            this.controlToolStripMenuItem1.Name = "controlToolStripMenuItem1";
            this.controlToolStripMenuItem1.Size = new System.Drawing.Size(260, 26);
            this.controlToolStripMenuItem1.Text = "Setup Controller";
            this.controlToolStripMenuItem1.Click += new System.EventHandler(this.controlToolStripMenuItem1_Click);
            // 
            // exitToWindowsToolStripMenuItem
            // 
            this.exitToWindowsToolStripMenuItem.Name = "exitToWindowsToolStripMenuItem";
            this.exitToWindowsToolStripMenuItem.Size = new System.Drawing.Size(260, 26);
            this.exitToWindowsToolStripMenuItem.Text = "Exit to Windows";
            this.exitToWindowsToolStripMenuItem.Click += new System.EventHandler(this.exitToWindowsToolStripMenuItem_Click);
            // 
            // setupToolStripMenuItem
            // 
            this.setupToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.connectToPLCToolStripMenuItem});
            this.setupToolStripMenuItem.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.setupToolStripMenuItem.Name = "setupToolStripMenuItem";
            this.setupToolStripMenuItem.Size = new System.Drawing.Size(168, 26);
            this.setupToolStripMenuItem.Text = "Communication";
            this.setupToolStripMenuItem.Click += new System.EventHandler(this.setupToolStripMenuItem_Click);
            // 
            // connectToPLCToolStripMenuItem
            // 
            this.connectToPLCToolStripMenuItem.Name = "connectToPLCToolStripMenuItem";
            this.connectToPLCToolStripMenuItem.Size = new System.Drawing.Size(530, 26);
            this.connectToPLCToolStripMenuItem.Text = "Update COM Number and Modbus Node Address";
            this.connectToPLCToolStripMenuItem.Click += new System.EventHandler(this.connectToPLCToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(63, 26);
            this.helpToolStripMenuItem.Text = "Help";
            this.helpToolStripMenuItem.Click += new System.EventHandler(this.helpToolStripMenuItem_Click);
            // 
            // TaskTick
            // 
            this.TaskTick.Enabled = true;
            this.TaskTick.Interval = 500;
            this.TaskTick.Tick += new System.EventHandler(this.TaskTick_Tick);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label7.Font = new System.Drawing.Font("Arial", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.MediumBlue;
            this.label7.Location = new System.Drawing.Point(273, 266);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(746, 37);
            this.label7.TabIndex = 61;
            this.label7.Text = "CableVue Peripherial Test  Software Version 1.3";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label8.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.MediumBlue;
            this.label8.Location = new System.Drawing.Point(409, 316);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(137, 22);
            this.label8.TabIndex = 62;
            this.label8.Text = "Kinectrics Inc";
            // 
            // textBox15
            // 
            this.textBox15.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox15.Location = new System.Drawing.Point(5, 60);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(126, 21);
            this.textBox15.TabIndex = 63;
            // 
            // tmrCursorDispOffDelay
            // 
            this.tmrCursorDispOffDelay.Interval = 10000;
            this.tmrCursorDispOffDelay.Tick += new System.EventHandler(this.tmrCursorDispOffDelay_Tick);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textBox17);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.textBox16);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.textBox15);
            this.groupBox2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(858, 609);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(136, 192);
            this.groupBox2.TabIndex = 64;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Cusor Value";
            this.groupBox2.Visible = false;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(8, 161);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(101, 26);
            this.textBox17.TabIndex = 68;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(7, 138);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(113, 19);
            this.label11.TabIndex = 67;
            this.label11.Text = "Tritium Value:";
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(11, 109);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(50, 26);
            this.textBox16.TabIndex = 66;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(7, 86);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(82, 19);
            this.label10.TabIndex = 65;
            this.label10.Text = "Location:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(7, 36);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(91, 19);
            this.label9.TabIndex = 64;
            this.label9.Text = "Date/Time:";
            // 
            // lblTritium
            // 
            this.lblTritium.AutoSize = true;
            this.lblTritium.BackColor = System.Drawing.Color.White;
            this.lblTritium.Font = new System.Drawing.Font("Arial", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTritium.Location = new System.Drawing.Point(983, 316);
            this.lblTritium.Name = "lblTritium";
            this.lblTritium.Size = new System.Drawing.Size(0, 32);
            this.lblTritium.TabIndex = 86;
            // 
            // lblLastCommunication
            // 
            this.lblLastCommunication.AutoSize = true;
            this.lblLastCommunication.BackColor = System.Drawing.Color.Yellow;
            this.lblLastCommunication.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblLastCommunication.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLastCommunication.ForeColor = System.Drawing.Color.Blue;
            this.lblLastCommunication.Location = new System.Drawing.Point(168, 872);
            this.lblLastCommunication.Name = "lblLastCommunication";
            this.lblLastCommunication.Size = new System.Drawing.Size(232, 28);
            this.lblLastCommunication.TabIndex = 88;
            this.lblLastCommunication.Text = "Lost Communication!";
            this.lblLastCommunication.Visible = false;
            // 
            // lblBackgroundCancellationInfo
            // 
            this.lblBackgroundCancellationInfo.AutoSize = true;
            this.lblBackgroundCancellationInfo.BackColor = System.Drawing.Color.Transparent;
            this.lblBackgroundCancellationInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblBackgroundCancellationInfo.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBackgroundCancellationInfo.ForeColor = System.Drawing.Color.Blue;
            this.lblBackgroundCancellationInfo.Location = new System.Drawing.Point(406, 884);
            this.lblBackgroundCancellationInfo.Name = "lblBackgroundCancellationInfo";
            this.lblBackgroundCancellationInfo.Size = new System.Drawing.Size(572, 28);
            this.lblBackgroundCancellationInfo.TabIndex = 89;
            this.lblBackgroundCancellationInfo.Text = "BackGround cancellation is in processing, Please wait!";
            this.lblBackgroundCancellationInfo.Visible = false;
            // 
            // tmrWarnSoundPlay
            // 
            this.tmrWarnSoundPlay.Interval = 5000;
            this.tmrWarnSoundPlay.Tick += new System.EventHandler(this.tmrWarnSoundPlay_Tick);
            // 
            // tmrAlarmSoundPlay
            // 
            this.tmrAlarmSoundPlay.Interval = 5000;
            this.tmrAlarmSoundPlay.Tick += new System.EventHandler(this.tmrAlarmSoundPlay_Tick);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Red;
            this.label13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label13.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Blue;
            this.label13.Location = new System.Drawing.Point(209, 884);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(145, 28);
            this.label13.TabIndex = 90;
            this.label13.Text = "Tritium High!";
            this.label13.Visible = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Yellow;
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label14.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Blue;
            this.label14.Location = new System.Drawing.Point(329, 884);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(128, 28);
            this.label14.TabIndex = 91;
            this.label14.Text = "Flow Low !";
            this.label14.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("Arial", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(600, 834);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 32);
            this.label1.TabIndex = 92;
            this.label1.Text = "0";
            this.label1.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Font = new System.Drawing.Font("Arial", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(135, 835);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 32);
            this.label6.TabIndex = 93;
            this.label6.Text = "0.0";
            this.label6.Visible = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.White;
            this.label12.Font = new System.Drawing.Font("Arial", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(290, 834);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(113, 32);
            this.label12.TabIndex = 94;
            this.label12.Text = "Comp.:";
            this.label12.Visible = false;
            // 
            // listBox1
            // 
            this.listBox1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Location = new System.Drawing.Point(1014, 33);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(238, 836);
            this.listBox1.TabIndex = 95;
            this.listBox1.Visible = false;
            // 
            // tmrWarningFlashing
            // 
            this.tmrWarningFlashing.Interval = 500;
            this.tmrWarningFlashing.Tick += new System.EventHandler(this.tmrWarningFlashing_Tick);
            // 
            // tmrAlarmFlashing
            // 
            this.tmrAlarmFlashing.Interval = 500;
            this.tmrAlarmFlashing.Tick += new System.EventHandler(this.tmrAlarmFlashing_Tick);
            // 
            // lblDateTimeData
            // 
            this.lblDateTimeData.AutoSize = true;
            this.lblDateTimeData.BackColor = System.Drawing.Color.White;
            this.lblDateTimeData.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDateTimeData.ForeColor = System.Drawing.Color.Blue;
            this.lblDateTimeData.Location = new System.Drawing.Point(741, 837);
            this.lblDateTimeData.Name = "lblDateTimeData";
            this.lblDateTimeData.Size = new System.Drawing.Size(206, 29);
            this.lblDateTimeData.TabIndex = 96;
            this.lblDateTimeData.Text = "00-00-00 00:00:00";
            this.lblDateTimeData.Visible = false;
            this.lblDateTimeData.Click += new System.EventHandler(this.label15_Click);
            // 
            // tmrTCPCommandOnLifeTime
            // 
            this.tmrTCPCommandOnLifeTime.Interval = 1000;
            this.tmrTCPCommandOnLifeTime.Tick += new System.EventHandler(this.tmrTCPCommandOnLifeTime_Tick);
            // 
            // tmrTCPCommandOffLifeTime
            // 
            this.tmrTCPCommandOffLifeTime.Interval = 1500;
            this.tmrTCPCommandOffLifeTime.Tick += new System.EventHandler(this.tmrTCPCommandOffLifeTime_Tick);
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("Arial Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(1483, 834);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(172, 28);
            this.button5.TabIndex = 97;
            this.button5.Text = "Exit to Windows";
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.White;
            this.label16.Font = new System.Drawing.Font("Arial", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(12, 835);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(128, 32);
            this.label16.TabIndex = 99;
            this.label16.Text = "Gamma:";
            this.label16.Visible = false;
            // 
            // btnSilent
            // 
            this.btnSilent.Font = new System.Drawing.Font("Arial Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSilent.Location = new System.Drawing.Point(984, 884);
            this.btnSilent.Name = "btnSilent";
            this.btnSilent.Size = new System.Drawing.Size(85, 28);
            this.btnSilent.TabIndex = 100;
            this.btnSilent.Text = "Silent";
            this.btnSilent.Visible = false;
            this.btnSilent.Click += new System.EventHandler(this.btnSilent_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(656, 870);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(135, 29);
            this.button1.TabIndex = 101;
            this.button1.Text = "Show Virtue Keyboard";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // serialPort1
            // 
            this.serialPort1.BaudRate = 115200;
            this.serialPort1.PortName = "COM19";
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort1_DataReceived);
            // 
            // tmrSerialDataReceivingEndDetection
            // 
            this.tmrSerialDataReceivingEndDetection.Interval = 50;
            this.tmrSerialDataReceivingEndDetection.Tick += new System.EventHandler(this.tmrSerialDataReceivingEndDetection_Tick);
            // 
            // chart1
            // 
            this.chart1.BorderlineWidth = 2;
            chartArea5.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea5);
            legend5.Name = "Legend1";
            this.chart1.Legends.Add(legend5);
            this.chart1.Location = new System.Drawing.Point(6, 33);
            this.chart1.Name = "chart1";
            series5.ChartArea = "ChartArea1";
            series5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            series5.Legend = "Legend1";
            series5.Name = "Series1";
            this.chart1.Series.Add(series5);
            this.chart1.Size = new System.Drawing.Size(1002, 836);
            this.chart1.TabIndex = 45;
            this.chart1.Text = "chart1";
            this.chart1.Visible = false;
            this.chart1.Click += new System.EventHandler(this.chart1_Click_1);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Window;
            this.panel1.Location = new System.Drawing.Point(886, 52);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(91, 38);
            this.panel1.TabIndex = 102;
            this.panel1.Visible = false;
            // 
            // lblSent
            // 
            this.lblSent.AutoSize = true;
            this.lblSent.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblSent.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSent.ForeColor = System.Drawing.Color.Blue;
            this.lblSent.Location = new System.Drawing.Point(26, 843);
            this.lblSent.Name = "lblSent";
            this.lblSent.Size = new System.Drawing.Size(50, 19);
            this.lblSent.TabIndex = 103;
            this.lblSent.Text = "Sent:";
            // 
            // lblReceived
            // 
            this.lblReceived.AutoSize = true;
            this.lblReceived.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblReceived.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReceived.ForeColor = System.Drawing.Color.Black;
            this.lblReceived.Location = new System.Drawing.Point(26, 893);
            this.lblReceived.Name = "lblReceived";
            this.lblReceived.Size = new System.Drawing.Size(86, 19);
            this.lblReceived.TabIndex = 104;
            this.lblReceived.Text = "Received:";
            // 
            // lblSent2
            // 
            this.lblSent2.AutoSize = true;
            this.lblSent2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblSent2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSent2.ForeColor = System.Drawing.Color.Blue;
            this.lblSent2.Location = new System.Drawing.Point(62, 862);
            this.lblSent2.Name = "lblSent2";
            this.lblSent2.Size = new System.Drawing.Size(0, 19);
            this.lblSent2.TabIndex = 105;
            // 
            // lblSent3
            // 
            this.lblSent3.AutoSize = true;
            this.lblSent3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblSent3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSent3.ForeColor = System.Drawing.Color.Blue;
            this.lblSent3.Location = new System.Drawing.Point(68, 862);
            this.lblSent3.Name = "lblSent3";
            this.lblSent3.Size = new System.Drawing.Size(15, 19);
            this.lblSent3.TabIndex = 106;
            this.lblSent3.Text = ":";
            // 
            // frmStart
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.BackColor = System.Drawing.Color.MediumTurquoise;
            this.ClientSize = new System.Drawing.Size(1695, 933);
            this.ControlBox = false;
            this.Controls.Add(this.lblSent3);
            this.Controls.Add(this.lblSent2);
            this.Controls.Add(this.lblReceived);
            this.Controls.Add(this.lblSent);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnSilent);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.lblBackgroundCancellationInfo);
            this.Controls.Add(this.radBits);
            this.Controls.Add(this.lblDateTimeData);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.lblLastCommunication);
            this.Controls.Add(this.lblTritium);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.chart1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.grpData);
            this.Controls.Add(this.grpExchange);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmStart";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Kinectrics CableVuw Peripherial";
            this.Closing += new System.ComponentModel.CancelEventHandler(this.frmStart_Closing);
            this.Load += new System.EventHandler(this.frmStart_Load);
            this.grpExchange.ResumeLayout(false);
            this.grpExchange.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        /// <summary>
        /// Der Haupteinstiegspunkt f�r die Anwendung.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.Run(new frmStart());
        }


        // ------------------------------------------------------------------------
        // Programm start
        // ------------------------------------------------------------------------
        private void frmStart_Load(object sender, System.EventArgs e)
        {
            // Set standard format byte, make some textboxes
            radBytes.Checked = true;
            data = new byte[0];
            string msConfigFile;
            //ResizeData();

            GlbByte.GbyteTCPConnected = 0;
            glbData.ValueToShare = 100;
            GlbByte.GbyteTCPReadRequested = 0;
            GlbByte.gByteTCPWriteReq = 0;

            piTCPConnectionTried = 0;
            GlbByte.GbyteLoggedIn = 0;
            GlbByte.giSavedDataPointer = 0;
            GlbByte.gbSavedDataFull = false;
            pbChartSetup = false;
            piRealTimeDataCnt = 0;
            piTrendHourSpan = 4;
            piDataLogTimeCnt = 0;
            pbyteStartupFlagForDataLog = 1;
            pbyteStartupFlagForRealTimeTrend= 1;
            GlbByte.GbyteRealTimeTrendRefreshReq = 0;
            GlbByte.msCurrentDirName = System.IO.Directory.GetCurrentDirectory();// + @"\SystemCfg.txt";

            msConfigFile = GlbByte.msCurrentDirName + @"\SystemCfg.txt";
            // Read the file and display it line by line.  
            System.IO.StreamReader file =
                new System.IO.StreamReader(msConfigFile);// (msCurrentDirName);

            GlbByte.msIPAddress = file.ReadLine();
            GlbByte.miHistSaveInterval = Int32.Parse(file.ReadLine());
            GlbByte.giPassword = Int32.Parse(file.ReadLine());
            GlbByte.giLocationSelect = Int32.Parse(file.ReadLine());
            GlbByte.giLocationTimmingArry[0] = Int32.Parse(file.ReadLine());
            GlbByte.giLocationTimmingArry[1] = Int32.Parse(file.ReadLine());
            GlbByte.giLocationTimmingArry[2] = Int32.Parse(file.ReadLine());
            GlbByte.giLocationTimmingArry[3] = Int32.Parse(file.ReadLine());
            GlbByte.giLocationTimmingArry[4] = Int32.Parse(file.ReadLine());
            GlbByte.giEngineeringUnitSelected = Int32.Parse(file.ReadLine());

            GlbByte.gstrEngUnit[0] = "�Ci/m3";
            GlbByte.gstrEngUnit[1] = "MPC(a)";
            GlbByte.gstrEngUnit[2] = "MBq/m";
            GlbByte.gstrEngUnit[3] = "DAC";
            GlbByte.gstrEngUnit[4] = "mRem/h";



            GlbByte.gdblEngUnitFactor[0] = 1.0;
            GlbByte.gdblEngUnitFactor[1] = 0.1;
            GlbByte.gdblEngUnitFactor[2] = 0.037;
            GlbByte.gdblEngUnitFactor[3] = 0.116;//default
            GlbByte.gdblEngUnitFactor[4] = 0.120;

            if (GlbByte.miHistSaveInterval < 0)
                GlbByte.miHistSaveInterval = 0;

            file.Close();
            //txtIP.Text = GlbByte.msIPAddress;
            //textBox1.Text = GlbByte.miHistSaveInterval.ToString();

            mbyteSlaveAddress = 0;

            dbConnection = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source = " + GlbByte.msCurrentDirName +@"\TrinetData.mdb");
            dbConnection.Open();

            player1 = new System.Media.SoundPlayer(GlbByte.msCurrentDirName + @"\Alarm10.wav");

            try
            {
                serialPort1.PortName = GlbByte.msIPAddress;

                serialPort1.Open();
                GlbByte.GbyteTCPConnected = 1;
            }
            catch (Exception exxx)
            {
                Console.WriteLine("Tried to Open COM9 Port, Exception: " + exxx.Message);
                GlbByte.GbyteTCPConnected = 0;
            }


        }

        // ------------------------------------------------------------------------
        // Programm stop ----------------------------------------------
        private void frmStart_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (MBmaster != null)
            {
                MBmaster.Dispose();
                MBmaster = null;
            }
            Application.Exit();
        }

        // ------------------------------------------------------------------------
        // Button connect
        // ------------------------------------------------------------------------
        private void btnConnect_Click(object sender, System.EventArgs e)
        {
            // Commented to remove TCP/IP Modbus 
            //connectTCP();

            try
            {
                serialPort1.Open();
                GlbByte.GbyteTCPConnected = 1;
            }
            catch (Exception exxx)
            {
                GlbByte.GbyteTCPConnected = 0;
                Console.WriteLine("Tried to Open COM Port, Exception: " + exxx.Message);

            }

        }


        public void connectTCP()
        {

            //mbTCPInConnection = true;
           
            int i;
            bool bTCPConnected;
            bTCPConnected = false;
            for (i = 0; i < 2; i++)
            {
                try
                {
                    // Create new modbus master and add event functions                   
                    MBmaster = new Master(GlbByte.msIPAddress, 502, true);
                    MBmaster.OnResponseData += new ModbusTCP.Master.ResponseData(MBmaster_OnResponseData);
                    MBmaster.OnException += new ModbusTCP.Master.ExceptionData(MBmaster_OnException);
                    bTCPConnected = true;
                    piTCPConnectionTried = 0;
                   

                    GlbByte.GbyteTCPConnected = 1;
                }
                catch (SystemException error)
                {
                    piTCPConnectionTried++;
                    if(i!=0)
                        MessageBox.Show(error.Message + " !  Tried " + (i+1).ToString() + " of 2" );
                }

                if (bTCPConnected == true)
                    break;
                


            }
           // mbTCPInConnection = false;
            //label5.Visible = false;



        }

        // ------------------------------------------------------------------------
        // Button read coils
        // ------------------------------------------------------------------------
        private void btnReadCoils_Click(object sender, System.EventArgs e)
		{
			ushort ID			= 1;
            byte unit           = Convert.ToByte(txtUnit.Text);
            ushort StartAddress = ReadStartAdr();
            UInt16 Length = Convert.ToUInt16(txtSize.Text);

            MBmaster.ReadCoils(ID, unit, StartAddress, Length);
		}

		// ------------------------------------------------------------------------
		// Button read discrete inputs
		// ------------------------------------------------------------------------
		private void btnReadDisInp_Click(object sender, System.EventArgs e)
		{
			ushort ID			= 2;
            byte unit           = Convert.ToByte(txtUnit.Text);
            ushort StartAddress = ReadStartAdr();
            UInt16 Length = Convert.ToUInt16(txtSize.Text);

			MBmaster.ReadDiscreteInputs(ID, unit, StartAddress, Length);	
		}

		// ------------------------------------------------------------------------
		// Button read holding register
		// ------------------------------------------------------------------------
		private void btnReadHoldReg_Click(object sender, System.EventArgs e)
		{
			ushort ID			= 3;
            byte unit           = Convert.ToByte(txtUnit.Text);
            ushort StartAddress = ReadStartAdr();
			UInt16 Length		= Convert.ToUInt16(txtSize.Text);

			MBmaster.ReadHoldingRegister(ID, unit, StartAddress, Length);		
		}

		// ------------------------------------------------------------------------
		// Button read holding register
		// ------------------------------------------------------------------------
		private void btnReadInpReg_Click(object sender, System.EventArgs e)
		{
			ushort ID			= 4;
            byte unit           = Convert.ToByte(txtUnit.Text);
            ushort StartAddress = ReadStartAdr();
            UInt16 Length       = Convert.ToUInt16(txtSize.Text);

			MBmaster.ReadInputRegister(ID, unit, StartAddress, Length);			
		}

		// ------------------------------------------------------------------------
		// Button write single coil
		// ------------------------------------------------------------------------
		private void btnWriteSingleCoil_Click(object sender, System.EventArgs e)
		{
			ushort ID			= 5;
            byte unit           = Convert.ToByte(txtUnit.Text);
            ushort StartAddress = ReadStartAdr();

			data			= GetData(1);
			txtSize.Text	= "1";

			MBmaster.WriteSingleCoils(ID, unit, StartAddress, Convert.ToBoolean(data[0]));
		}

		// ------------------------------------------------------------------------
		// Button write multiple coils
		// ------------------------------------------------------------------------	
		private void btnWriteMultipleCoils_Click(object sender, System.EventArgs e)
		{
			ushort ID			= 6;
            byte unit           = Convert.ToByte(txtUnit.Text);
            ushort StartAddress = ReadStartAdr();
            UInt16 Length = Convert.ToUInt16(txtSize.Text);

            data = GetData(Convert.ToUInt16(txtSize.Text));
			MBmaster.WriteMultipleCoils(ID, unit, StartAddress, Length, data);		
		}

		// ------------------------------------------------------------------------
		// Button write single register
		// ------------------------------------------------------------------------
		private void btnWriteSingleReg_Click(object sender, System.EventArgs e)
		{
			ushort ID			= 7;
            byte unit           = Convert.ToByte(txtUnit.Text);
            ushort StartAddress = ReadStartAdr();

			if (radBits.Checked) data = GetData(16);
            else if (radBytes.Checked) data = GetData(2);
            else data = GetData(1);
            txtSize.Text	= "1";
			txtData.Text	= data[0].ToString();

			MBmaster.WriteSingleRegister(ID, unit, StartAddress, data);
		}
		
		// ------------------------------------------------------------------------
		// Button write multiple register
		// ------------------------------------------------------------------------	
		private void btnWriteMultipleReg_Click(object sender, System.EventArgs e)
		{
			ushort ID			= 8;
            byte unit           = Convert.ToByte(txtUnit.Text);
            ushort StartAddress = ReadStartAdr();

			data = GetData(Convert.ToByte(txtSize.Text));
			MBmaster.WriteMultipleRegister(ID, unit, StartAddress, data);		
		}

		// ------------------------------------------------------------------------
		// Event for response data
		// ------------------------------------------------------------------------
		private void MBmaster_OnResponseData(ushort ID, byte unit, byte function, byte[] values)
		{
            // ------------------------------------------------------------------
            // Seperate calling threads
            if (this.InvokeRequired)
            {
                this.BeginInvoke(new Master.ResponseData(MBmaster_OnResponseData), new object[] { ID, unit, function, values });
                return;
            }

			// ------------------------------------------------------------------------
			// Identify requested data
			switch(ID)
			{
				case 1:
					//grpData.Text = "Read coils";
					//data = values;
					//ShowAs(null, null);
				break; 
				case 2:
					//grpData.Text = "Read discrete inputs";
					//data = values;
					//ShowAs(null, null);
				break;
				case 3:
					//grpData.Text = "Read holding register";
					//data = values;
					//ShowAs(null, null);
				break;
				case 4:
					//grpData.Text = "Read input register";
					data = values;
					ShowAs(null, null);
				break;
				case 5:
					//grpData.Text = "Write single coil";
				break;
				case 6:
					//grpData.Text = "Write multiple coils";
				break;
				case 7:
					//grpData.Text = "Write single register";
				break;
				case 8:
					//grpData.Text = "Write multiple register";
				break;
			}	
		}

		// ------------------------------------------------------------------------
		// Modbus TCP slave exception
		// ------------------------------------------------------------------------
		private void MBmaster_OnException(ushort id, byte unit, byte function, byte exception)
		{
			string exc = "Modbus says error: ";
			switch(exception)
			{
				case Master.excIllegalFunction: exc += "Illegal function!"; break;
				case Master.excIllegalDataAdr: exc += "Illegal data adress!"; break;
				case Master.excIllegalDataVal: exc += "Illegal data value!"; break;
				case Master.excSlaveDeviceFailure: exc += "Slave device failure!"; break;
				case Master.excAck: exc += "Acknoledge!"; break;
				case Master.excGatePathUnavailable: exc += "Gateway path unavailbale!"; break;
				case Master.excExceptionTimeout: exc += "Slave timed out!"; break;
				case Master.excExceptionConnectionLost: exc += "Connection is lost!"; break;
				case Master.excExceptionNotConnected: exc += "Not connected!"; break;
			}

			MessageBox.Show(exc, "Modbus slave exception");
		}

		// ------------------------------------------------------------------------
		// Generate new number of text boxes
		// ------------------------------------------------------------------------
		//private void ResizeData()
		//{
		//	// Create as many textboxes as fit into window
		//	grpData.Controls.Clear();
		//	int x = 0;
		//	int y = 10;
		//	int z = 20;
		//	while(y < grpData.Size.Width - 100)
		//	{
		//		labData				= new Label();
		//		grpData.Controls.Add(labData);
		//		labData.Size		= new System.Drawing.Size(30, 20);
		//		labData.Location	= new System.Drawing.Point(y, z);
		//		labData.Text		= Convert.ToString(x + 1);

		//		txtData				= new TextBox();
		//		grpData.Controls.Add(txtData);
		//		txtData.Size		= new System.Drawing.Size(50, 20);
		//		txtData.Location	= new System.Drawing.Point(y + 30, z);
		//		txtData.TextAlign	= System.Windows.Forms.HorizontalAlignment.Right;
		//		txtData.Tag			= x;

		//		x++;
		//		z = z + txtData.Size.Height + 5;
		//		if(z > grpData.Size.Height - 40) 
		//		{
		//			y = y + 100;
		//			z = 20;
		//		}
		//	}
		//}

		// ------------------------------------------------------------------------
		// Resize form elements
		// ------------------------------------------------------------------------
		//private void frmStart_Resize(object sender, System.EventArgs e)
		//{
		//	if(grpData.Visible == true) ResizeData();
		//}

		// ------------------------------------------------------------------------
		// Read start address
		// ------------------------------------------------------------------------
		private ushort ReadStartAdr()
		{
			// Convert hex numbers into decimal
			if(txtStartAdress.Text.IndexOf("0x", 0, txtStartAdress.Text.Length) == 0) 
			{
				string str = txtStartAdress.Text.Replace("0x", "");
				ushort hex = Convert.ToUInt16(str, 16);
				return hex;
			}
			else 
			{
				return Convert.ToUInt16(txtStartAdress.Text);
			}
		}

		// ------------------------------------------------------------------------
		// Read values from textboxes
		// ------------------------------------------------------------------------
		private byte[] GetData(int num)
		{
			bool[] bits	= new bool[num];
			byte[] data	= new Byte[num];
			int[]  word	= new int[num];

			// ------------------------------------------------------------------------
			// Convert data from text boxes
			foreach(Control ctrl in grpData.Controls)
			{
				if (ctrl is TextBox)
				{
					int x = Convert.ToInt16(ctrl.Tag);
					if(radBits.Checked)
					{
						if((x <= bits.GetUpperBound(0)) && (ctrl.Text != "")) bits[x] = Convert.ToBoolean(Convert.ToByte(ctrl.Text));
						else break;
					}
					if(radBytes.Checked)
					{
						if((x <= data.GetUpperBound(0)) && (ctrl.Text != "")) data[x] = Convert.ToByte(ctrl.Text);
						else break;
					}
					if(radWord.Checked)
					{
                        if ((x <= data.GetUpperBound(0)) && (ctrl.Text != ""))
                        {
                            try { word[x] = Convert.ToInt16(ctrl.Text); }
                            catch(SystemException) { word[x] = Convert.ToUInt16(ctrl.Text);};
                        }
                        else break;
					}
				}
			}
			if(radBits.Checked)
			{
				int numBytes		= (num / 8 + (num % 8 > 0 ? 1 : 0));
				data				= new Byte[numBytes];
				BitArray bitArray	= new BitArray(bits);
				bitArray.CopyTo(data, 0);
			}
			if(radWord.Checked)
			{
				data = new Byte[num*2];
				for(int x=0;x<num;x++)
				{
					byte[] dat = BitConverter.GetBytes((short) IPAddress.HostToNetworkOrder((short) word[x]));
					data[x*2]	= dat[0];
					data[x*2+1] = dat[1];
				}
			}
			return data;
		}

		// ------------------------------------------------------------------------
		// Show values in selected way
		// ------------------------------------------------------------------------
		private void ShowAs(object sender, System.EventArgs e)
		{
			RadioButton rad;
			if(sender is RadioButton)	
			{
				rad = (RadioButton) sender;
				if(rad.Checked == false) return;
			}

			bool[]	bits = new bool[1];
			int[]	word = new int[1];

			// Convert data to selected data type
			if(radBits.Checked == true)
			{
				BitArray bitArray = new BitArray(data);
				bits = new bool[bitArray.Count];
				bitArray.CopyTo(bits, 0);
			}
			if(radWord.Checked == true)
			{
				if(data.Length < 2) return;
                int length = data.Length / 2 + Convert.ToInt16(data.Length % 2 > 0);      
                word = new int[length];
				for(int x=0;x<length; x=x+2)
				{
					word[x/2] = data[x] * 256 + data[x+1];
				}
			}

			// ------------------------------------------------------------------------
			// Put new data into text boxes
			foreach(Control ctrl in grpData.Controls)
			{
				if (ctrl is TextBox)
				{
					int x = Convert.ToInt16(ctrl.Tag);
					if(radBits.Checked)
					{
						if(x <= bits.GetUpperBound(0)) 
						{
							ctrl.Text = Convert.ToByte(bits[x]).ToString();
							ctrl.Visible = true;
						}
						else ctrl.Text = "";
					}
                    if (radBytes.Checked)
                    {
                        if (x <= data.GetUpperBound(0))
                        {
                            ctrl.Text = data[x].ToString();
                            ctrl.Visible = true;
                        }
                        else ctrl.Text = "";
                    }
                    if (radWord.Checked)
					{
						if(x <= word.GetUpperBound(0)) 
						{
							ctrl.Text = word[x].ToString();
							ctrl.Visible = true;
						}
						else ctrl.Text = "";
					}
				}
			}
		}

        private void grpStart_Enter(object sender, EventArgs e)
        {

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void menuStrip1_ItemClicked_1(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void setupToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //frmSetup frmSoftwareSetup = new frmSetup();
            //frmSoftwareSetup.Show();

            //grpSetup.Visible = true;
        }

        

        

        private void realTimeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmRealTime frmRealTime1 = new frmRealTime();

            frmRealTime1.Show();

        }

        private void grpData_Enter(object sender, EventArgs e)
        {

        }

        private void statusToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
            //if (GlbByte.giFormStatusOpened == 0)
            //{
            //    frmStatus frmStatus1 = new frmStatus();
            //    frmStatus1.Show();
            //    GlbByte.giFormStatusOpened = 1;
            //}

            if (frmStatus1 == null || frmStatus1.IsDisposed)
            {
                frmStatus1 = new frmStatus();
                frmStatus1.Show();
            }
            else
            {
                frmStatus1.WindowState = FormWindowState.Normal;
                frmStatus1.BringToFront();
                frmStatus1.Activate();
            }


        }

        private void alarmToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAlarm frmAlarm1 = new frmAlarm();

            frmAlarm1.Show();
        }

        //private void timer1_Tick(object sender, EventArgs e)
        //{
        //    //    //if(mbTCPInConnection == true)
        //    //    //    label5.Visible = true;
        //    //    //else
        //    //    //    label5.Visible = false;



        //}

        private void controlToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            //if (GlbByte.giFormSetupOpened == 0)
            //{
            //    frmInstrumentSetup frmInstrumentSetup1 = new frmInstrumentSetup();
            //    frmInstrumentSetup1.Show();
            //    GlbByte.giFormSetupOpened = 1;
            //}
            //else
            //{
            //    frmInstrumentSetup1.WindowState = FormWindowState.Normal;
            //    frmInstrumentSetup1.Activate();
            //    frmInstrumentSetup1.BringToFront();

            //}

            if (frmInstrumentSetup1 == null || frmInstrumentSetup1.IsDisposed)
            {
                frmInstrumentSetup1 = new frmInstrumentSetup();
                frmInstrumentSetup1.Show();
            }
            else
            {
                frmInstrumentSetup1.WindowState = FormWindowState.Normal;
                frmInstrumentSetup1.BringToFront();
                frmInstrumentSetup1.Activate();
            }

        }

        private void TaskTick_Tick(object sender, EventArgs e)
        {
            

            DateTime dtMinDateInApp = DateTime.MinValue;
            DateTime dtMaxDateInApp = DateTime.MinValue;

            double dblTemp;
            Byte ByteTemp;

           
            int i,j;
            j = 0;
            DateTime newTrendStartTime;

            if (GlbByte.giFormSetupOpened != 0)
            {

            }

            TaskTick.Enabled = false;

            lblDateTimeData.Text = GlbByte.gdtCurrent.ToString("yyyy-MM-dd HH:mm:ss");

            dblTemp = (double)GlbByte.giTritiumReadingInTenth *GlbByte.gdblEngUnitFactor[GlbByte.giEngineeringUnitSelected] / 10.0;
            if(GlbByte.giEngineeringUnitSelected == 3)
            {
                i =(int)(dblTemp * 10);
                dblTemp = (float)i * 0.1;
            }            
            label1.Text = dblTemp.ToString("F1") + GlbByte.gstrEngUnit[GlbByte.giEngineeringUnitSelected];//�Ci/m3";

            //dblTemp = (double)GlbByte.giGammaReadingInTenth/ 10.0;
            //label6.Text = dblTemp.ToString("F1") + " mR/Hr";�
            i = GlbByte.giGammaReadingInTenth;
            label6.Text = i.ToString() + " �Sv/H";

            dblTemp = (double)GlbByte.giCompensationInTenthMicro * GlbByte.gdblEngUnitFactor[GlbByte.giEngineeringUnitSelected] / 10.0;
            label12.Text = "Comp: " + dblTemp.ToString("F1");
           

            dtMinDateInApp = DateTime.Parse("2019-01-01");
            dtMaxDateInApp = DateTime.Parse("2059-01-01");

            if (GlbByte.GbyteRealTimeTrendRefreshReq != 0)
            {
                GlbByte.GbyteRealTimeTrendRefreshReq = 0;
                setupChart();
            }

            if (pbChartSetup == false)
            {
                if (GlbByte.giSavedDataPointer > 1)
                {
                    pbChartSetup = true;
                    piRealTimeDataCnt = GlbByte.giSavedDataPointer;
                    for (i = 0; i < piRealTimeDataCnt; i++)
                    {
                        pdtTrendTime[i] = GlbByte.gdtBuf[i];
                        pbyteTrendSeriesNum[i] = GlbByte.gbyteSmpLocArray[i];
                        pdTrendData[i] = GlbByte.giTritium[i]/10.0;

                    }
                    setupChart();
                    label5.Visible = false;
                    label7.Visible = false;
                    label8.Visible = false;

                }
            }

            //serialPort1.Write("Hello");

            if (GlbByte.GbyteTCPConnected == 1)
            {
                if (GlbByte.gByteTCPWriteReq != 0)
                {
                    GlbByte.GbyteReadInputRegRequest = 0;  // disale Inout scanning
                    GlbByte.giBlockInputRegReadingCnt = 10;
                    if (GlbByte.gByteTCPWriteReq_InBackGroundCancellation == 0)
                        tmrTCPCommandOnLifeTime.Enabled = true;
                    
                    //ByteTemp = 0;
                    //for (i = 0; i < 53; i++)
                    //    ByteTemp += GlbByte.GbyteWriteBuf[i];
                    //GlbByte.GbyteWriteBuf[53] = ByteTemp;

                    sendFunc16(GlbByte.GbyteWriteBuf, 54);
                    tmrSerialDataReceivingEndDetection.Enabled = true;
                    piTCPFeedBackDelay = 0;
                    GlbByte.gByteTCPWriteReq = 0;

                }

                if (GlbByte.GbyteTCPReadRequested == 1)
                {
                    GlbByte.GbyteReadInputRegRequest = 0;  // disale Input scanning
                    GlbByte.giBlockInputRegReadingCnt = 10;
                    i = GlbByte.gsModbusStartReg;
                    j = GlbByte.gsModbusNumberReg;

                    readHoldingReg((ushort)i, (ushort)j);
                    tmrSerialDataReceivingEndDetection.Enabled = true;
                    piTCPFeedBackDelay = 0;
                    lblLastCommunication.Visible = false;
                    GlbByte.GbyteTCPReadRequested = 0;
                }

                if (GlbByte.giBlockInputRegReadingCnt > 0)
                    GlbByte.giBlockInputRegReadingCnt = GlbByte.giBlockInputRegReadingCnt - 1;
                else
                {
                    if (GlbByte.GbyteReadInputRegRequest == 1)
                    {

                        readInputReg(0, 6);

                        tmrSerialDataReceivingEndDetection.Enabled = true;
                        piTCPFeedBackDelay = 0;
                        lblLastCommunication.Visible = false;
                        GlbByte.GbyteReadInputRegRequest = 0;
                    }
                }
                //else
                //{

                //    piTCPFeedBackDelay++;
                //    if(piTCPFeedBackDelay > 2)  // was 10 for 5 
                //    {
                //        piTCPFeedBackDelay = 0;
                //        GlbByte.GbyteTCPReadRequested = 0;
                //        lblLastCommunication.Visible = true;
                //    }
                //}




                if ((pbChartSetup == true)&&(GlbByte.GbyteTCPReadCompleted ==1))
                {   //.Points.AddXY(mdtData[i], TrendData[i]);
                    //if((GlbByte.gbyteSampleLocation != 0)&& (GlbByte.gbyteSampleLocation < 6))
                    //    chart1.Series[GlbByte.gbyteSampleLocation -1].Points.AddXY(GlbByte.gdtCurrent, GlbByte.giTritiumReadingInTenth / 10.0);
                    GlbByte.GbyteTCPReadCompleted = 0;
                    if (pbyteStartupFlagForRealTimeTrend == 1)
                    {
                        pbyteStartupFlagForRealTimeTrend = 0;
                        pdtTrendTime[piRealTimeDataCnt] = GlbByte.gdtCurrent;
                        pbyteTrendSeriesNum[piRealTimeDataCnt] = GlbByte.gbyteSampleLocation;

                        pdTrendData[piRealTimeDataCnt] = GlbByte.giTritiumReadingInTenth/ 10.0;
                        //if (GlbByte.gbyteSampleLocation == 1)
                        //    pdTrendData[piRealTimeDataCnt] = GlbByte.giMeas1;
                        //if (GlbByte.gbyteSampleLocation == 2)
                        //    pdTrendData[piRealTimeDataCnt] = GlbByte.giMeas2;
                        //if (GlbByte.gbyteSampleLocation == 3)
                        //    pdTrendData[piRealTimeDataCnt] = GlbByte.giComp1;
                        //if (GlbByte.gbyteSampleLocation == 4)
                        //    pdTrendData[piRealTimeDataCnt] = GlbByte.giComp2;
                        //if (GlbByte.gbyteSampleLocation == 5)
                        //    pdTrendData[piRealTimeDataCnt] = GlbByte.giMiKPa / 1000;
                       
                        chart1.Series[0].Points.AddXY(pdtTrendTime[piRealTimeDataCnt], pdTrendData[piRealTimeDataCnt] * GlbByte.gdblEngUnitFactor[GlbByte.giEngineeringUnitSelected]);
                        switch (pbyteTrendSeriesNum[piRealTimeDataCnt])
                        {
                            case 1:
                                chart1.Series[0].Points[piRealTimeDataCnt].Color = Color.Brown;
                                break;
                            case 2:
                                chart1.Series[0].Points[piRealTimeDataCnt].Color = Color.Orange;
                                break;
                            case 3:
                                chart1.Series[0].Points[piRealTimeDataCnt].Color = Color.Yellow;
                                break;
                            case 4:
                                chart1.Series[0].Points[piRealTimeDataCnt].Color = Color.White;//Color.Green;
                                break;
                            case 5:
                                chart1.Series[0].Points[piRealTimeDataCnt].Color = Color.Blue;
                                break;
                        }
                        //chart1.Series[pbyteTrendSeriesNum[piRealTimeDataCnt] - 1].Points.AddXY(pdtTrendTime[piRealTimeDataCnt], pdTrendData[piRealTimeDataCnt]);
                        piRealTimeDataCnt++;  // = 1

                    }
                    else
                    {
                        if((GlbByte.gdtCurrent != pdtTrendTime[piRealTimeDataCnt-1]) && (GlbByte.gdtCurrent > dtMinDateInApp) && (GlbByte.gdtCurrent <dtMaxDateInApp) && (GlbByte.gbyteSampleLocation < 6) && (GlbByte.gbyteSampleLocation > 0))
                        {
                            pdtTrendTime[piRealTimeDataCnt] = GlbByte.gdtCurrent;
                            pbyteTrendSeriesNum[piRealTimeDataCnt] = GlbByte.gbyteSampleLocation;

                           
                            pdTrendData[piRealTimeDataCnt] = GlbByte.giTritiumReadingInTenth / 10.0;
                            //if (GlbByte.gbyteSampleLocation == 1)
                            //    pdTrendData[piRealTimeDataCnt] = GlbByte.giMeas1;
                            //if (GlbByte.gbyteSampleLocation == 2)
                            //    pdTrendData[piRealTimeDataCnt] = GlbByte.giMeas2;
                            //if (GlbByte.gbyteSampleLocation == 3)
                            //    pdTrendData[piRealTimeDataCnt] = GlbByte.giComp1;
                            //if (GlbByte.gbyteSampleLocation == 4)
                            //    pdTrendData[piRealTimeDataCnt] = GlbByte.giComp2;
                            //if (GlbByte.gbyteSampleLocation == 5)
                            //    pdTrendData[piRealTimeDataCnt] = GlbByte.giMiKPa / 1000;

                           // textBox12.Text = pdtTrendTime[piRealTimeDataCnt].ToString();
                            //textBox13.Text = pbyteTrendSeriesNum[piRealTimeDataCnt].ToString();
                            //textBox14.Text = pdTrendData[piRealTimeDataCnt].ToString();

                            if (GlbByte.gdtCurrent < pdtTrendTime[0].AddHours(piTrendHourSpan))
                            {
                               
                                chart1.Series[0].Points.AddXY(pdtTrendTime[piRealTimeDataCnt], pdTrendData[piRealTimeDataCnt] * GlbByte.gdblEngUnitFactor[GlbByte.giEngineeringUnitSelected]);
                                switch (pbyteTrendSeriesNum[piRealTimeDataCnt])
                                {
                                    case 1:
                                        chart1.Series[0].Points[piRealTimeDataCnt].Color = Color.Brown;
                                        break;
                                    case 2:
                                        chart1.Series[0].Points[piRealTimeDataCnt].Color = Color.Orange;
                                        break;
                                    case 3:
                                        chart1.Series[0].Points[piRealTimeDataCnt].Color = Color.Yellow;
                                        break;
                                    case 4:
                                        chart1.Series[0].Points[piRealTimeDataCnt].Color = Color.White;//Color.Green;
                                        break;
                                    case 5:
                                        chart1.Series[0].Points[piRealTimeDataCnt].Color = Color.Blue;
                                        break;
                                }
                                //chart1.Series[pbyteTrendSeriesNum[piRealTimeDataCnt] - 1].Points.AddXY(pdtTrendTime[piRealTimeDataCnt], pdTrendData[piRealTimeDataCnt]);
                                piRealTimeDataCnt++;
                            }
                            else
                            {
                                i = piTrendHourSpan / 2;
                                newTrendStartTime = pdtTrendTime[0].AddHours(i);
                                for (i = 0; i < piRealTimeDataCnt + 1; i++)
                                {
                                    if (pdtTrendTime[i] > newTrendStartTime)
                                    {
                                        j = i;
                                        break;
                                    }
                                }
                                for (i = j; i < piRealTimeDataCnt + 1; i++)
                                {
                                    pdtTrendTime[i - j] = pdtTrendTime[i];
                                    pbyteTrendSeriesNum[i - j] = pbyteTrendSeriesNum[i];
                                    pdTrendData[i - j] = pdTrendData[i];
                                }
                                piRealTimeDataCnt = piRealTimeDataCnt - j + 1;
                                setupChart();

                            }

                            //textBox2.Text = piRealTimeDataCnt.ToString();

                            if (piRealTimeDataCnt == 86400)
                            {
                                // refresh the chart 1
                                piRealTimeDataCnt = 70000;
                            }

                            if (pbyteStartupFlagForDataLog == 1)
                            {
                                pbyteStartupFlagForDataLog = 0;
                                InsertDataToDataBase();
                                psDataSavedTime = GlbByte.gdtCurrent;
                            }
                            else
                            {
                                if ((GlbByte.gdtCurrent == psDataSavedTime.AddSeconds(GlbByte.miHistSaveInterval)) || ((GlbByte.gdtCurrent > psDataSavedTime.AddSeconds(GlbByte.miHistSaveInterval))))
                                {
                                    //piDataLogTimeCnt = 0;
                                    InsertDataToDataBase();
                                    psDataSavedTime = GlbByte.gdtCurrent;
                                }
                            }

                        }

                    }
                }


                //piStartupTime++;                

                //if (piStartupTime > miHistSaveInterval)
                //{
                //    piStartupTime = 1;
                //    InsertDataToDataBase();
                //    psDataSavedTime = GlbByte.gdtCurrent;
                //}
            }
            /* Commented to remvove TCP/IP Modbus
            else
            {
                if(piTCPConnectionTried == 0)
                   connectTCP();
            }
            */
            processAlarmWarning();

            TaskTick.Enabled = true;

        }



        private void InsertDataToDataBase()
        {
            //dbConnection = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source = " + GlbByte.msCurrentDirName +@"\TrinetData.mdb");
            //dbConnection.Open();

            OleDbCommand cmd = dbConnection.CreateCommand();           

            cmd.CommandText = "Insert into RadData " + "(dtDateTime, Location, TritiumLevel, GammaLevel) " + "Values (" + "#"+GlbByte.gdtCurrent.ToString() + "#" + ", "
                                                                                                                + GlbByte.gbyteSampleLocation.ToString() + ", "
                                                                                                                + GlbByte.giTritiumReadingInTenth.ToString() + ", "
                                                                                                                + GlbByte.giGammaReadingInTenth.ToString() + ")";
            cmd.Connection = dbConnection;
            cmd.CommandType = CommandType.Text;

            cmd.ExecuteNonQuery();


            cmd.Dispose();

            //dbConnection.Close();

            //dbConnection.Dispose();

            
        }

        public void writeLinesToFile()
        {
            try
            {
               

                //Pass the filepath and filename to the StreamWriter Constructor
                System.IO.StreamWriter sw = new System.IO.StreamWriter(GlbByte.msCurrentDirName);

                //Write a line of text
                sw.WriteLine(GlbByte.msIPAddress);
                sw.WriteLine(GlbByte.miHistSaveInterval.ToString());
                sw.WriteLine(GlbByte.giPassword.ToString());
                sw.WriteLine(GlbByte.giLocationSelect.ToString());
                sw.WriteLine(GlbByte.giLocationTimmingArry[0].ToString());
                sw.WriteLine(GlbByte.giLocationTimmingArry[1].ToString());
                sw.WriteLine(GlbByte.giLocationTimmingArry[2].ToString());
                sw.WriteLine(GlbByte.giLocationTimmingArry[3].ToString());
                sw.WriteLine(GlbByte.giLocationTimmingArry[4].ToString());
                sw.WriteLine(GlbByte.giEngineeringUnitSelected.ToString());

                //Close the file
                sw.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.Message);
            }
            finally
            {
                Console.WriteLine("Executing finally block.");
            }
        }

        private void grpExchange_Enter(object sender, EventArgs e)
        {

        }

        

        private void setupChart()
        {


            //dtTemp.ToOADate()

            int i;
            String strSeriesName = System.String.Empty;

            TimeSpan tsTemp;
            DateTime dtTemp;
           
            chart1.Series.Clear();
            chart1.Titles.Clear();


            //chart1.Titles.Add("Tritium Reading uCi/m3");

            chart1.ChartAreas[0].BackColor = Color.Black;
            chart1.ChartAreas[0].AxisX.MajorGrid.LineColor = Color.DarkGreen;//Color.LawnGreen;
            chart1.ChartAreas[0].AxisY.MajorGrid.LineColor = Color.DarkGreen; //Color.Gray;//Color.LawnGreen;

            chart1.ChartAreas[0].AxisY.Title = GlbByte.gstrEngUnit[GlbByte.giEngineeringUnitSelected];// "�Ci/m3";
            chart1.ChartAreas[0].AxisY.TitleFont =
                   new System.Drawing.Font("Arial", 14, System.Drawing.FontStyle.Bold);

            chart1.ChartAreas[0].CursorX.IsUserEnabled = true;
            chart1.ChartAreas[0].CursorX.IsUserSelectionEnabled = true;
            chart1.ChartAreas[0].CursorY.IsUserEnabled = true;
            chart1.ChartAreas[0].CursorY.IsUserSelectionEnabled = true;

            chart1.ChartAreas[0].CursorX.Interval = 0;
            chart1.ChartAreas[0].CursorY.Interval = 0;
            chart1.ChartAreas[0].AxisX.ScaleView.Zoomable = true;
            chart1.ChartAreas[0].AxisY.ScaleView.Zoomable = true;

            chart1.ChartAreas[0].CursorX.LineColor = Color.White; //Color.LightGray; //Color.MediumTurquoise;//Color.Black;
            chart1.ChartAreas[0].CursorX.LineWidth = 1;
            chart1.ChartAreas[0].CursorX.LineDashStyle = ChartDashStyle.Dot;
            tsTemp = TimeSpan.FromSeconds(10);
            chart1.ChartAreas[0].CursorX.Interval = 10 / 86400;// 0.0002;// 1000/86400;// 100 seconds, the format of date is x.yyyyy x is the day number from 1900;
            chart1.ChartAreas[0].CursorY.LineColor = Color.White; //Color.LightGray; // Color.MediumTurquoise;
            chart1.ChartAreas[0].CursorY.LineWidth = 1;
            chart1.ChartAreas[0].CursorY.LineDashStyle = ChartDashStyle.Dot;
            chart1.ChartAreas[0].CursorY.Interval = 2;// 0;


            chart1.ChartAreas[0].AxisX.ScrollBar.Enabled = true;
            // Set scrollbar size
            chart1.ChartAreas[0].AxisX.ScrollBar.Size = 20;
            chart1.ChartAreas[0].AxisY.ScrollBar.Size = 20;

            // Show small scroll buttons only          
            // chart1.ChartAreas[0].AxisX.ScrollBar.ButtonStyle = ScrollBarButtonStyles.SmallScroll;
            // Scrollbars position
            chart1.ChartAreas[0].AxisX.ScrollBar.IsPositionedInside = true;

            // Change scrollbar colors
            chart1.ChartAreas[0].AxisX.ScrollBar.BackColor =  Color.MediumTurquoise;
            chart1.ChartAreas[0].AxisX.ScrollBar.ButtonColor = Color.LightCyan;
            chart1.ChartAreas[0].AxisX.ScrollBar.LineColor = Color.Blue;

            chart1.ChartAreas[0].AxisY.ScrollBar.BackColor = Color.MediumTurquoise;// Color.LightCyan;//Color.LightGray;
            chart1.ChartAreas[0].AxisY.ScrollBar.ButtonColor = Color.LightCyan;//Color.LightCyan;
            chart1.ChartAreas[0].AxisY.ScrollBar.LineColor = Color.Blue; //Color.Black;



            //chart1.Titles[0].Font = new System.Drawing.Font("Arial", 14, FontStyle.Bold);
            chart1.ChartAreas[0].AxisX.LabelStyle.Format = "yyyy-MM-dd HH:mm:ss";
            //tsTemp = new TimeSpan(0, 1, 0);           
            chart1.ChartAreas[0].AxisX.Minimum = pdtTrendTime[0].ToOADate();//(double)pdtTrendTime[0].Millisecond*1000;
            dtTemp = pdtTrendTime[0].AddHours(piTrendHourSpan);//pdtTrendTime[0].AddMinutes(5);
            chart1.ChartAreas[0].AxisX.Maximum = dtTemp.ToOADate();//(double)dtTemp.Millisecond*1000;

            //chart1.ChartAreas[0].AxisY.Maximum = 8.0;//(double)dtTemp.Millisecond*1000;
            //chart1.ChartAreas[0].AxisY.Minimum = -2.0;//(double)dtTemp.Millisecond*1000;

            Series series1 = chart1.Series.Add("Location1");
            series1.ChartType =SeriesChartType.Line;//SeriesChartType.Spline;
            series1.BorderWidth = 2;
            series1.Color = Color.Blue;
            series1.Font = new System.Drawing.Font("Arial", 14, FontStyle.Bold);
            /*
            Series series2 = chart1.Series.Add("Location2");
            series2.ChartType = SeriesChartType.Point;//SeriesChartType.Line;//SeriesChartType.Spline;
            series2.BorderWidth = 4;
            series2.Color = Color.Black;
            series2.Font = new System.Drawing.Font("Arial", 14, FontStyle.Bold);

            Series series3 = chart1.Series.Add("Location3");
            series3.ChartType = SeriesChartType.Point;//SeriesChartType.Line;//SeriesChartType.Spline;
            series3.BorderWidth = 4;
            series3.Color = Color.DarkRed;
            series3.Font = new System.Drawing.Font("Arial", 14, FontStyle.Bold);

            Series series4 = chart1.Series.Add("Location4");
            series4.ChartType = SeriesChartType.Point;// SeriesChartType.Line;//SeriesChartType.Spline;
            series4.BorderWidth = 4;
            series4.Color = Color.DarkSeaGreen;
            series4.Font = new System.Drawing.Font("Arial", 14, FontStyle.Bold);

            Series series5 = chart1.Series.Add("Location5");
            series5.ChartType = SeriesChartType.Point;//SeriesChartType.Line;//SeriesChartType.Spline;
            series5.BorderWidth = 4;
            series5.Color = Color.Purple;
            series5.Font = new System.Drawing.Font("Arial", 14, FontStyle.Bold);
            */

            

            for (i = 0; i < piRealTimeDataCnt; i++)
            {


                //chart1.Series[pbyteTrendSeriesNum[i] - 1].Points.AddXY(pdtTrendTime[i], pdTrendData[i]);
                
                chart1.Series[0].Points.AddXY(pdtTrendTime[i], pdTrendData[i] * GlbByte.gdblEngUnitFactor[GlbByte.giEngineeringUnitSelected]);
                switch (pbyteTrendSeriesNum[i])
                {
                    case 1:
                        chart1.Series[0].Points[i].Color = Color.Brown;
                        break;
                    case 2:
                        chart1.Series[0].Points[i].Color = Color.Orange;
                        break;
                    case 3:
                        chart1.Series[0].Points[i].Color = Color.Yellow;
                        break;
                    case 4:
                        chart1.Series[0].Points[i].Color = Color.White;//Color.Green;
                        break;
                    case 5:
                        chart1.Series[0].Points[i].Color = Color.Blue;
                        break;
                }

            }

        }

        private void historicalDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmHistricalData frmHistory1 = new frmHistricalData();

            frmHistory1.Show();
        }

        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmRealTime frmRealTime1= new frmRealTime();

            frmRealTime1.Show();

        }


        //private void chart1_Click(object sender, EventArgs e)
        //{
        //    int i, j;
        //    DateTime dtTemp;
        //    double XVal = chart1.ChartAreas[0].CursorX.Position;
        //    double dblMinDate, dblMaxDate;

        //    DateTime dtMinDateInApp = DateTime.MinValue;
        //    DateTime dtMaxDateInApp = DateTime.MinValue;

            
        //    dtMinDateInApp = DateTime.Parse("2019-01-01");
        //    dtMaxDateInApp = DateTime.Parse("2059-01-01");
        //    dblMinDate = dtMinDateInApp.ToOADate();
        //    dblMaxDate = dtMaxDateInApp.ToOADate();

        //    if ((XVal > dblMinDate) && (XVal < dblMaxDate))
        //    {
        //        dtTemp = DateTime.FromOADate(XVal);
        //        j = 0;
        //        for (i = 1; i < piRealTimeDataCnt; i++)
        //        {
        //            if ((pdtTrendTime[i] == dtTemp) || (pdtTrendTime[i] > dtTemp))
        //            {
        //                j = i;
        //                break;
        //            }
        //        }

        //        if (j != 0)
        //        {
        //            groupBox2.Visible = true;

        //            textBox15.Text = dtTemp.ToString();
        //            textBox16.Text = pbyteTrendSeriesNum[j].ToString();
        //            textBox17.Text = pdTrendData[j].ToString();

        //            tmrCursorDispOffDelay.Enabled = true;
        //        }
        //    }
        //}

        private void tmrWarnSoundPlay_Tick(object sender, EventArgs e)
        {
            
            //System.Media.SoundPlayer player1 = new System.Media.SoundPlayer(GlbByte.msCurrentDirName + @"\Alarm10.wav");
            player1.Play();
            //SystemSounds.Beep.Play();
        }

        private void tmrAlarmSoundPlay_Tick(object sender, EventArgs e)
        {
           
            //SystemSounds.Beep.Play();
            player1.Play();

        }

        private void chart1_Click_1(object sender, EventArgs e)
        {
            int i, j;
            DateTime dtTemp;
            double XVal = chart1.ChartAreas[0].CursorX.Position;
            double dblMinDate, dblMaxDate;
            double dblTemp;

            DateTime dtMinDateInApp = DateTime.MinValue;
            DateTime dtMaxDateInApp = DateTime.MinValue;


            dtMinDateInApp = DateTime.Parse("2019-01-01");
            dtMaxDateInApp = DateTime.Parse("2059-01-01");
            dblMinDate = dtMinDateInApp.ToOADate();
            dblMaxDate = dtMaxDateInApp.ToOADate();

            if ((XVal > dblMinDate) && (XVal < dblMaxDate))
            {
                dtTemp = DateTime.FromOADate(XVal);
                j = 0;
                for (i = 1; i < piRealTimeDataCnt; i++)
                {
                    if ((pdtTrendTime[i] == dtTemp) || (pdtTrendTime[i] > dtTemp))
                    {
                        j = i;
                        break;
                    }
                }

                if (j != 0)
                {
                    groupBox2.Visible = true;

                    textBox15.Text = dtTemp.ToString("yyyy-MM-dd HH:mm:ss");
                    textBox16.Text = pbyteTrendSeriesNum[j].ToString();

                    dblTemp = pdTrendData[j] * GlbByte.gdblEngUnitFactor[GlbByte.giEngineeringUnitSelected];
                    textBox17.Text = dblTemp.ToString();

                    tmrCursorDispOffDelay.Enabled = true;
                }
            }

        }

        private void connectToPLCToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSetup frmSoftwareSetup = new frmSetup();
            frmSoftwareSetup.Show();
    
        }

        private void connectToPLCToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            // Commented to remove TCP/IP Modbus
            //connectTCP();
            try
            {
                serialPort1.Open();
                GlbByte.GbyteTCPConnected = 1;
            }
            catch (Exception exxx)
            {
                GlbByte.GbyteTCPConnected = 0;
                Console.WriteLine("Tried to Open COM9 Port, Exception: " + exxx.Message);
            }
        }

        private void tmrWarningFlashing_Tick(object sender, EventArgs e)
        {
            if (pbWarningToggleBit == false)
            {
                label14.Visible = true;
                pbWarningToggleBit = true;
            }
            else
            {
                label14.Visible = false;
                pbWarningToggleBit = false;
            }
        }

        private void tmrAlarmFlashing_Tick(object sender, EventArgs e)
        {
            if(pbAlarmToggleBit == false)
            {
                label13.Visible = true;
                pbAlarmToggleBit = true;
            }
            else
            {
                label13.Visible = false;
                pbAlarmToggleBit = false;
            }
        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void tmrTCPCommandOnLifeTime_Tick(object sender, EventArgs e)
        {
            //GlbByte.GbyteWriteBuf[0] = 0x55;
            //GlbByte.GbyteWriteBuf[1] =0;  // request for background cancellation
            //GlbByte.GbyteWriteBuf[2] = 0;
            tmrTCPCommandOnLifeTime.Enabled = false;
            tmrTCPCommandOffLifeTime.Enabled = true;

        }

        private void tmrTCPCommandOffLifeTime_Tick(object sender, EventArgs e)
        {
            GlbByte.gByteTCPWriteReq = 0;
            tmrTCPCommandOnLifeTime.Enabled = false;
            tmrTCPCommandOffLifeTime.Enabled = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            //this.Close();
            //dbConnection.Close();

            dbConnection.Close();

            dbConnection.Dispose();

            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Process.Start("shutdown", "/s /t 0");
        }

        private void label21_Click(object sender, EventArgs e)
        {

        }

        private void btnSilent_Click(object sender, EventArgs e)
        {
            tmrWarnSoundPlay.Enabled = false;
            tmrAlarmSoundPlay.Enabled = false;
            btnSilent.Visible = false;

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
           
    
            string OSKpath32 = @"C:\Windows\System32\osk.exe";
        
            

            System.Diagnostics.Process.Start(OSKpath32);
        }

        private void exitToWindowsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dbConnection.Close();

            dbConnection.Dispose();

            Application.Exit();
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            int i;
            int iNumBytes = serialPort1.BytesToRead;  //find the size of the array needed
            byte[] byteBuffer = new byte[iNumBytes];  //create the array
            serialPort1.Read(byteBuffer, 0, iNumBytes);  //read the message and save it into the buffer

            pbUartReceived = true;

            if (iNumBytes < 250)
            {
                for (i = 0; i < iNumBytes; i++)
                {
                    arrByteRXBuf[piUartReceivedCnt + i] = byteBuffer[i];
                }
                piUartReceivedCnt = piUartReceivedCnt + iNumBytes;
                if (piUartReceivedCnt > 250)
                    piUartReceivedCnt = 0;
            }

        }

        private void label12_Click(object sender, EventArgs e)
        {
           
        }

        private void tmrCursorDispOffDelay_Tick(object sender, EventArgs e)
        {
            tmrCursorDispOffDelay.Enabled = false;
            groupBox2.Visible = false;

        }

        private void processAlarmWarning()
        {
            string sInfo;



            if(GlbByte.gbyteAlarmBits > mbyteAlarmBits_Saved)
            {
                player1.Play();
                tmrAlarmSoundPlay.Enabled = true;
                btnSilent.Visible = true;
            }

            if(GlbByte.gbyteAlarmBits == 0)
            {
                tmrAlarmSoundPlay.Enabled = false;
                //btnSilent.Visible = false;
            }

            if(GlbByte.gbyteWarningBits > mbyteWarningBits_Saved)
            {
                player1.Play();
                tmrWarnSoundPlay.Enabled = true;
                btnSilent.Visible = true;
            }

            if(GlbByte.gbyteWarningBits == 0)
            {
                tmrWarnSoundPlay.Enabled = false;
                //btnSilent.Visible = false;
            }

            if ((GlbByte.gbyteAlarmBits == 0) && (GlbByte.gbyteWarningBits == 0))
                btnSilent.Visible = false;

            mbyteWarningBits_Saved = GlbByte.gbyteWarningBits;
            mbyteAlarmBits_Saved = GlbByte.gbyteAlarmBits;

            if ((GlbByte.gbyteAlarmBits == 0)&&(GlbByte.gbyteWarningBits == 0))
            {
                if ((GlbByte.gbyteStatusFlag & 0x1) == 0)
                    this.BackColor = Color.Cyan;
                else
                    this.BackColor = Color.Green;
            }

            if ((GlbByte.gbyteStatusFlag & 0x2) != 0)
                lblBackgroundCancellationInfo.Visible = true;
            else
                lblBackgroundCancellationInfo.Visible = false;

            if (GlbByte.gbyteWarningBits != 0)
            {
                this.BackColor = Color.Yellow;
                //tmrWarnSoundPlay.Enabled = true;
            }
            
            if (GlbByte.gbyteAlarmBits != 0)
            {
                this.BackColor = Color.Red;
                //tmrAlarmSoundPlay.Enabled = true;
            }
           

            if ((GlbByte.gbyteAlarmBits&0x1) != 0)
            {
                label13.Text = "Tritium HH Level 2 ";  
            }

            if ((GlbByte.gbyteAlarmBits & 0x2) != 0)
            {
                label13.Text = "Gamma High";
            }

            if ((GlbByte.gbyteAlarmBits & 0x4) != 0)
            {
                label13.Text = "Tritium H Level 1";
            }

            if ((GlbByte.gbyteAlarmBits & 0x7) != 0)
            {
                //label13.Visible = true;
                tmrAlarmFlashing.Enabled = true;
            }
            else
            {
                tmrAlarmFlashing.Enabled = false;
                label13.Visible = false;
            }

            if ((GlbByte.gbyteWarningBits & 0x4) != 0)
            {
                label14.Text = "Flow Low!";
            }

            if ((GlbByte.gbyteWarningBits & 0x8) != 0)
            {
                label14.Text = "Drier Failure!";
            }

            if ((GlbByte.gbyteWarningBits & 0x10) != 0)
            {
                label14.Text = "Ion chamber Body Over Temperature!";
            }

            if ((GlbByte.gbyteWarningBits & 0x20) != 0)
            {
                label14.Text = "Air Filter Due!";
            }

            if ((GlbByte.gbyteWarningBits & 0x3c) == 0)
            {
                tmrWarningFlashing.Enabled = false;
                label14.Visible = false;
            }
            else
            {
                tmrWarningFlashing.Enabled = true;
                //label14.Visible = true;
            }


            if ((GlbByte.gbyteWarningBits & 0x40) != 0)
            {
                lblLastCommunication.Visible = true;
            }
            else
                lblLastCommunication.Visible = false;
            

            if (((GlbByte.gbyteAlarmBits&0x1) != 0)&&((pbyteAlarmBits & 0x1) == 0))
            {               
                tmrAlarmSoundPlay.Enabled = true;
                // display in the list and Save to Data Base and 
                sInfo = "Tritium HH Level 2";
                listBox1.Items.Add(GlbByte.gdtCurrent.ToString("yyyy-MM-dd HH:mm:ss") +  " " + sInfo);
                InsertAlarmWarnToDataBase(sInfo);
            }

            if (((GlbByte.gbyteAlarmBits & 0x2) != 0) && ((pbyteAlarmBits & 0x2) == 0))
            {
                tmrAlarmSoundPlay.Enabled = true;
                // display in the list and Save to Data Base and 
                sInfo = "Gamma High";
                listBox1.Items.Add(GlbByte.gdtCurrent.ToString("yyyy-MM-dd HH:mm:ss") +  " " + sInfo);
                InsertAlarmWarnToDataBase(sInfo);
            }

            if (((GlbByte.gbyteAlarmBits & 0x4) != 0) && ((pbyteAlarmBits & 0x4) == 0))
            {
                tmrAlarmSoundPlay.Enabled = true;
                // display in the list and Save to Data Base and 
                sInfo = "Tritium H Level 1";
                listBox1.Items.Add(GlbByte.gdtCurrent.ToString("yyyy-MM-dd HH:mm:ss") +  " " + sInfo);
                InsertAlarmWarnToDataBase(sInfo);
            }

            if (((GlbByte.gbyteWarningBits & 0x4) != 0) && ((pbyteWarningBits & 0x4) == 0))
            {
                tmrWarnSoundPlay.Enabled = true;
                // display in the list and Save to Data Base and 
                sInfo = "Flow Low";
                listBox1.Items.Add(GlbByte.gdtCurrent.ToString("yyyy-MM-dd HH:mm:ss")  + " " + sInfo);
                InsertAlarmWarnToDataBase(sInfo);
            }

            if (((GlbByte.gbyteWarningBits & 0x8) != 0) && ((pbyteWarningBits & 0x8) == 0))
            {
                tmrWarnSoundPlay.Enabled = true;
                // display in the list and Save to Data Base and 
                sInfo = "Drier Failure";
                listBox1.Items.Add(GlbByte.gdtCurrent.ToString("yyyy-MM-dd HH:mm:ss") + " " + sInfo);
                InsertAlarmWarnToDataBase(sInfo);
            }

            if (((GlbByte.gbyteWarningBits & 0x10) != 0) && ((pbyteWarningBits & 0x10) == 0))
            {
                tmrWarnSoundPlay.Enabled = true;
                // display in the list and Save to Data Base and 
                sInfo = "Ion Chamber O.T.";
                listBox1.Items.Add(GlbByte.gdtCurrent.ToString("yyyy-MM-dd HH:mm:ss")  + " " + sInfo);
                InsertAlarmWarnToDataBase(sInfo);
            }

            if (((GlbByte.gbyteWarningBits & 0x20) != 0) && ((pbyteWarningBits & 0x20) == 0))
            {
                tmrWarnSoundPlay.Enabled = true;
                // display in the list and Save to Data Base and 
                sInfo = "Air Filter Due";
                listBox1.Items.Add(GlbByte.gdtCurrent.ToString("yyyy-MM-dd HH:mm:ss") + " " + sInfo);
                InsertAlarmWarnToDataBase(sInfo);
            }

            if (((GlbByte.gbyteWarningBits & 0x40) != 0) && ((pbyteWarningBits & 0x40) == 0))
            {
                tmrWarnSoundPlay.Enabled = true;
                // display in the list and Save to Data Base and 
                sInfo = "Lost Communication";
                listBox1.Items.Add(GlbByte.gdtCurrent.ToString("yyyy-MM-dd HH:mm:ss")  + " " + sInfo);
                InsertAlarmWarnToDataBase(sInfo);
            }

            //Back to Normal
            if(((pbyteAlarmBits != 0)||(pbyteWarningBits != 0)) && ((GlbByte.gbyteAlarmBits == 0)&& (GlbByte.gbyteWarningBits == 0)))
            {
                tmrAlarmSoundPlay.Enabled = false;
                tmrWarnSoundPlay.Enabled = false;
                sInfo = "Return to Normal";
                listBox1.Items.Add(GlbByte.gdtCurrent.ToString("yyyy-MM-dd HH:mm:ss") + " " + sInfo);
                InsertAlarmWarnToDataBase(sInfo);
            }


            pbyteAlarmBits = GlbByte.gbyteAlarmBits;
            pbyteWarningBits = GlbByte.gbyteWarningBits;
        }


        private void InsertAlarmWarnToDataBase(string sInfo)
        {
            //dbConnection = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source = " + GlbByte.msCurrentDirName + @"\TrinetData.mdb");
            //dbConnection.Open();


            OleDbCommand cmd = dbConnection.CreateCommand();

            cmd.CommandText = "Insert into AlarmWarnning " + "(dtDateTime, Location, sInform) " + "Values (" + "#" + GlbByte.gdtCurrent.ToString() + "#" + ", "
                                                                                                                + GlbByte.gbyteSampleLocation.ToString() + ", "                                                                                                               
                                                                                                                + "'" + sInfo+ "')";
            cmd.Connection = dbConnection;
            cmd.CommandType = CommandType.Text;

            cmd.ExecuteNonQuery();

            cmd.Dispose();

            //dbConnection.Close();

           //dbConnection.Dispose();

        }

        private void tmrSerialDataReceivingEndDetection_Tick(object sender, EventArgs e)
        {

            if ((pbUartReceived == true) && (piUartReceivedCnt_SAVED == piUartReceivedCnt) && (piUartReceivedCnt>5))
            {
                tmrSerialDataReceivingEndDetection.Enabled = false;
                processUARTData(1);
                piUartReceivedCnt_SAVED = 0;
            }
            piUartReceivedCnt_SAVED = piUartReceivedCnt;
        }


        private void processUARTData(int iTemp)
        {
            int i,j,k;
            ushort usTemp;
            byte[] data;
            byte byteTemp;

            // display Received
            lblReceived.Text = "Received: ";
            for (i = 0; i < piUartReceivedCnt; i++)
                lblReceived.Text = lblReceived.Text + " "+ arrByteRXBuf[i].ToString("x2");
            if (((arrByteRXBuf[0] == (byte)GlbByte.miHistSaveInterval)|| (GlbByte.miHistSaveInterval == 0)) && (arrByteRXBuf[1] == 3))
            {
                // CRC check
                usTemp = CRC16(arrByteRXBuf, (byte)(piUartReceivedCnt-2));
                if ((arrByteRXBuf[piUartReceivedCnt - 2] == (byte)(usTemp % 256)) && (arrByteRXBuf[piUartReceivedCnt - 1] == (byte)(usTemp / 256)))
                {
                    data = new byte[arrByteRXBuf[2]];
                    Array.Copy(arrByteRXBuf, 3, data, 0, arrByteRXBuf[2]);
                    Array.Copy(arrByteRXBuf, 3, GlbByte.GbyteReadBuf, 0, arrByteRXBuf[2]);

                    try
                    {

                        GlbByte.gsHoldingRegTableUpdateReg = 1;
                       
                        GlbByte.GbyteTCPReadRequested = 0;
                        GlbByte.GbyteTCPReadCompleted = 1;
                    }
                    catch (Exception ex)
                    {
                        //MessageBox.Show(ex.Message);
                    }

                }
            }

            // Input Register
            if (((arrByteRXBuf[0] == (byte)GlbByte.miHistSaveInterval) || (GlbByte.miHistSaveInterval == 0)) && (arrByteRXBuf[1] == 4))
            {
                // CRC check
                usTemp = CRC16(arrByteRXBuf, (byte)(piUartReceivedCnt - 2));
                if ((arrByteRXBuf[piUartReceivedCnt - 2] == (byte)(usTemp % 256)) && (arrByteRXBuf[piUartReceivedCnt - 1] == (byte)(usTemp / 256)))
                {
                    data = new byte[arrByteRXBuf[2]];
                    Array.Copy(arrByteRXBuf, 3, data, 0, arrByteRXBuf[2]);
                    Array.Copy(arrByteRXBuf, 3, GlbByte.GbyteReadBuf, 0, arrByteRXBuf[2]);

                    try
                    {

                        GlbByte.gsInputRegTableUpdateReg = 1;


                        GlbByte.giMeas1 =  (int)GlbByte.GbyteReadBuf[0] *256 + GlbByte.GbyteReadBuf[1];
                        
                        GlbByte.giMeas2 = (int)GlbByte.GbyteReadBuf[2] * 256 + GlbByte.GbyteReadBuf[3];

                        GlbByte.giComp1 = (int)GlbByte.GbyteReadBuf[4] * 256 + GlbByte.GbyteReadBuf[5];

                        GlbByte.giComp2 = (int)GlbByte.GbyteReadBuf[6] * 256 + GlbByte.GbyteReadBuf[7];

                        GlbByte.giGammaCnt = (int)GlbByte.GbyteReadBuf[8] * 256 + GlbByte.GbyteReadBuf[9];

                        i = (int)GlbByte.GbyteReadBuf[10] * 256 + GlbByte.GbyteReadBuf[11];
                        GlbByte.gsBodyTemp = (short)i;


                        // save to array for a day
                        //GlbByte.gdtBuf[GlbByte.giSavedDataPointer] = GlbByte.gdtCurrent;// new DateTime(GlbByte.gbyteYear + 2000, GlbByte.gbyteMonth, GlbByte.gbyteDay, GlbByte.gbyteHour, GlbByte.gbyteMinute, GlbByte.gbyteSec);
                        //GlbByte.giTritium[GlbByte.giSavedDataPointer] = GlbByte.giTritiumReadingInTenth;
                        //GlbByte.giGamma[GlbByte.giSavedDataPointer] = GlbByte.giGammaReadingInTenth;
                        GlbByte.giMeasCnt1[GlbByte.giSavedDataPointer] = GlbByte.giMeas1;
                        GlbByte.giMeasCnt2[GlbByte.giSavedDataPointer] = GlbByte.giMeas2;
                        GlbByte.giCompCnt1[GlbByte.giSavedDataPointer] = GlbByte.giComp1;
                        GlbByte.giCompCnt2[GlbByte.giSavedDataPointer] = GlbByte.giComp2;
                        GlbByte.giGMCnt[GlbByte.giSavedDataPointer] = GlbByte.giGammaCnt;
                        GlbByte.giBodyTmp[GlbByte.giSavedDataPointer] = (int)GlbByte.gsBodyTemp;
                        //GlbByte.giCmpRH[GlbByte.giSavedDataPointer] = (int)GlbByte.gsCompRH;
                        //GlbByte.giMiPre[GlbByte.giSavedDataPointer] = GlbByte.giMiKPa;
                        //GlbByte.giCiPre[GlbByte.giSavedDataPointer] = GlbByte.giCiKPa;
                        //GlbByte.giDpPre[GlbByte.giSavedDataPointer] = (int)GlbByte.gsDpKPa;
                        //GlbByte.giFlowRate[GlbByte.giSavedDataPointer] = (int)GlbByte.gsFlow;

                        //GlbByte.gbyteSmpLocArray[GlbByte.giSavedDataPointer] = GlbByte.gbyteSampleLocation;

                        GlbByte.giSavedDataPointer++;
                        if (GlbByte.giSavedDataPointer == 86400)
                        {
                            GlbByte.giSavedDataPointer = 0;
                            GlbByte.gbSavedDataFull = true;
                        }

                        GlbByte.GbyteTCPReadRequested = 0;
                        GlbByte.GbyteTCPReadCompleted = 1;
                    }
                    catch (Exception ex)
                    {
                        //MessageBox.Show(ex.Message);
                    }

                }
            }
            piUartReceivedCnt = 0;



        }

        byte[] arrByteTXBuf = new byte[256];

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void sendFunc16(byte[] btData,byte btNumberBytesTobeWritten)
        {
            int i;
            ushort usTemp;
            byte byteNumOfByte;

            arrByteTXBuf[0] = (byte)GlbByte.miHistSaveInterval;//mbyteSlaveAddress; //address
            arrByteTXBuf[1] = 16;   //  Function Code

            arrByteTXBuf[2] = 0;    //  Start Address Hi Byte
            arrByteTXBuf[3] = (byte)GlbByte.gsModbusStartReg;//0;    //  Start Address Lo Byte
            arrByteTXBuf[4] = 0;    //  Number of Regs Hi Byte
            arrByteTXBuf[5] = (byte)GlbByte.gsModbusNumberReg;//(byte)(btNumberBytesTobeWritten/2);    //  Number of Regs Lo Byte
            byteNumOfByte = (byte)(GlbByte.gsModbusNumberReg * 2);
            arrByteTXBuf[6] = byteNumOfByte;//btNumberBytesTobeWritten;    //  Number of Bytes to be write
            for (i = 0; i < byteNumOfByte; i++)
            {
                arrByteTXBuf[7 + i] = btData[i];
            }
            usTemp = CRC16(arrByteTXBuf, (byte)(7+ byteNumOfByte));
            arrByteTXBuf[7+ byteNumOfByte] = (byte)(usTemp % 256);
            arrByteTXBuf[8 + byteNumOfByte] = (byte)(usTemp/256);          

            serialPort1.Write(arrByteTXBuf, 0, 9 + byteNumOfByte);
            lblSent.Text = "Sent:";
            lblSent3.Text = "";
            if (byteNumOfByte < 30)
            {
                for (i = 0; i < 9 + byteNumOfByte; i++)
                    lblSent.Text = lblSent.Text + " " + arrByteTXBuf[i].ToString("x2");
            }
            else
            {
                for (i = 0; i < 39; i++)
                    lblSent.Text = lblSent.Text + " " + arrByteTXBuf[i].ToString("x2");                
                for (i = 39; i < 9 + byteNumOfByte; i++)
                    lblSent3.Text = lblSent3.Text + " " + arrByteTXBuf[i].ToString("x2");


            }
        }

        private void menuStrip1_ItemClicked_2(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void readHoldingReg(ushort usStartAddress, ushort usRegLen)
        {
            int i;
            ushort usTemp;
            arrByteTXBuf[0] = (byte)GlbByte.miHistSaveInterval;// mbyteSlaveAddress; //address
            arrByteTXBuf[1] = 3;   //  Function Code
            arrByteTXBuf[2] = (byte)(usStartAddress/256);    //  Start Address Hi Byte
            arrByteTXBuf[3] = (byte)(usStartAddress%256);    //  Start Address Lo Byte
            arrByteTXBuf[4] = 0;    //  Number of Regs Hi Byte
            arrByteTXBuf[5] = (byte)(usRegLen);    //  Number of Regs Lo Byte            
            
            usTemp = CRC16(arrByteTXBuf, 6);
            arrByteTXBuf[6] = (byte)(usTemp % 256);
            arrByteTXBuf[7] = (byte)(usTemp / 256);

            serialPort1.Write(arrByteTXBuf, 0, 8);

            lblSent.Text = "Sent:";
            lblSent3.Text = "";
            for (i = 0; i < 8; i++)
                lblSent.Text = lblSent.Text + " " + arrByteTXBuf[i].ToString("x2");
            
            //GlbByte.GbyteTCPReadRequested = 1;
            piUartReceivedCnt = 0;
            pbUartReceived = false;
    }

        private void readInputReg(ushort usStartAddress, ushort usRegLen)
        {
            int i;
            ushort usTemp;
            arrByteTXBuf[0] = (byte)GlbByte.miHistSaveInterval;// mbyteSlaveAddress; //address
            arrByteTXBuf[1] = 4;   //  Function Code
            arrByteTXBuf[2] = (byte)(usStartAddress / 256);    //  Start Address Hi Byte
            arrByteTXBuf[3] = (byte)(usStartAddress % 256);    //  Start Address Lo Byte
            arrByteTXBuf[4] = 0;    //  Number of Regs Hi Byte
            arrByteTXBuf[5] = (byte)(usRegLen);    //  Number of Regs Lo Byte            

            usTemp = CRC16(arrByteTXBuf, 6);
            arrByteTXBuf[6] = (byte)(usTemp % 256);
            arrByteTXBuf[7] = (byte)(usTemp / 256);

            serialPort1.Write(arrByteTXBuf, 0, 8);

            lblSent.Text = "Sent:";
            lblSent3.Text = "";
            for (i = 0; i < 8; i++)
                lblSent.Text = lblSent.Text + " " + arrByteTXBuf[i].ToString("x2");

            //GlbByte.GbyteTCPReadRequested = 1;
            piUartReceivedCnt = 0;
            pbUartReceived = false;
        }

        private ushort[] wCRCTable = new ushort[256] {
        0X0000, 0XC0C1, 0XC181, 0X0140, 0XC301, 0X03C0, 0X0280, 0XC241,
        0XC601, 0X06C0, 0X0780, 0XC741, 0X0500, 0XC5C1, 0XC481, 0X0440,
        0XCC01, 0X0CC0, 0X0D80, 0XCD41, 0X0F00, 0XCFC1, 0XCE81, 0X0E40,
        0X0A00, 0XCAC1, 0XCB81, 0X0B40, 0XC901, 0X09C0, 0X0880, 0XC841,
        0XD801, 0X18C0, 0X1980, 0XD941, 0X1B00, 0XDBC1, 0XDA81, 0X1A40,
        0X1E00, 0XDEC1, 0XDF81, 0X1F40, 0XDD01, 0X1DC0, 0X1C80, 0XDC41,
        0X1400, 0XD4C1, 0XD581, 0X1540, 0XD701, 0X17C0, 0X1680, 0XD641,
        0XD201, 0X12C0, 0X1380, 0XD341, 0X1100, 0XD1C1, 0XD081, 0X1040,
        0XF001, 0X30C0, 0X3180, 0XF141, 0X3300, 0XF3C1, 0XF281, 0X3240,
        0X3600, 0XF6C1, 0XF781, 0X3740, 0XF501, 0X35C0, 0X3480, 0XF441,
        0X3C00, 0XFCC1, 0XFD81, 0X3D40, 0XFF01, 0X3FC0, 0X3E80, 0XFE41,
        0XFA01, 0X3AC0, 0X3B80, 0XFB41, 0X3900, 0XF9C1, 0XF881, 0X3840,
        0X2800, 0XE8C1, 0XE981, 0X2940, 0XEB01, 0X2BC0, 0X2A80, 0XEA41,
        0XEE01, 0X2EC0, 0X2F80, 0XEF41, 0X2D00, 0XEDC1, 0XEC81, 0X2C40,
        0XE401, 0X24C0, 0X2580, 0XE541, 0X2700, 0XE7C1, 0XE681, 0X2640,
        0X2200, 0XE2C1, 0XE381, 0X2340, 0XE101, 0X21C0, 0X2080, 0XE041,
        0XA001, 0X60C0, 0X6180, 0XA141, 0X6300, 0XA3C1, 0XA281, 0X6240,
        0X6600, 0XA6C1, 0XA781, 0X6740, 0XA501, 0X65C0, 0X6480, 0XA441,
        0X6C00, 0XACC1, 0XAD81, 0X6D40, 0XAF01, 0X6FC0, 0X6E80, 0XAE41,
        0XAA01, 0X6AC0, 0X6B80, 0XAB41, 0X6900, 0XA9C1, 0XA881, 0X6840,
        0X7800, 0XB8C1, 0XB981, 0X7940, 0XBB01, 0X7BC0, 0X7A80, 0XBA41,
        0XBE01, 0X7EC0, 0X7F80, 0XBF41, 0X7D00, 0XBDC1, 0XBC81, 0X7C40,
        0XB401, 0X74C0, 0X7580, 0XB541, 0X7700, 0XB7C1, 0XB681, 0X7640,
        0X7200, 0XB2C1, 0XB381, 0X7340, 0XB101, 0X71C0, 0X7080, 0XB041,
        0X5000, 0X90C1, 0X9181, 0X5140, 0X9301, 0X53C0, 0X5280, 0X9241,
        0X9601, 0X56C0, 0X5780, 0X9741, 0X5500, 0X95C1, 0X9481, 0X5440,
        0X9C01, 0X5CC0, 0X5D80, 0X9D41, 0X5F00, 0X9FC1, 0X9E81, 0X5E40,
        0X5A00, 0X9AC1, 0X9B81, 0X5B40, 0X9901, 0X59C0, 0X5880, 0X9841,
        0X8801, 0X48C0, 0X4980, 0X8941, 0X4B00, 0X8BC1, 0X8A81, 0X4A40,
        0X4E00, 0X8EC1, 0X8F81, 0X4F40, 0X8D01, 0X4DC0, 0X4C80, 0X8C41,
        0X4400, 0X84C1, 0X8581, 0X4540, 0X8701, 0X47C0, 0X4680, 0X8641,
        0X8201, 0X42C0, 0X4380, 0X8341, 0X4100, 0X81C1, 0X8081, 0X4040 };

         private  ushort CRC16(byte[] puchMsg, ushort usDataLen)
         {
            byte nTemp;
            int  k, h;
            ushort i;
            ushort wCRCWord = 0xFFFF;

            //while (usDataLen--)
            for(i = 0; i < usDataLen; i++)
            {
                //nTemp = *puchMsg++ ^ wCRCWord;               
                nTemp = (byte)(puchMsg[i] ^ (byte)wCRCWord);   
                
                wCRCWord >>= 8;
                wCRCWord ^= wCRCTable[nTemp];
            }
            return wCRCWord;

         }








    }
}
