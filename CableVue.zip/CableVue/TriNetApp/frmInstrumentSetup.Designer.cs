﻿namespace TriNet
{
    partial class frmInstrumentSetup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblLocation = new System.Windows.Forms.Label();
            this.lblLocationData = new System.Windows.Forms.Label();
            this.lblTritiumAlarm = new System.Windows.Forms.Label();
            this.lblTritiumAlarmData = new System.Windows.Forms.Label();
            this.lblGammaAlarm = new System.Windows.Forms.Label();
            this.lblGammaAlarmData = new System.Windows.Forms.Label();
            this.lblTritiumGain = new System.Windows.Forms.Label();
            this.lblGammaGain = new System.Windows.Forms.Label();
            this.lblTritiumGainData = new System.Windows.Forms.Label();
            this.lblGammaGainData = new System.Windows.Forms.Label();
            this.lblInstrumentDateTime = new System.Windows.Forms.Label();
            this.lblDateTimeData = new System.Windows.Forms.Label();
            this.lblTemperatureSettingData = new System.Windows.Forms.Label();
            this.lblFlowCalFactor = new System.Windows.Forms.Label();
            this.lblFlowCaliFactorData = new System.Windows.Forms.Label();
            this.lblPressureCalFactor = new System.Windows.Forms.Label();
            this.lblMeasurePressureFactorData = new System.Windows.Forms.Label();
            this.lblCompPressureFactorData = new System.Windows.Forms.Label();
            this.lblInstrumentLogInterval = new System.Windows.Forms.Label();
            this.lblLogIntervalData = new System.Windows.Forms.Label();
            this.lblTempSetting = new System.Windows.Forms.Label();
            this.lblDrierAlarm = new System.Windows.Forms.Label();
            this.lblDrierRHSettingData = new System.Windows.Forms.Label();
            this.lblPumpSpeed = new System.Windows.Forms.Label();
            this.lblPumpSpeedData = new System.Windows.Forms.Label();
            this.lblPressureCompEnable = new System.Windows.Forms.Label();
            this.lblPressureCompensationSelData = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblRequest = new System.Windows.Forms.Label();
            this.btnEnter = new System.Windows.Forms.Button();
            this.txtBoxInput = new System.Windows.Forms.TextBox();
            this.lblHelpInfo = new System.Windows.Forms.Label();
            this.tmrTaskTick = new System.Windows.Forms.Timer(this.components);
            this.label17 = new System.Windows.Forms.Label();
            this.lblEngUnit = new System.Windows.Forms.Label();
            this.tmrSendingCommand = new System.Windows.Forms.Timer(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.btn0 = new System.Windows.Forms.Button();
            this.btn1 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn7 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.btnDOT = new System.Windows.Forms.Button();
            this.btnCLR = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.dgrdHoldingRegTable = new System.Windows.Forms.DataGridView();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgrdHoldingRegTable)).BeginInit();
            this.SuspendLayout();
            // 
            // lblLocation
            // 
            this.lblLocation.AutoSize = true;
            this.lblLocation.BackColor = System.Drawing.Color.LightGray;
            this.lblLocation.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLocation.Location = new System.Drawing.Point(26, 23);
            this.lblLocation.Name = "lblLocation";
            this.lblLocation.Size = new System.Drawing.Size(202, 26);
            this.lblLocation.TabIndex = 0;
            this.lblLocation.Text = "Instrument Unit ID:";
            this.lblLocation.Click += new System.EventHandler(this.lblLocation_Click);
            // 
            // lblLocationData
            // 
            this.lblLocationData.AutoSize = true;
            this.lblLocationData.BackColor = System.Drawing.Color.LightGray;
            this.lblLocationData.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLocationData.ForeColor = System.Drawing.Color.Blue;
            this.lblLocationData.Location = new System.Drawing.Point(336, 23);
            this.lblLocationData.Name = "lblLocationData";
            this.lblLocationData.Size = new System.Drawing.Size(122, 26);
            this.lblLocationData.TabIndex = 1;
            this.lblLocationData.Text = "Loop Scan";
            // 
            // lblTritiumAlarm
            // 
            this.lblTritiumAlarm.AutoSize = true;
            this.lblTritiumAlarm.BackColor = System.Drawing.Color.LightGray;
            this.lblTritiumAlarm.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTritiumAlarm.Location = new System.Drawing.Point(26, 75);
            this.lblTritiumAlarm.Name = "lblTritiumAlarm";
            this.lblTritiumAlarm.Size = new System.Drawing.Size(291, 26);
            this.lblTritiumAlarm.TabIndex = 2;
            this.lblTritiumAlarm.Text = "Tritium  Alarm Level 2 (HH):";
            this.lblTritiumAlarm.Click += new System.EventHandler(this.lblTritiumAlarm_Click);
            // 
            // lblTritiumAlarmData
            // 
            this.lblTritiumAlarmData.AutoSize = true;
            this.lblTritiumAlarmData.BackColor = System.Drawing.Color.LightGray;
            this.lblTritiumAlarmData.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTritiumAlarmData.ForeColor = System.Drawing.Color.Blue;
            this.lblTritiumAlarmData.Location = new System.Drawing.Point(336, 75);
            this.lblTritiumAlarmData.Name = "lblTritiumAlarmData";
            this.lblTritiumAlarmData.Size = new System.Drawing.Size(60, 26);
            this.lblTritiumAlarmData.TabIndex = 3;
            this.lblTritiumAlarmData.Text = "1000";
            // 
            // lblGammaAlarm
            // 
            this.lblGammaAlarm.AutoSize = true;
            this.lblGammaAlarm.BackColor = System.Drawing.Color.LightGray;
            this.lblGammaAlarm.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGammaAlarm.Location = new System.Drawing.Point(558, 75);
            this.lblGammaAlarm.Name = "lblGammaAlarm";
            this.lblGammaAlarm.Size = new System.Drawing.Size(208, 26);
            this.lblGammaAlarm.TabIndex = 5;
            this.lblGammaAlarm.Text = "GM Gamma  Alarm:";
            this.lblGammaAlarm.Click += new System.EventHandler(this.lblGammaAlarm_Click);
            // 
            // lblGammaAlarmData
            // 
            this.lblGammaAlarmData.AutoSize = true;
            this.lblGammaAlarmData.BackColor = System.Drawing.Color.LightGray;
            this.lblGammaAlarmData.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGammaAlarmData.ForeColor = System.Drawing.Color.Blue;
            this.lblGammaAlarmData.Location = new System.Drawing.Point(875, 75);
            this.lblGammaAlarmData.Name = "lblGammaAlarmData";
            this.lblGammaAlarmData.Size = new System.Drawing.Size(60, 26);
            this.lblGammaAlarmData.TabIndex = 7;
            this.lblGammaAlarmData.Text = "1000";
            // 
            // lblTritiumGain
            // 
            this.lblTritiumGain.AutoSize = true;
            this.lblTritiumGain.BackColor = System.Drawing.Color.LightGray;
            this.lblTritiumGain.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTritiumGain.Location = new System.Drawing.Point(26, 121);
            this.lblTritiumGain.Name = "lblTritiumGain";
            this.lblTritiumGain.Size = new System.Drawing.Size(149, 26);
            this.lblTritiumGain.TabIndex = 8;
            this.lblTritiumGain.Text = "Tritium  Gain:";
            this.lblTritiumGain.Click += new System.EventHandler(this.lblTritiumGain_Click);
            // 
            // lblGammaGain
            // 
            this.lblGammaGain.AutoSize = true;
            this.lblGammaGain.BackColor = System.Drawing.Color.LightGray;
            this.lblGammaGain.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGammaGain.Location = new System.Drawing.Point(562, 121);
            this.lblGammaGain.Name = "lblGammaGain";
            this.lblGammaGain.Size = new System.Drawing.Size(191, 26);
            this.lblGammaGain.TabIndex = 9;
            this.lblGammaGain.Text = "GM Gamma Gain:";
            this.lblGammaGain.Click += new System.EventHandler(this.lblGammaGain_Click);
            // 
            // lblTritiumGainData
            // 
            this.lblTritiumGainData.AutoSize = true;
            this.lblTritiumGainData.BackColor = System.Drawing.Color.LightGray;
            this.lblTritiumGainData.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTritiumGainData.ForeColor = System.Drawing.Color.Blue;
            this.lblTritiumGainData.Location = new System.Drawing.Point(336, 121);
            this.lblTritiumGainData.Name = "lblTritiumGainData";
            this.lblTritiumGainData.Size = new System.Drawing.Size(66, 26);
            this.lblTritiumGainData.TabIndex = 10;
            this.lblTritiumGainData.Text = "0.000";
            // 
            // lblGammaGainData
            // 
            this.lblGammaGainData.AutoSize = true;
            this.lblGammaGainData.BackColor = System.Drawing.Color.LightGray;
            this.lblGammaGainData.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGammaGainData.ForeColor = System.Drawing.Color.Blue;
            this.lblGammaGainData.Location = new System.Drawing.Point(875, 121);
            this.lblGammaGainData.Name = "lblGammaGainData";
            this.lblGammaGainData.Size = new System.Drawing.Size(66, 26);
            this.lblGammaGainData.TabIndex = 11;
            this.lblGammaGainData.Text = "0.000";
            // 
            // lblInstrumentDateTime
            // 
            this.lblInstrumentDateTime.AutoSize = true;
            this.lblInstrumentDateTime.BackColor = System.Drawing.Color.LightGray;
            this.lblInstrumentDateTime.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInstrumentDateTime.Location = new System.Drawing.Point(26, 164);
            this.lblInstrumentDateTime.Name = "lblInstrumentDateTime";
            this.lblInstrumentDateTime.Size = new System.Drawing.Size(291, 26);
            this.lblInstrumentDateTime.TabIndex = 12;
            this.lblInstrumentDateTime.Text = "Instrument RTC Date/Time:";
            this.lblInstrumentDateTime.Click += new System.EventHandler(this.lblInstrumentDateTime_Click);
            // 
            // lblDateTimeData
            // 
            this.lblDateTimeData.AutoSize = true;
            this.lblDateTimeData.BackColor = System.Drawing.Color.LightGray;
            this.lblDateTimeData.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDateTimeData.ForeColor = System.Drawing.Color.Blue;
            this.lblDateTimeData.Location = new System.Drawing.Point(336, 164);
            this.lblDateTimeData.Name = "lblDateTimeData";
            this.lblDateTimeData.Size = new System.Drawing.Size(214, 26);
            this.lblDateTimeData.TabIndex = 13;
            this.lblDateTimeData.Text = "2019-09-01 17:45:56";
            // 
            // lblTemperatureSettingData
            // 
            this.lblTemperatureSettingData.AutoSize = true;
            this.lblTemperatureSettingData.BackColor = System.Drawing.Color.LightGray;
            this.lblTemperatureSettingData.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTemperatureSettingData.ForeColor = System.Drawing.Color.Blue;
            this.lblTemperatureSettingData.Location = new System.Drawing.Point(881, 164);
            this.lblTemperatureSettingData.Name = "lblTemperatureSettingData";
            this.lblTemperatureSettingData.Size = new System.Drawing.Size(54, 26);
            this.lblTemperatureSettingData.TabIndex = 15;
            this.lblTemperatureSettingData.Text = "56.8";
            // 
            // lblFlowCalFactor
            // 
            this.lblFlowCalFactor.AutoSize = true;
            this.lblFlowCalFactor.BackColor = System.Drawing.Color.LightGray;
            this.lblFlowCalFactor.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFlowCalFactor.Location = new System.Drawing.Point(26, 219);
            this.lblFlowCalFactor.Name = "lblFlowCalFactor";
            this.lblFlowCalFactor.Size = new System.Drawing.Size(255, 26);
            this.lblFlowCalFactor.TabIndex = 16;
            this.lblFlowCalFactor.Text = "Flow Calibration Factor:";
            this.lblFlowCalFactor.Click += new System.EventHandler(this.lblFlowCalFactor_Click);
            // 
            // lblFlowCaliFactorData
            // 
            this.lblFlowCaliFactorData.AutoSize = true;
            this.lblFlowCaliFactorData.BackColor = System.Drawing.Color.LightGray;
            this.lblFlowCaliFactorData.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFlowCaliFactorData.ForeColor = System.Drawing.Color.Blue;
            this.lblFlowCaliFactorData.Location = new System.Drawing.Point(336, 219);
            this.lblFlowCaliFactorData.Name = "lblFlowCaliFactorData";
            this.lblFlowCaliFactorData.Size = new System.Drawing.Size(66, 26);
            this.lblFlowCaliFactorData.TabIndex = 17;
            this.lblFlowCaliFactorData.Text = "1.000";
            // 
            // lblPressureCalFactor
            // 
            this.lblPressureCalFactor.AutoSize = true;
            this.lblPressureCalFactor.BackColor = System.Drawing.Color.LightGray;
            this.lblPressureCalFactor.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPressureCalFactor.Location = new System.Drawing.Point(562, 219);
            this.lblPressureCalFactor.Name = "lblPressureCalFactor";
            this.lblPressureCalFactor.Size = new System.Drawing.Size(297, 26);
            this.lblPressureCalFactor.TabIndex = 18;
            this.lblPressureCalFactor.Text = "Pressure Calibration Factor:";
            this.lblPressureCalFactor.Click += new System.EventHandler(this.lblPressureCalFactor_Click);
            // 
            // lblMeasurePressureFactorData
            // 
            this.lblMeasurePressureFactorData.AutoSize = true;
            this.lblMeasurePressureFactorData.BackColor = System.Drawing.Color.LightGray;
            this.lblMeasurePressureFactorData.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMeasurePressureFactorData.ForeColor = System.Drawing.Color.Blue;
            this.lblMeasurePressureFactorData.Location = new System.Drawing.Point(881, 219);
            this.lblMeasurePressureFactorData.Name = "lblMeasurePressureFactorData";
            this.lblMeasurePressureFactorData.Size = new System.Drawing.Size(66, 26);
            this.lblMeasurePressureFactorData.TabIndex = 19;
            this.lblMeasurePressureFactorData.Text = "1.000";
            this.lblMeasurePressureFactorData.Click += new System.EventHandler(this.lblMeasurePressureFactorData_Click);
            // 
            // lblCompPressureFactorData
            // 
            this.lblCompPressureFactorData.AutoSize = true;
            this.lblCompPressureFactorData.BackColor = System.Drawing.Color.LightGray;
            this.lblCompPressureFactorData.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCompPressureFactorData.ForeColor = System.Drawing.Color.Blue;
            this.lblCompPressureFactorData.Location = new System.Drawing.Point(984, 219);
            this.lblCompPressureFactorData.Name = "lblCompPressureFactorData";
            this.lblCompPressureFactorData.Size = new System.Drawing.Size(66, 26);
            this.lblCompPressureFactorData.TabIndex = 20;
            this.lblCompPressureFactorData.Text = "1.001";
            // 
            // lblInstrumentLogInterval
            // 
            this.lblInstrumentLogInterval.AutoSize = true;
            this.lblInstrumentLogInterval.BackColor = System.Drawing.Color.LightGray;
            this.lblInstrumentLogInterval.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInstrumentLogInterval.Location = new System.Drawing.Point(26, 272);
            this.lblInstrumentLogInterval.Name = "lblInstrumentLogInterval";
            this.lblInstrumentLogInterval.Size = new System.Drawing.Size(263, 26);
            this.lblInstrumentLogInterval.TabIndex = 21;
            this.lblInstrumentLogInterval.Text = "Tritium Alarm Level 1(H):";
            this.lblInstrumentLogInterval.Click += new System.EventHandler(this.lblInstrumentLogInterval_Click);
            // 
            // lblLogIntervalData
            // 
            this.lblLogIntervalData.AutoSize = true;
            this.lblLogIntervalData.BackColor = System.Drawing.Color.LightGray;
            this.lblLogIntervalData.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogIntervalData.ForeColor = System.Drawing.Color.Blue;
            this.lblLogIntervalData.Location = new System.Drawing.Point(337, 272);
            this.lblLogIntervalData.Name = "lblLogIntervalData";
            this.lblLogIntervalData.Size = new System.Drawing.Size(36, 26);
            this.lblLogIntervalData.TabIndex = 22;
            this.lblLogIntervalData.Text = "10";
            this.lblLogIntervalData.Click += new System.EventHandler(this.lblLogIntervalData_Click);
            // 
            // lblTempSetting
            // 
            this.lblTempSetting.AutoSize = true;
            this.lblTempSetting.BackColor = System.Drawing.Color.LightGray;
            this.lblTempSetting.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTempSetting.Location = new System.Drawing.Point(562, 164);
            this.lblTempSetting.Name = "lblTempSetting";
            this.lblTempSetting.Size = new System.Drawing.Size(265, 26);
            this.lblTempSetting.TabIndex = 23;
            this.lblTempSetting.Text = "Temperature Setting(°C):";
            this.lblTempSetting.Click += new System.EventHandler(this.lblTempSetting_Click);
            // 
            // lblDrierAlarm
            // 
            this.lblDrierAlarm.AutoSize = true;
            this.lblDrierAlarm.BackColor = System.Drawing.Color.LightGray;
            this.lblDrierAlarm.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDrierAlarm.Location = new System.Drawing.Point(562, 272);
            this.lblDrierAlarm.Name = "lblDrierAlarm";
            this.lblDrierAlarm.Size = new System.Drawing.Size(274, 26);
            this.lblDrierAlarm.TabIndex = 24;
            this.lblDrierAlarm.Text = "Drier Alarm Setting(%RH):";
            this.lblDrierAlarm.Click += new System.EventHandler(this.lblDrierAlarm_Click);
            // 
            // lblDrierRHSettingData
            // 
            this.lblDrierRHSettingData.AutoSize = true;
            this.lblDrierRHSettingData.BackColor = System.Drawing.Color.LightGray;
            this.lblDrierRHSettingData.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDrierRHSettingData.ForeColor = System.Drawing.Color.Blue;
            this.lblDrierRHSettingData.Location = new System.Drawing.Point(887, 272);
            this.lblDrierRHSettingData.Name = "lblDrierRHSettingData";
            this.lblDrierRHSettingData.Size = new System.Drawing.Size(60, 26);
            this.lblDrierRHSettingData.TabIndex = 25;
            this.lblDrierRHSettingData.Text = "1000";
            // 
            // lblPumpSpeed
            // 
            this.lblPumpSpeed.AutoSize = true;
            this.lblPumpSpeed.BackColor = System.Drawing.Color.LightGray;
            this.lblPumpSpeed.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPumpSpeed.Location = new System.Drawing.Point(26, 321);
            this.lblPumpSpeed.Name = "lblPumpSpeed";
            this.lblPumpSpeed.Size = new System.Drawing.Size(182, 26);
            this.lblPumpSpeed.TabIndex = 26;
            this.lblPumpSpeed.Text = "Pump Speed(%):";
            this.lblPumpSpeed.Click += new System.EventHandler(this.label8_Click);
            // 
            // lblPumpSpeedData
            // 
            this.lblPumpSpeedData.AutoSize = true;
            this.lblPumpSpeedData.BackColor = System.Drawing.Color.LightGray;
            this.lblPumpSpeedData.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPumpSpeedData.ForeColor = System.Drawing.Color.Blue;
            this.lblPumpSpeedData.Location = new System.Drawing.Point(337, 321);
            this.lblPumpSpeedData.Name = "lblPumpSpeedData";
            this.lblPumpSpeedData.Size = new System.Drawing.Size(48, 26);
            this.lblPumpSpeedData.TabIndex = 27;
            this.lblPumpSpeedData.Text = "100";
            // 
            // lblPressureCompEnable
            // 
            this.lblPressureCompEnable.AutoSize = true;
            this.lblPressureCompEnable.BackColor = System.Drawing.Color.LightGray;
            this.lblPressureCompEnable.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPressureCompEnable.Location = new System.Drawing.Point(563, 321);
            this.lblPressureCompEnable.Name = "lblPressureCompEnable";
            this.lblPressureCompEnable.Size = new System.Drawing.Size(265, 26);
            this.lblPressureCompEnable.TabIndex = 28;
            this.lblPressureCompEnable.Text = "Pressure Compensation:";
            this.lblPressureCompEnable.Click += new System.EventHandler(this.lblPressureCompEnable_Click);
            // 
            // lblPressureCompensationSelData
            // 
            this.lblPressureCompensationSelData.AutoSize = true;
            this.lblPressureCompensationSelData.BackColor = System.Drawing.Color.LightGray;
            this.lblPressureCompensationSelData.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPressureCompensationSelData.ForeColor = System.Drawing.Color.Blue;
            this.lblPressureCompensationSelData.Location = new System.Drawing.Point(887, 321);
            this.lblPressureCompensationSelData.Name = "lblPressureCompensationSelData";
            this.lblPressureCompensationSelData.Size = new System.Drawing.Size(95, 26);
            this.lblPressureCompensationSelData.TabIndex = 29;
            this.lblPressureCompensationSelData.Text = "Enabled";
            this.lblPressureCompensationSelData.Click += new System.EventHandler(this.lblPressureCompensationSelData_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.PaleTurquoise;
            this.panel1.Controls.Add(this.textBox6);
            this.panel1.Controls.Add(this.textBox5);
            this.panel1.Controls.Add(this.textBox4);
            this.panel1.Controls.Add(this.textBox3);
            this.panel1.Controls.Add(this.textBox2);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(544, 394);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(529, 115);
            this.panel1.TabIndex = 30;
            this.panel1.Visible = false;
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox6.Location = new System.Drawing.Point(421, 77);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(96, 29);
            this.textBox6.TabIndex = 44;
            this.textBox6.MouseEnter += new System.EventHandler(this.textBox6_MouseEnter);
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(315, 77);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(96, 29);
            this.textBox5.TabIndex = 43;
            this.textBox5.MouseEnter += new System.EventHandler(this.textBox5_MouseEnter);
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(211, 77);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(96, 29);
            this.textBox4.TabIndex = 42;
            this.textBox4.MouseEnter += new System.EventHandler(this.textBox4_MouseEnter);
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(109, 77);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(96, 29);
            this.textBox3.TabIndex = 41;
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            this.textBox3.MouseEnter += new System.EventHandler(this.textBox3_MouseEnter);
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(3, 77);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(96, 29);
            this.textBox2.TabIndex = 35;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            this.textBox2.MouseEnter += new System.EventHandler(this.textBox2_MouseEnter);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(417, 38);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(89, 19);
            this.label16.TabIndex = 40;
            this.label16.Text = "Location 5";
            this.label16.Click += new System.EventHandler(this.label16_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(311, 38);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(89, 19);
            this.label15.TabIndex = 39;
            this.label15.Text = "Location 4";
            this.label15.Click += new System.EventHandler(this.label15_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(207, 38);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(89, 19);
            this.label14.TabIndex = 38;
            this.label14.Text = "Location 3";
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(103, 38);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(89, 19);
            this.label13.TabIndex = 37;
            this.label13.Text = "Location 2";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(3, 38);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(89, 19);
            this.label12.TabIndex = 36;
            this.label12.Text = "Location 1";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(151, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(291, 22);
            this.label1.TabIndex = 35;
            this.label1.Text = "Loop Scan Default Timming(S)";
            // 
            // lblRequest
            // 
            this.lblRequest.AutoSize = true;
            this.lblRequest.BackColor = System.Drawing.Color.Red;
            this.lblRequest.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRequest.ForeColor = System.Drawing.Color.Blue;
            this.lblRequest.Location = new System.Drawing.Point(26, 479);
            this.lblRequest.Name = "lblRequest";
            this.lblRequest.Size = new System.Drawing.Size(279, 26);
            this.lblRequest.TabIndex = 31;
            this.lblRequest.Text = "Enter Password to Log in:";
            // 
            // btnEnter
            // 
            this.btnEnter.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnEnter.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEnter.Location = new System.Drawing.Point(946, 665);
            this.btnEnter.Name = "btnEnter";
            this.btnEnter.Size = new System.Drawing.Size(291, 41);
            this.btnEnter.TabIndex = 32;
            this.btnEnter.Text = "Write (Function Code 16)";
            this.btnEnter.UseVisualStyleBackColor = false;
            this.btnEnter.Click += new System.EventHandler(this.btnEnter_Click);
            // 
            // txtBoxInput
            // 
            this.txtBoxInput.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxInput.Location = new System.Drawing.Point(452, 472);
            this.txtBoxInput.Name = "txtBoxInput";
            this.txtBoxInput.Size = new System.Drawing.Size(89, 32);
            this.txtBoxInput.TabIndex = 33;
            this.txtBoxInput.TextChanged += new System.EventHandler(this.txtBoxInput_TextChanged);
            this.txtBoxInput.MouseEnter += new System.EventHandler(this.txtBoxInput_MouseEnter);
            // 
            // lblHelpInfo
            // 
            this.lblHelpInfo.AutoSize = true;
            this.lblHelpInfo.BackColor = System.Drawing.Color.Transparent;
            this.lblHelpInfo.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHelpInfo.ForeColor = System.Drawing.Color.Blue;
            this.lblHelpInfo.Location = new System.Drawing.Point(26, 518);
            this.lblHelpInfo.Name = "lblHelpInfo";
            this.lblHelpInfo.Size = new System.Drawing.Size(142, 26);
            this.lblHelpInfo.TabIndex = 34;
            this.lblHelpInfo.Text = "Hint: 3 Digits";
            this.lblHelpInfo.Click += new System.EventHandler(this.lblHelpInfo_Click);
            // 
            // tmrTaskTick
            // 
            this.tmrTaskTick.Enabled = true;
            this.tmrTaskTick.Interval = 1000;
            this.tmrTaskTick.Tick += new System.EventHandler(this.tmrTaskTick_Tick);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.LightGray;
            this.label17.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(557, 23);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(188, 26);
            this.label17.TabIndex = 35;
            this.label17.Text = "Engineering Unit:";
            this.label17.Click += new System.EventHandler(this.label17_Click);
            // 
            // lblEngUnit
            // 
            this.lblEngUnit.AutoSize = true;
            this.lblEngUnit.BackColor = System.Drawing.Color.LightGray;
            this.lblEngUnit.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEngUnit.ForeColor = System.Drawing.Color.Blue;
            this.lblEngUnit.Location = new System.Drawing.Point(875, 23);
            this.lblEngUnit.Name = "lblEngUnit";
            this.lblEngUnit.Size = new System.Drawing.Size(83, 26);
            this.lblEngUnit.TabIndex = 36;
            this.lblEngUnit.Text = "µCi/m3";
            this.lblEngUnit.Click += new System.EventHandler(this.label18_Click);
            // 
            // tmrSendingCommand
            // 
            this.tmrSendingCommand.Enabled = true;
            this.tmrSendingCommand.Interval = 1000;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(718, 578);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(415, 35);
            this.button1.TabIndex = 37;
            this.button1.Text = "Exit and Return Main Screen";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(31, 370);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(177, 34);
            this.button2.TabIndex = 38;
            this.button2.Text = "Turn Pump ON";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(31, 419);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(184, 34);
            this.button3.TabIndex = 39;
            this.button3.Text = "Turn Pump OFF";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Visible = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 250;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // btn0
            // 
            this.btn0.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn0.Location = new System.Drawing.Point(3, 567);
            this.btn0.Name = "btn0";
            this.btn0.Size = new System.Drawing.Size(65, 52);
            this.btn0.TabIndex = 40;
            this.btn0.Text = "0";
            this.btn0.UseVisualStyleBackColor = false;
            this.btn0.Click += new System.EventHandler(this.btn0_Click);
            // 
            // btn1
            // 
            this.btn1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn1.Location = new System.Drawing.Point(83, 567);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(65, 52);
            this.btn1.TabIndex = 41;
            this.btn1.Text = "1";
            this.btn1.UseVisualStyleBackColor = false;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // btn2
            // 
            this.btn2.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn2.Location = new System.Drawing.Point(164, 568);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(65, 52);
            this.btn2.TabIndex = 42;
            this.btn2.Text = "2";
            this.btn2.UseVisualStyleBackColor = false;
            this.btn2.Click += new System.EventHandler(this.btn2_Click);
            // 
            // btn3
            // 
            this.btn3.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn3.Location = new System.Drawing.Point(244, 568);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(65, 52);
            this.btn3.TabIndex = 43;
            this.btn3.Text = "3";
            this.btn3.UseVisualStyleBackColor = false;
            this.btn3.Click += new System.EventHandler(this.btn3_Click);
            // 
            // btn4
            // 
            this.btn4.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn4.Location = new System.Drawing.Point(332, 568);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(65, 52);
            this.btn4.TabIndex = 44;
            this.btn4.Text = "4";
            this.btn4.UseVisualStyleBackColor = false;
            this.btn4.Click += new System.EventHandler(this.btn4_Click);
            // 
            // btn5
            // 
            this.btn5.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn5.Location = new System.Drawing.Point(416, 567);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(65, 52);
            this.btn5.TabIndex = 45;
            this.btn5.Text = "5";
            this.btn5.UseVisualStyleBackColor = false;
            this.btn5.Click += new System.EventHandler(this.btn5_Click);
            // 
            // btn6
            // 
            this.btn6.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn6.Location = new System.Drawing.Point(496, 567);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(65, 52);
            this.btn6.TabIndex = 46;
            this.btn6.Text = "6";
            this.btn6.UseVisualStyleBackColor = false;
            this.btn6.Click += new System.EventHandler(this.btn6_Click);
            // 
            // btn7
            // 
            this.btn7.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn7.Location = new System.Drawing.Point(578, 570);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(65, 52);
            this.btn7.TabIndex = 47;
            this.btn7.Text = "7";
            this.btn7.UseVisualStyleBackColor = false;
            this.btn7.Click += new System.EventHandler(this.btn7_Click);
            // 
            // btn8
            // 
            this.btn8.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn8.Location = new System.Drawing.Point(671, 570);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(65, 52);
            this.btn8.TabIndex = 48;
            this.btn8.Text = "8";
            this.btn8.UseVisualStyleBackColor = false;
            this.btn8.Click += new System.EventHandler(this.btn8_Click);
            // 
            // btn9
            // 
            this.btn9.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn9.Location = new System.Drawing.Point(755, 570);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(65, 52);
            this.btn9.TabIndex = 49;
            this.btn9.Text = "9";
            this.btn9.UseVisualStyleBackColor = false;
            this.btn9.Click += new System.EventHandler(this.btn9_Click);
            // 
            // btnDOT
            // 
            this.btnDOT.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnDOT.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDOT.Location = new System.Drawing.Point(840, 568);
            this.btnDOT.Name = "btnDOT";
            this.btnDOT.Size = new System.Drawing.Size(65, 52);
            this.btnDOT.TabIndex = 50;
            this.btnDOT.Text = ".";
            this.btnDOT.UseVisualStyleBackColor = false;
            this.btnDOT.Click += new System.EventHandler(this.btnDOT_Click);
            // 
            // btnCLR
            // 
            this.btnCLR.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnCLR.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCLR.Location = new System.Drawing.Point(927, 568);
            this.btnCLR.Name = "btnCLR";
            this.btnCLR.Size = new System.Drawing.Size(65, 52);
            this.btnCLR.TabIndex = 51;
            this.btnCLR.Text = "CLR";
            this.btnCLR.UseVisualStyleBackColor = false;
            this.btnCLR.Click += new System.EventHandler(this.btnCLR_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(327, 400);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(91, 29);
            this.textBox1.TabIndex = 52;
            this.textBox1.Visible = false;
            // 
            // dgrdHoldingRegTable
            // 
            this.dgrdHoldingRegTable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgrdHoldingRegTable.Location = new System.Drawing.Point(3, 12);
            this.dgrdHoldingRegTable.Name = "dgrdHoldingRegTable";
            this.dgrdHoldingRegTable.Size = new System.Drawing.Size(1238, 648);
            this.dgrdHoldingRegTable.TabIndex = 53;
            this.dgrdHoldingRegTable.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgrdHoldingRegTable_CellContentClick);
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(176, 674);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(76, 29);
            this.textBox7.TabIndex = 54;
            this.textBox7.Text = "40001";
            this.textBox7.TextChanged += new System.EventHandler(this.textBox7_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.LightGray;
            this.label2.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 673);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(158, 26);
            this.label2.TabIndex = 55;
            this.label2.Text = "Start Address:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.LightGray;
            this.label3.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(264, 674);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(217, 26);
            this.label3.TabIndex = 56;
            this.label3.Text = "Number of Register:";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(478, 673);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(48, 29);
            this.textBox8.TabIndex = 57;
            this.textBox8.Text = "28";
            this.textBox8.TextChanged += new System.EventHandler(this.textBox8_TextChanged);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.button4.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(596, 665);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(291, 41);
            this.button4.TabIndex = 58;
            this.button4.Text = "Read (Function Code 03)";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // frmInstrumentSetup
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGray;
            this.ClientSize = new System.Drawing.Size(1249, 706);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dgrdHoldingRegTable);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.btnCLR);
            this.Controls.Add(this.btnDOT);
            this.Controls.Add(this.btn9);
            this.Controls.Add(this.btn8);
            this.Controls.Add(this.btn7);
            this.Controls.Add(this.btn6);
            this.Controls.Add(this.btn5);
            this.Controls.Add(this.btn4);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.btn0);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblEngUnit);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.btnEnter);
            this.Controls.Add(this.txtBoxInput);
            this.Controls.Add(this.lblHelpInfo);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblPressureCompensationSelData);
            this.Controls.Add(this.lblPressureCompEnable);
            this.Controls.Add(this.lblRequest);
            this.Controls.Add(this.lblPumpSpeedData);
            this.Controls.Add(this.lblPumpSpeed);
            this.Controls.Add(this.lblDrierRHSettingData);
            this.Controls.Add(this.lblDrierAlarm);
            this.Controls.Add(this.lblTempSetting);
            this.Controls.Add(this.lblLogIntervalData);
            this.Controls.Add(this.lblInstrumentLogInterval);
            this.Controls.Add(this.lblCompPressureFactorData);
            this.Controls.Add(this.lblMeasurePressureFactorData);
            this.Controls.Add(this.lblPressureCalFactor);
            this.Controls.Add(this.lblFlowCaliFactorData);
            this.Controls.Add(this.lblFlowCalFactor);
            this.Controls.Add(this.lblTemperatureSettingData);
            this.Controls.Add(this.lblDateTimeData);
            this.Controls.Add(this.lblInstrumentDateTime);
            this.Controls.Add(this.lblGammaGainData);
            this.Controls.Add(this.lblTritiumGainData);
            this.Controls.Add(this.lblGammaGain);
            this.Controls.Add(this.lblTritiumGain);
            this.Controls.Add(this.lblGammaAlarmData);
            this.Controls.Add(this.lblGammaAlarm);
            this.Controls.Add(this.lblTritiumAlarmData);
            this.Controls.Add(this.lblTritiumAlarm);
            this.Controls.Add(this.lblLocationData);
            this.Controls.Add(this.lblLocation);
            this.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "frmInstrumentSetup";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Instrument Setup ";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmInstrumentSetup_FormClosing);
            this.Load += new System.EventHandler(this.frmInstrumentSetup_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgrdHoldingRegTable)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblLocation;
        private System.Windows.Forms.Label lblLocationData;
        private System.Windows.Forms.Label lblTritiumAlarm;
        private System.Windows.Forms.Label lblTritiumAlarmData;
        private System.Windows.Forms.Label lblGammaAlarm;
        private System.Windows.Forms.Label lblGammaAlarmData;
        private System.Windows.Forms.Label lblTritiumGain;
        private System.Windows.Forms.Label lblGammaGain;
        private System.Windows.Forms.Label lblTritiumGainData;
        private System.Windows.Forms.Label lblGammaGainData;
        private System.Windows.Forms.Label lblInstrumentDateTime;
        private System.Windows.Forms.Label lblDateTimeData;
        private System.Windows.Forms.Label lblTemperatureSettingData;
        private System.Windows.Forms.Label lblFlowCalFactor;
        private System.Windows.Forms.Label lblFlowCaliFactorData;
        private System.Windows.Forms.Label lblPressureCalFactor;
        private System.Windows.Forms.Label lblMeasurePressureFactorData;
        private System.Windows.Forms.Label lblCompPressureFactorData;
        private System.Windows.Forms.Label lblInstrumentLogInterval;
        private System.Windows.Forms.Label lblLogIntervalData;
        private System.Windows.Forms.Label lblTempSetting;
        private System.Windows.Forms.Label lblDrierAlarm;
        private System.Windows.Forms.Label lblDrierRHSettingData;
        private System.Windows.Forms.Label lblPumpSpeed;
        private System.Windows.Forms.Label lblPumpSpeedData;
        private System.Windows.Forms.Label lblPressureCompEnable;
        private System.Windows.Forms.Label lblPressureCompensationSelData;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblHelpInfo;
        private System.Windows.Forms.TextBox txtBoxInput;
        private System.Windows.Forms.Button btnEnter;
        private System.Windows.Forms.Label lblRequest;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer tmrTaskTick;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label lblEngUnit;
        private System.Windows.Forms.Timer tmrSendingCommand;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button btn0;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button btnDOT;
        private System.Windows.Forms.Button btnCLR;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.DataGridView dgrdHoldingRegTable;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Button button4;
    }
}