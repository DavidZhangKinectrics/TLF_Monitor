﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.OleDb;

using ModbusTCP;


using System.Windows.Forms.DataVisualization.Charting;


namespace TriNet
{


    public partial class frmHistricalData : Form
    {
        private int piYearAryCnt;
        private int[] piYearAry = new int[100];

        private int piMonthAryCnt;
        private int[] piMonthAry = new int[20];

        private int piDayAryCnt;
        private int[] piDayAry = new int[20];

        private int piDTAryCnt;
        private DateTime[] pdateArray = new DateTime[1000000];


        private int iNumRecord;
        private DateTime[] dtArray = new DateTime[2000000];
        private int[] iLocArray = new int[2000000];
        private double[] iTritiumArray = new double[2000000];
        private int[] iGammaArray = new int[2000000];

        //private OleDbConnection dbConnection;// = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source = C:\All Projects\TriNet\TriNetApp\bin\x86\Debug\TrinetData.mdb");

        public frmHistricalData()
        {
            InitializeComponent();
        }

        private void frmHistricalData_Load(object sender, EventArgs e)
        {

            //private OleDbConnection dbConnection = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source = C:\All Projects\TriNet\TriNetApp\bin\x86\Debug\TrinetData.mdb");
            DateTime dtTemp;
            int i, j;
            bool bAlreadyExist;

            //dbConnection = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source = " + GlbByte.msCurrentDirName + @"\TrinetData.mdb");
            //using (OleDbConnection connection = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source = C:\All Projects\TriNet\TriNetApp\bin\x86\Debug\TrinetData.mdb"))

            using (OleDbConnection connection = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source = " + GlbByte.msCurrentDirName + @"\TrinetData.mdb"))
            {
                using (OleDbCommand custCMD = new OleDbCommand("select * from RadData order by dtDateTime ASC", connection))
                {
                    connection.Open();

                    using (OleDbDataReader custReader = custCMD.ExecuteReader())
                    {
                        piYearAryCnt = 0;
                        piMonthAryCnt = 0;
                        piDayAryCnt = 0;
                        piDTAryCnt = 0;

                        custReader.Read();
                        dtTemp = custReader.GetDateTime(1);
                        piYearAry[piYearAryCnt++] = dtTemp.Year;
                        piMonthAry[piMonthAryCnt++] = dtTemp.Month;
                        piDayAry[piDayAryCnt++] = dtTemp.Day;
                        pdateArray[piDTAryCnt++] = dtTemp;

                        while (custReader.Read())
                        {

                            dtTemp = custReader.GetDateTime(1);

                            bAlreadyExist = false;
                            for (i = 0; i < piYearAryCnt; i++)
                            {
                                if (piYearAry[i] == dtTemp.Year)
                                {
                                    bAlreadyExist = true;
                                    break;
                                }
                            }
                            if (bAlreadyExist == false)
                            {
                                piYearAry[piYearAryCnt++] = dtTemp.Year;
                            }


                            bAlreadyExist = false;
                            for (i = 0; i < piMonthAryCnt; i++)
                            {
                                if (piMonthAry[i] == dtTemp.Month)
                                {
                                    bAlreadyExist = true;
                                    break;
                                }
                            }
                            if (bAlreadyExist == false)
                            {
                                piMonthAry[piMonthAryCnt++] = dtTemp.Month;
                            }

                            bAlreadyExist = false;
                            for (i = 0; i < piDayAryCnt; i++)
                            {
                                if (piDayAry[i] == dtTemp.Day)
                                {
                                    bAlreadyExist = true;
                                    break;
                                }
                            }
                            if (bAlreadyExist == false)
                            {
                                piDayAry[piDayAryCnt++] = dtTemp.Day;
                            }


                            bAlreadyExist = false;
                            for (i = 0; i < piDTAryCnt; i++)
                            {
                                if ((pdateArray[i].Year == dtTemp.Year) && (pdateArray[i].Month == dtTemp.Month) && (pdateArray[i].Day == dtTemp.Day))
                                {
                                    bAlreadyExist = true;
                                    break;
                                }
                            }
                            if (bAlreadyExist == false)
                            {
                                pdateArray[piDTAryCnt++] = dtTemp;
                            }
                        }
                        // Make sure to always close readers and connections.  
                        custReader.Close();
                    }
                    resetFilter();
                    //for (i = 0; i < piYearAryCnt; i++)
                    //    listBox2.Items.Add(piYearAry[i].ToString());

                    //for (i = 0; i < piYearAryCnt; i++)
                    //    listBox3.Items.Add(piYearAry[i].ToString());


                    //for (i = 0; i < piMonthAryCnt; i++)
                    //    listBox4.Items.Add(piMonthAry[i].ToString());

                    //for (i = 0; i < piMonthAryCnt; i++)
                    //    listBox5.Items.Add(piMonthAry[i].ToString());

                    //for (i = 0; i < piDayAryCnt; i++)
                    //    listBox6.Items.Add(piDayAry[i].ToString());

                    //for (i = 0; i < piDayAryCnt; i++)
                    //    listBox7.Items.Add(piDayAry[i].ToString());

                }
            }

            /*
            //// read the DateTimeInformation from Database
            string sSql;

            sSql = "select * from RadData order by dtDateTime DESC";


            SqlCommand command =
               new SqlCommand(sSql, dbConnection);

            dbConnection.Open();
            
            OleDbCommand cmd = dbConnection.CreateCommand();
            cmd.CommandText = "select * from RadData order by dtDateTime DESC";
            cmd.Connection = dbConnection;
            cmd.CommandType = CommandType.Text;
            
            SqlDataReader rdr = cmd.ExecuteReader();



            con.Open();
            OdbcCommand cmd = new OdbcCommand();
            cmd.Connection = con;
            cmd.CommandText = "select text,id from ...........";
            OdbcDataReader dr = cmd.ExecuteReader();
            MultiCheckCombo1.ClearAll();
            dr.Read();
            MultiCheckCombo1.AddItems(dr, "text", "id");

            OleDbCommand cmd = dbConnection.CreateCommand();

            cmd.CommandText = "Insert into RadData " + "(dtDateTime, Location, TritiumLevel, GammaLevel) " + "Values (" + "#" + GlbByte.gdtCurrent.ToString() + "#" + ", "
                                                                                                                + GlbByte.gbyteSampleLocation.ToString() + ", "
                                                                                                                + GlbByte.giTritiumReadingInTenth.ToString() + ", "
                                                                                                                + GlbByte.giGammaReadingInTenth.ToString() + ")";
            cmd.Connection = dbConnection;
            cmd.CommandType = CommandType.Text;

            cmd.ExecuteNonQuery();

            cmd.Dispose();
            sSql = "select * from RadData order by dtDateTime DESC";

               cmd = New OleDbCommand(sSql, mdbConnection);

            */

        }

        private void resetFilter()
        {
            int i;
            listBox2.Items.Clear();
            listBox3.Items.Clear();
            listBox4.Items.Clear();
            listBox5.Items.Clear();
            listBox6.Items.Clear();
            listBox7.Items.Clear();

            for (i = 0; i < piYearAryCnt; i++)
                listBox2.Items.Add(piYearAry[i].ToString());

            for (i = 0; i < piYearAryCnt; i++)
                listBox3.Items.Add(piYearAry[i].ToString());


            for (i = 0; i < piMonthAryCnt; i++)
                listBox4.Items.Add(piMonthAry[i].ToString());

            for (i = 0; i < piMonthAryCnt; i++)
                listBox5.Items.Add(piMonthAry[i].ToString());

            for (i = 0; i < piDayAryCnt; i++)
                listBox6.Items.Add(piDayAry[i].ToString());

            for (i = 0; i < piDayAryCnt; i++)
                listBox7.Items.Add(piDayAry[i].ToString());

            listBox3.Enabled = false;
            listBox4.Enabled = false;
            listBox5.Enabled = false;
            listBox6.Enabled = false;
            listBox7.Enabled = false;


            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";


            listBox2.Enabled = true;
            listBox2.BackColor = Color.PaleGreen;
            listBox3.BackColor = Color.White;
            listBox4.BackColor = Color.White;
            listBox5.BackColor = Color.White;
            listBox6.BackColor = Color.White;
            listBox7.BackColor = Color.White;







        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int i;
            int iStartYear, iEndYear;
            int iStartMonth, iEndMonth;
            int iStartDay, iEndDay;
            //DateTime dtStartDate, dtEndDate;
            bool bDateValid;
            DateTime dtTempValue;

            string sStartDate, sEndDate;

            // int iPreviousLocation, iCurrentLocation;

            iStartYear = 0;
            iEndYear = 0;
            iStartMonth = 0;
            iEndMonth = 0;
            iStartDay = 0;
            iEndDay = 0;


            if (textBox1.Text != "")
                iStartYear = int.Parse(textBox1.Text);

            if (textBox2.Text != "")
                iEndYear = int.Parse(textBox2.Text);

            if (textBox3.Text != "")
                iStartMonth = int.Parse(textBox3.Text);

            if (textBox4.Text != "")
                iEndMonth = int.Parse(textBox4.Text);

            if (textBox5.Text != "")
                iStartDay = int.Parse(textBox5.Text);
            if (textBox6.Text != "")
                iEndDay = int.Parse(textBox6.Text);

            //bDateValid = true;
            //if ((iStartYear < 2000) || (iStartYear > 2059) || (iEndYear < 2000) || (iEndYear > 2059))
            //{
            //    bDateValid = false;
            //    MessageBox.Show("Incoorect Year!");
            //}

            //if ((iStartMonth < 1) || (iStartMonth > 12) || (iEndMonth < 1) || (iEndMonth > 12))
            //{
            //    bDateValid = false;
            //    MessageBox.Show("Incoorect Month!");
            //}

            //if ((iStartDay < 1) || (iStartDay > 31) || (iEndDay < 1) || (iEndDay > 31))
            //{
            //    bDateValid = false;
            //    MessageBox.Show("Incoorect Day!");
            //}

            sStartDate = iStartYear.ToString() + "-" + iStartMonth.ToString("D2") + "-" + iStartDay.ToString("D2") + " 00:00:00 ";
            sEndDate = iEndYear.ToString() + "-" + iEndMonth.ToString("D2") + "-" + iEndDay.ToString("D2") + " 23:59:59 ";


            bDateValid = true;
            if (DateTime.TryParse(sStartDate, out dtTempValue) == false)
            {
                bDateValid = false;
                MessageBox.Show(sStartDate + "is Invalid date");
            }

            if (DateTime.TryParse(sEndDate, out dtTempValue) == false)
            {
                bDateValid = false;
                MessageBox.Show(sEndDate + "is Invalid date");
            }


            if (bDateValid == true)
            {
                grpSetup.Visible = false;
                //panel1.Visible = true;
                groupBox1.Visible = true;
                chart1.Visible = true;
                listBox1.Visible = true;

                button5.Visible = true;
                btnExport.Visible = true;
                // upated the Listboxes and TextBoxes
                //dtStartDate = new DateTime(iStartYear, iStartMonth, iStartDay, 0,0,0);
                //dtEndDate = new DateTime(iEndYear, iEndMonth, iEndDay, 23, 59, 59);

                setupChart();

                sStartDate = "#" + iStartYear.ToString() + "-" + iStartMonth.ToString("D2") + "-" + iStartDay.ToString("D2") + " 00:00:00 " + "#";
                sEndDate = "#" + iEndYear.ToString() + "-" + iEndMonth.ToString("D2") + "-" + iEndDay.ToString("D2") + " 23:59:59 " + "#";


                // load selected into the chart
                //select* from tabblename WHERE(datecolumn BETWEEN '2018-04-01' AND '2018-04-5')
                iNumRecord = 0;


                //using (OleDbConnection connection = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source = C:\All Projects\TriNet\TriNetApp\bin\x86\Debug\TrinetData.mdb"))
                using (OleDbConnection connection = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source = " + GlbByte.msCurrentDirName + @"\TrinetData.mdb"))
                {
                    using (OleDbCommand custCMD = new OleDbCommand("select * from RadData where dtDateTime BETWEEN " + sStartDate + " AND " + sEndDate + " order by dtDateTime ASC", connection))
                    {
                        connection.Open();

                        using (OleDbDataReader custReader = custCMD.ExecuteReader())
                        {

                            //custReader.Read();
                            //dtTemp = custReader.GetDateTime(1);
                            //piYearAry[piYearAryCnt++] = dtTemp.Year;
                            //piMonthAry[piMonthAryCnt++] = dtTemp.Month;
                            //piDayAry[piDayAryCnt++] = dtTemp.Day;
                            //pdateArray[piDTAryCnt++] = dtTemp;

                            while (custReader.Read())
                            {

                                //int iNumRecord;
                                //DateTime[] dtArray = new DateTime[2000000];
                                //int[] iLocArray = new int[2000000];
                                //int[] iTritiumArray = new int[2000000];
                                //int[] iGammaArray = new int[2000000];
                                dtArray[iNumRecord] = custReader.GetDateTime(1);
                                iLocArray[iNumRecord] = custReader.GetInt32(2);
                                iTritiumArray[iNumRecord] = custReader.GetInt32(3) / 10.0;
                                iGammaArray[iNumRecord] = custReader.GetInt32(4);
                                iNumRecord++;


                            }
                            // Make sure to always close readers and connections.  
                            custReader.Close();
                        }

                    }
                }
                // add to chart 1

                //iPreviousLocation = iLocArray[0] - 1;
                for (i = 0; i < iNumRecord; i++)
                {

                    //iCurrentLocation = iLocArray[i] - 1;
                    //if(iCurrentLocation == iPreviousLocation)
                    //{
                    //    chart1.Series[iCurrentLocation].ChartType = SeriesChartType.Line;                       
                    //}
                    //else
                    //{
                    //    chart1.Series[iCurrentLocation].ChartType = SeriesChartType.Point;                       
                    //}
                    //chart1.Series[iCurrentLocation].Points.AddXY(dtArray[i], iTritiumArray[i]);
                    //iPreviousLocation = iCurrentLocation;


                    chart1.Series[0].Points.AddXY(dtArray[i], iTritiumArray[i]*GlbByte.gdblEngUnitFactor[GlbByte.giEngineeringUnitSelected]);
                    switch (iLocArray[i])
                    {
                        case 1:
                            chart1.Series[0].Points[i].Color = Color.Brown;
                            break;
                        case 2:
                            chart1.Series[0].Points[i].Color = Color.Orange;
                            break;
                        case 3:
                            chart1.Series[0].Points[i].Color = Color.Purple;//Color.Yellow;
                            break;
                        case 4:
                            chart1.Series[0].Points[i].Color = Color.Black; //Color.White;
                            break;
                        case 5:
                            chart1.Series[0].Points[i].Color = Color.Blue;
                            break;
                    }

                }

                // added to Alarm List
                listBox1.Items.Clear();

                //using (OleDbConnection connection = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source = C:\All Projects\TriNet\TriNetApp\bin\x86\Debug\TrinetData.mdb"))
                using (OleDbConnection connection = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source = " + GlbByte.msCurrentDirName + @"\TrinetData.mdb"))
                {
                    using (OleDbCommand custCMD = new OleDbCommand("select * from AlarmWarnning where dtDateTime BETWEEN " + sStartDate + " AND " + sEndDate + " order by dtDateTime ASC", connection))
                    {
                        connection.Open();

                        using (OleDbDataReader custReader = custCMD.ExecuteReader())
                        {
                            while (custReader.Read())
                            {
                                listBox1.Items.Add(custReader.GetDateTime(1).ToString("yyyy-MM-dd HH:mm:ss") + ", Loc.: " + custReader.GetInt32(2).ToString() + ", " + custReader.GetString(3));

                            }
                            // Make sure to always close readers and connections.  
                            custReader.Close();
                        }

                    }
                }


            }





        }

        private void grpSetup_Enter(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            int i, j;
            int miYearAryCnt;

            DateTime dtStartDate, dtEndDate;
            int[] miYearAry = new int[100];

            int miMonthAryCnt;
            int[] miMonthAry = new int[20];

            int miDayAryCnt;
            int[] miDayAry = new int[20];


            textBox1.Text = listBox2.SelectedItem.ToString();
            j = int.Parse(textBox1.Text);
            // upated the Listboxes and TextBoxes
            miYearAry[0] = j;
            miYearAryCnt = 1;
            for (i = 0; i < piDTAryCnt; i++)
            {
                if (pdateArray[i].Year > miYearAry[miYearAryCnt - 1])
                {
                    miYearAry[miYearAryCnt++] = pdateArray[i].Year;
                }
            }
            listBox3.Items.Clear();
            for (i = 0; i < miYearAryCnt; i++)
                listBox3.Items.Add(miYearAry[i].ToString());
            textBox2.Text = "";
            listBox3.Enabled = true;
            listBox3.BackColor = Color.PaleGreen;
            listBox2.Enabled = false;
            listBox2.BackColor = Color.White;



        }

        private void button4_Click(object sender, EventArgs e)
        {
            resetFilter();
        }

        private void listBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            int i, j;
            int iStartYear, iEndYear;
            int miYearAryCnt;

            //DateTime dtStartDate, dtEndDate;

            int[] miYearAry = new int[100];

            int miMonthAryCnt;
            int[] miMonthAry = new int[20];

            int miDayAryCnt;
            int[] miDayAry = new int[20];
            bool bAlreadyExist;


            textBox2.Text = listBox3.SelectedItem.ToString();
            iStartYear = int.Parse(textBox1.Text);
            iEndYear = int.Parse(textBox2.Text);



            //dtStartDate = new DateTime(iStart, 1, 1);
            //dtEndDate = new DateTime(iEnd, 12, 30, 23, 59, 59);

            // upated the Listboxes and TextBoxes

            miMonthAryCnt = 0;
            for (i = 0; i < piDTAryCnt; i++)
            {
                //if (((pdateArray[i].Year > iStart)||(pdateArray[i].Year == iStart)) && ((pdateArray[i].Year < iEnd) || (pdateArray[i].Year == iEnd)))
                if (pdateArray[i].Year == iStartYear)
                {
                    if (miMonthAryCnt == 0)
                    {
                        miMonthAry[miMonthAryCnt++] = pdateArray[i].Month;
                    }
                    else
                    {

                        bAlreadyExist = false;
                        for (j = 0; j < miMonthAryCnt; j++)
                        {
                            if (miMonthAry[j] == pdateArray[i].Month)
                            {
                                bAlreadyExist = true;
                                break;
                            }
                        }
                        if (bAlreadyExist == false)
                        {
                            miMonthAry[miMonthAryCnt++] = pdateArray[i].Month;
                        }
                    }

                }
            }
            listBox4.Items.Clear();
            for (i = 0; i < miMonthAryCnt; i++)
            {
                listBox4.Items.Add(miMonthAry[i].ToString());
            }

            miMonthAryCnt = 0;
            for (i = 0; i < piDTAryCnt; i++)
            {
                //if (((pdateArray[i].Year > iStart)||(pdateArray[i].Year == iStart)) && ((pdateArray[i].Year < iEnd) || (pdateArray[i].Year == iEnd)))
                if (pdateArray[i].Year == iEndYear)
                {
                    if (miMonthAryCnt == 0)
                    {
                        miMonthAry[miMonthAryCnt++] = pdateArray[i].Month;
                    }
                    else
                    {

                        bAlreadyExist = false;
                        for (j = 0; j < miMonthAryCnt; j++)
                        {
                            if (miMonthAry[j] == pdateArray[i].Month)
                            {
                                bAlreadyExist = true;
                                break;
                            }
                        }
                        if (bAlreadyExist == false)
                        {
                            miMonthAry[miMonthAryCnt++] = pdateArray[i].Month;
                        }
                    }

                }
            }
            listBox5.Items.Clear();
            for (i = 0; i < miMonthAryCnt; i++)
            {
                listBox5.Items.Add(miMonthAry[i].ToString());
            }


            //miMonthAryCnt = 0;
            //for (i = 0; i < piDTAryCnt; i++)
            //{
            //    //if (((pdateArray[i].Year > iStart)||(pdateArray[i].Year == iStart)) && ((pdateArray[i].Year < iEnd) || (pdateArray[i].Year == iEnd)))
            //    if ((pdateArray[i] >= dtStartDate) && (pdateArray[i] <= dtEndDate))
            //    {
            //        if (miMonthAryCnt == 0)
            //        {
            //            miMonthAry[miMonthAryCnt++] = pdateArray[i].Month;
            //        }
            //        else
            //        {

            //            bAlreadyExist = false;
            //            for (j = 0; j < miMonthAryCnt; j++)
            //            {
            //                if (miMonthAry[j] == pdateArray[i].Month)
            //                {
            //                    bAlreadyExist = true;
            //                    break;
            //                }
            //            }
            //            if (bAlreadyExist == false)
            //            {
            //                miMonthAry[miMonthAryCnt++] = pdateArray[i].Month;
            //            }
            //        }

            //    }
            //}
            //listBox4.Items.Clear();
            //listBox5.Items.Clear();

            //for (i = 0; i < miMonthAryCnt; i++)
            //{
            //    listBox4.Items.Add(miMonthAry[i].ToString());
            //    listBox5.Items.Add(miMonthAry[i].ToString());
            //}
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            //listBox4.Enabled = true;
            listBox4.Enabled = true;
            listBox4.BackColor = Color.PaleGreen;
            listBox3.Enabled = false;
            listBox3.BackColor = Color.White;

        }

        private void chart1_Click(object sender, EventArgs e)
        {
            int i, j;
            DateTime dtTemp;
            double XVal = chart1.ChartAreas[0].CursorX.Position;
            double dblMinDate, dblMaxDate;
            double dblTemp;

            DateTime dtMinDateInApp = DateTime.MinValue;
            DateTime dtMaxDateInApp = DateTime.MinValue;


            dtMinDateInApp = DateTime.Parse("2019-01-01");
            dtMaxDateInApp = DateTime.Parse("2059-01-01");
            dblMinDate = dtMinDateInApp.ToOADate();
            dblMaxDate = dtMaxDateInApp.ToOADate();

            //    iNumRecord;
            //private DateTime[] dtArray = new DateTime[2000000];
            //private int[] iLocArray = new int[2000000];
            //private int[] iTritiumArray = new int[2000000];
            //private int[] iGammaArray = new int[2000000];

            if ((XVal > dblMinDate) && (XVal < dblMaxDate))
            {
                dtTemp = DateTime.FromOADate(XVal);
                j = 0;
                for (i = 1; i < iNumRecord; i++)
                {
                    if ((dtArray[i] == dtTemp) || (dtArray[i] > dtTemp))
                    {
                        j = i;
                        break;
                    }
                }

                if (j != 0)
                {
                    groupBox1.Visible = true;

                    textBox9.Text = dtTemp.ToString("yyyy-MM-dd HH:mm:ss");
                    textBox8.Text = iLocArray[j].ToString();
                    dblTemp = iTritiumArray[j]*GlbByte.gdblEngUnitFactor[GlbByte.giEngineeringUnitSelected];
                    textBox7.Text = dblTemp.ToString("F1");

                }
            }

        }

        private void listBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            int i, j;
            int iStartYear, iEndYear;
            int iStartMonth;
            //DateTime dtStartDate, dtEndDate;
            int miYearAryCnt;
            int[] miYearAry = new int[100];

            int miMonthAryCnt;
            int[] miMonthAry = new int[20];

            int miDayAryCnt;
            int[] miDayAry = new int[20];
            bool bAlreadyExist;



            textBox3.Text = listBox4.SelectedItem.ToString();
            iStartYear = int.Parse(textBox1.Text);
            iEndYear = int.Parse(textBox2.Text);

            iStartMonth = int.Parse(textBox3.Text);

            // upated the Listboxes and TextBoxes

            //dtStartDate = new DateTime(iStartYear, iStartMonth, 1);
            //dtEndDate = new DateTime(iEndYear, 12, 30, 23, 59, 59);

            // upated the Listboxes and TextBoxes

            miMonthAryCnt = 0;
            for (i = 0; i < piDTAryCnt; i++)
            {
                if ((pdateArray[i].Year == iEndYear) && (pdateArray[i].Month >= iStartMonth))
                {
                    if (miMonthAryCnt == 0)
                    {
                        miMonthAry[miMonthAryCnt++] = pdateArray[i].Month;
                    }
                    else
                    {

                        bAlreadyExist = false;
                        for (j = 0; j < miMonthAryCnt; j++)
                        {
                            if (miMonthAry[j] == pdateArray[i].Month)
                            {
                                bAlreadyExist = true;
                                break;
                            }
                        }
                        if (bAlreadyExist == false)
                        {
                            miMonthAry[miMonthAryCnt++] = pdateArray[i].Month;
                        }
                    }

                }
            }

            listBox5.Items.Clear();
            for (i = 0; i < miMonthAryCnt; i++)
                listBox5.Items.Add(miMonthAry[i].ToString());

            //miMonthAryCnt = 0;
            //for (i = 0; i < piDTAryCnt; i++)
            //{
            //    if ((pdateArray[i] >= dtStartDate) && (pdateArray[i] <= dtEndDate))
            //    {
            //        if (miMonthAryCnt == 0)
            //        {
            //            miMonthAry[miMonthAryCnt++] = pdateArray[i].Month;
            //        }
            //        else
            //        {

            //            bAlreadyExist = false;
            //            for (j = 0; j < miMonthAryCnt; j++)
            //            {
            //                if (miMonthAry[j] == pdateArray[i].Month)
            //                {
            //                    bAlreadyExist = true;
            //                    break;
            //                }
            //            }
            //            if (bAlreadyExist == false)
            //            {
            //                miMonthAry[miMonthAryCnt++] = pdateArray[i].Month;
            //            }
            //        }

            //    }
            //}

            //listBox5.Items.Clear();
            //for (i = 0; i < miMonthAryCnt; i++)
            //    listBox5.Items.Add(miMonthAry[i].ToString());

            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";

            listBox5.Enabled = true;
            listBox5.BackColor = Color.PaleGreen;
            listBox4.Enabled = false;
            listBox4.BackColor = Color.White;



        }

        private void listBox6_SelectedIndexChanged(object sender, EventArgs e)
        {

            int i, j;
            int iStartYear, iEndYear;
            int iStartMonth, iEndMonth;
            int iStartDay;
            //DateTime dtStartDate, dtEndDate;

            int miYearAryCnt;
            int[] miYearAry = new int[100];

            int miMonthAryCnt;
            int[] miMonthAry = new int[20];

            int miDayAryCnt;
            int[] miDayAry = new int[20];
            bool bAlreadyExist;


            textBox5.Text = listBox6.SelectedItem.ToString();
            iStartYear = int.Parse(textBox1.Text);
            iEndYear = int.Parse(textBox2.Text);

            iStartMonth = int.Parse(textBox3.Text);
            iEndMonth = int.Parse(textBox4.Text);

            iStartDay = int.Parse(textBox5.Text);

            if ((iStartYear == iEndYear) && (iStartMonth == iEndMonth))
            {

                miDayAryCnt = 0;
                for (i = 0; i < piDTAryCnt; i++)
                {
                    if ((pdateArray[i].Year == iEndYear) && (pdateArray[i].Month == iEndMonth) && (pdateArray[i].Day >= iStartDay))
                    {
                        if (miDayAryCnt == 0)
                        {
                            miDayAry[miDayAryCnt++] = pdateArray[i].Day;
                        }
                        else
                        {

                            bAlreadyExist = false;
                            for (j = 0; j < miDayAryCnt; j++)
                            {
                                if (miDayAry[j] == pdateArray[i].Day)
                                {
                                    bAlreadyExist = true;
                                    break;
                                }
                            }
                            if (bAlreadyExist == false)
                            {
                                miDayAry[miDayAryCnt++] = pdateArray[i].Day;
                            }
                        }

                    }
                }


                listBox7.Items.Clear();
                for (i = 0; i < miDayAryCnt; i++)
                {
                    listBox7.Items.Add(miDayAry[i].ToString());

                }
            }

            //dtStartDate = new DateTime(iStartYear, iStartMonth, iStartDay);
            //dtEndDate = new DateTime(iEndYear, iEndMonth, 30, 23, 59, 59);

            //miDayAryCnt = 0;
            //for (i = 0; i < piDTAryCnt; i++)
            //{
            //    if ((pdateArray[i] >= dtStartDate) && (pdateArray[i] <= dtEndDate))
            //    {
            //        if (miDayAryCnt == 0)
            //        {
            //            miDayAry[miDayAryCnt++] = pdateArray[i].Day;
            //        }
            //        else
            //        {

            //            bAlreadyExist = false;
            //            for (j = 0; j < miDayAryCnt; j++)
            //            {
            //                if (miDayAry[j] == pdateArray[i].Day)
            //                {
            //                    bAlreadyExist = true;
            //                    break;
            //                }
            //            }
            //            if (bAlreadyExist == false)
            //            {
            //                miDayAry[miDayAryCnt++] = pdateArray[i].Day;
            //            }
            //        }

            //    }
            //}


            //listBox7.Items.Clear();
            //for (i = 0; i < miDayAryCnt; i++)
            //{
            //    listBox7.Items.Add(miDayAry[i].ToString());

            //}

            textBox6.Text = "";
            listBox7.Enabled = true;
            listBox7.Enabled = true;
            listBox7.BackColor = Color.PaleGreen;
            listBox6.Enabled = false;
            listBox6.BackColor = Color.White;



        }

        // End Month
        private void listBox5_SelectedIndexChanged(object sender, EventArgs e)
        {

            int i, j;
            int iStartYear, iEndYear;
            int iStartMonth, iEndMonth;
            DateTime dtStartDate, dtEndDate;

            int miYearAryCnt;
            int[] miYearAry = new int[100];

            int miMonthAryCnt;
            int[] miMonthAry = new int[20];

            int miDayAryCnt;
            int[] miDayAry = new int[20];
            bool bAlreadyExist;


            textBox4.Text = listBox5.SelectedItem.ToString();
            iStartYear = int.Parse(textBox1.Text);
            iEndYear = int.Parse(textBox2.Text);

            iStartMonth = int.Parse(textBox3.Text);
            iEndMonth = int.Parse(textBox4.Text);


            // upated the Listboxes and TextBoxes
            //dtStartDate = new DateTime(iStartYear, iStartMonth, 1);
            //dtEndDate = new DateTime(iEndYear, iEndMonth, 30, 23, 59, 59);

            miDayAryCnt = 0;
            for (i = 0; i < piDTAryCnt; i++)
            {
                if ((pdateArray[i].Year == iStartYear) && (pdateArray[i].Month == iStartMonth))
                {
                    if (miDayAryCnt == 0)
                    {
                        miDayAry[miDayAryCnt++] = pdateArray[i].Day;
                    }
                    else
                    {

                        bAlreadyExist = false;
                        for (j = 0; j < miDayAryCnt; j++)
                        {
                            if (miDayAry[j] == pdateArray[i].Day)
                            {
                                bAlreadyExist = true;
                                break;
                            }
                        }
                        if (bAlreadyExist == false)
                        {
                            miDayAry[miDayAryCnt++] = pdateArray[i].Day;
                        }
                    }

                }
            }

            listBox6.Items.Clear();
            for (i = 0; i < miDayAryCnt; i++)
            {
                listBox6.Items.Add(miDayAry[i].ToString());
            }


            miDayAryCnt = 0;
            for (i = 0; i < piDTAryCnt; i++)
            {
                if ((pdateArray[i].Year == iEndYear) && (pdateArray[i].Month == iEndMonth))
                {
                    if (miDayAryCnt == 0)
                    {
                        miDayAry[miDayAryCnt++] = pdateArray[i].Day;
                    }
                    else
                    {

                        bAlreadyExist = false;
                        for (j = 0; j < miDayAryCnt; j++)
                        {
                            if (miDayAry[j] == pdateArray[i].Day)
                            {
                                bAlreadyExist = true;
                                break;
                            }
                        }
                        if (bAlreadyExist == false)
                        {
                            miDayAry[miDayAryCnt++] = pdateArray[i].Day;
                        }
                    }

                }
            }

            listBox7.Items.Clear();
            for (i = 0; i < miDayAryCnt; i++)
            {
                listBox7.Items.Add(miDayAry[i].ToString());
            }


            //miDayAryCnt = 0;
            //for (i = 0; i < piDTAryCnt; i++)
            //{
            //    if ((pdateArray[i] >= dtStartDate) && (pdateArray[i] <= dtEndDate))
            //    {
            //        if (miDayAryCnt == 0)
            //        {
            //            miDayAry[miDayAryCnt++] = pdateArray[i].Day;
            //        }
            //        else
            //        {

            //            bAlreadyExist = false;
            //            for (j = 0; j < miDayAryCnt; j++)
            //            {
            //                if (miDayAry[j] == pdateArray[i].Day)
            //                {
            //                    bAlreadyExist = true;
            //                    break;
            //                }
            //            }
            //            if (bAlreadyExist == false)
            //            {
            //                miDayAry[miDayAryCnt++] = pdateArray[i].Day;
            //            }
            //        }

            //    }
            //}

            //listBox6.Items.Clear();
            //listBox7.Items.Clear();
            //for (i = 0; i < miDayAryCnt; i++)
            //{
            //    listBox6.Items.Add(miDayAry[i].ToString());
            //    listBox7.Items.Add(miDayAry[i].ToString());

            //}


            textBox5.Text = "";
            textBox6.Text = "";
            listBox6.Enabled = true;
            listBox6.BackColor = Color.PaleGreen;
            listBox5.Enabled = false;
            listBox5.BackColor = Color.White;
        }

        private void listBox7_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox6.Text = listBox7.SelectedItem.ToString();
        }


        private void setupChart()
        {

            int i;
            String strSeriesName = System.String.Empty;

            TimeSpan tsTemp;
            DateTime dtTemp;

            chart1.Series.Clear();
            chart1.Titles.Clear();


            chart1.ChartAreas[0].BackColor = Color.White;
            chart1.ChartAreas[0].AxisX.MajorGrid.LineColor = Color.DarkGreen;//Color.LawnGreen;
            chart1.ChartAreas[0].AxisY.MajorGrid.LineColor = Color.DarkGreen; //Color.Gray;//Color.LawnGreen;


            chart1.ChartAreas[0].CursorX.IsUserEnabled = true;
            chart1.ChartAreas[0].CursorX.IsUserSelectionEnabled = true;
            chart1.ChartAreas[0].CursorY.IsUserEnabled = true;
            chart1.ChartAreas[0].CursorY.IsUserSelectionEnabled = true;

            chart1.ChartAreas[0].CursorX.Interval = 0;
            chart1.ChartAreas[0].CursorY.Interval = 0;
            chart1.ChartAreas[0].AxisX.ScaleView.Zoomable = true;
            chart1.ChartAreas[0].AxisY.ScaleView.Zoomable = true;

            chart1.ChartAreas[0].CursorX.LineColor = Color.Black; //Color.MediumTurquoise;//Color.Black;
            chart1.ChartAreas[0].CursorX.LineWidth = 1;
            chart1.ChartAreas[0].CursorX.LineDashStyle = ChartDashStyle.Dot;
            tsTemp = TimeSpan.FromSeconds(10);
            chart1.ChartAreas[0].CursorX.Interval = 10 / 86400;// 0.0002;// 1000/86400;// 100 seconds, the format of date is x.yyyyy x is the day number from 1900;
            chart1.ChartAreas[0].CursorY.LineColor = Color.Black; // Color.MediumTurquoise;
            chart1.ChartAreas[0].CursorY.LineWidth = 1;
            chart1.ChartAreas[0].CursorY.LineDashStyle = ChartDashStyle.Dot;
            chart1.ChartAreas[0].CursorY.Interval = 2;// 0;

            chart1.ChartAreas[0].AxisY.Title = GlbByte.gstrEngUnit[GlbByte.giEngineeringUnitSelected];//GlbByte.gdblEngUnitFactor[GlbByte.giEngineeringUnitSelected];// "µCi/m3";
            chart1.ChartAreas[0].AxisY.TitleFont =
                   new System.Drawing.Font("Arial", 14, System.Drawing.FontStyle.Bold);


            chart1.ChartAreas[0].AxisX.ScrollBar.Enabled = true;
            // Set scrollbar size
            chart1.ChartAreas[0].AxisX.ScrollBar.Size = 20;
            chart1.ChartAreas[0].AxisY.ScrollBar.Size = 20;

            // Show small scroll buttons only          
            // chart1.ChartAreas[0].AxisX.ScrollBar.ButtonStyle = ScrollBarButtonStyles.SmallScroll;
            // Scrollbars position
            chart1.ChartAreas[0].AxisX.ScrollBar.IsPositionedInside = true;

            // Change scrollbar colors
            chart1.ChartAreas[0].AxisX.ScrollBar.BackColor = Color.MediumTurquoise;
            chart1.ChartAreas[0].AxisX.ScrollBar.ButtonColor = Color.LightCyan;
            chart1.ChartAreas[0].AxisX.ScrollBar.LineColor = Color.Blue;

            chart1.ChartAreas[0].AxisY.ScrollBar.BackColor = Color.MediumTurquoise;// Color.LightCyan;//Color.LightGray;
            chart1.ChartAreas[0].AxisY.ScrollBar.ButtonColor = Color.LightCyan;//Color.LightCyan;
            chart1.ChartAreas[0].AxisY.ScrollBar.LineColor = Color.Blue; //Color.Black;

            //chart1.Titles[0].Font = new System.Drawing.Font("Arial", 14, FontStyle.Bold);
            chart1.ChartAreas[0].AxisX.LabelStyle.Format = "yyyy-MM-dd HH:mm:ss";

            Series series1 = chart1.Series.Add(" ");
            series1.ChartType = SeriesChartType.Line;//SeriesChartType.Spline;
            series1.BorderWidth = 4;
            series1.Color = Color.White;//Color.Blue;
            series1.Font = new System.Drawing.Font("Arial", 14, FontStyle.Bold);

            //Series series1 = chart1.Series.Add("Location 1");
            //series1.ChartType = SeriesChartType.Line;//SeriesChartType.Spline;
            //series1.BorderWidth = 4;
            //series1.Color = Color.Brown;//Color.Blue;

            //Series series2 = chart1.Series.Add("Location 2");
            //series2.ChartType = SeriesChartType.Line;//.Line;//SeriesChartType.Spline;
            //series2.BorderWidth = 4;
            //series2.Color = Color.Orange;//Color.Blue;

            //Series series3 = chart1.Series.Add("Location 3");
            //series3.ChartType = SeriesChartType.Line;//.Line;//SeriesChartType.Spline;
            //series3.BorderWidth = 4;
            //series3.Color = Color.Purple;//Color.Blue;

            //Series series4 = chart1.Series.Add("Location 4");
            //series4.ChartType = SeriesChartType.Line;//.Line;//SeriesChartType.Spline;
            //series4.BorderWidth = 4;
            //series4.Color = Color.Black;//Color.Blue;

            //Series series5 = chart1.Series.Add("Location 5");
            //series5.ChartType = SeriesChartType.Line;//SeriesChartType.Spline;
            //series5.BorderWidth = 4;
            //series5.Color = Color.Blue;

            //ImageAnnotation logo = new ImageAnnotation();
            //logo.X = 75;
            //logo.Y = 60;

            //logo.Image = System.IO.Directory.GetCurrentDirectory() + @"\LocationPic.jpg";
            //chart1.Annotations.Add(logo);

            //ImageAnnotation logo1 = new ImageAnnotation();            
            //logo1.X = 10;
            //logo1.Y = 60;
            //logo1.Image = System.IO.Directory.GetCurrentDirectory() + @"\LocationPic.jpg";
            //chart1.Annotations.Add(logo1);

            ImageAnnotation logo2 = new ImageAnnotation();
           
            //logo2.X = 88;
            //logo2.Y = 4;
            logo2.X = 85;
            logo2.Y = 4;

            logo2.Image = System.IO.Directory.GetCurrentDirectory() + @"\LocationPic.jpg";
            chart1.Annotations.Add(logo2);



        }


        private void button5_Click(object sender, EventArgs e)
        {


            chart1.Printing.PrintDocument.DefaultPageSettings.Landscape = true;

            this.chart1.Printing.PrintPreview();

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            //SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.Filter = "CSV File|*.csv";
            saveFileDialog1.Title = "Save an CSV File";
            //pnlKeyPad.Visible = true;
            saveFileDialog1.ShowDialog();
            //pnlKeyPad.Visible = true;

            if (saveFileDialog1.FileName != "")
            {
                saveToCSVFile(saveFileDialog1.FileName);

            }
        }


        //private int iNumRecord;
        //private DateTime[] dtArray = new DateTime[2000000];
        //private int[] iLocArray = new int[2000000];
        //private double[] iTritiumArray = new double[2000000];
        //private int[] iGammaArray = new int[2000000];

        public void saveToCSVFile(string strFilePath)
        {
            int i, j;
            string strTemp;
            string strTitle;
            double dblTemp;
            try
            {
                //Pass the filepath and filename to the StreamWriter Constructor

                i = strFilePath.Length;
                strTemp = strFilePath.Substring(0, i - 4);
                strTemp = strTemp + "Data" + ".csv";
                System.IO.StreamWriter sw = new System.IO.StreamWriter(strTemp);
                strTitle = "Date,                Location, TritiumLevel(" + GlbByte.gstrEngUnit[GlbByte.giEngineeringUnitSelected] + "), GammaLevel(µSv/H)";
                sw.WriteLine(strTitle);
                for (i = 0; i < iNumRecord; i++)
                {
                    dblTemp = iTritiumArray[i] * GlbByte.gdblEngUnitFactor[GlbByte.giEngineeringUnitSelected];
                    sw.WriteLine(dtArray[i].ToString("yyyy-MM-dd HH:mm:ss") + ",  " + iLocArray[i].ToString() + ",      " + dblTemp.ToString("F1") + ",      " + iGammaArray[i].ToString());

                }

                //Close the file
                sw.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.Message);
            }

            try
            {

                i = strFilePath.Length;
                strTemp = strFilePath.Substring(0, i - 4);
                strTemp = strTemp + "Alarm" + ".csv";
                //Pass the filepath and filename to the StreamWriter Constructor
                System.IO.StreamWriter sw = new System.IO.StreamWriter(strTemp);

                sw.WriteLine("Date,                Location, Alarm_Message");

                j = listBox1.Items.Count;
                if (j > 0)
                {
                    for (i = 0; i < j; i++)
                    {
                        sw.WriteLine(listBox1.Items[i].ToString());
                    }
                }

                //Close the file
                sw.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.Message);
            }

            i = strFilePath.Length;
            strTemp = strFilePath.Substring(0, i - 4);
            strTemp = strTemp + "Chart" + ".jpg";
            chart1.SaveImage(strTemp, ChartImageFormat.Png);
            //try
            //{
            //    // Create the CSV file to which grid data will be exported.
            //    StreamWriter sw = new StreamWriter(strFilePath, false);
            //    // First we will write the headers.
            //    //DataTable dt = m_dsProducts.Tables[0];
            //    int iColCount = dt.Columns.Count;
            //    for (int i = 0; i < iColCount; i++)
            //    {
            //        sw.Write(dt.Columns[i]);
            //        if (i < iColCount - 1)
            //        {
            //            sw.Write(",");
            //        }
            //    }
            //    sw.Write(sw.NewLine);

            //    // Now write all the rows.
            //    foreach (DataRow dr in dt.Rows)
            //    {
            //        for (int i = 0; i < iColCount; i++)
            //        {
            //            if (!Convert.IsDBNull(dr[i]))
            //            {
            //                sw.Write(dr[i].ToString());
            //            }
            //            if (i < iColCount - 1)
            //            {
            //                sw.Write(",");
            //            }
            //        }

            //        sw.Write(sw.NewLine);
            //    }
            //    sw.Close();
            //}
            //catch (Exception ex)
            //{
            //    throw ex;
            //}
        }

        private void button6_Click(object sender, EventArgs e)
        {

            int i;
            int iStartYear, iEndYear;
            int iStartMonth, iEndMonth;
            int iStartDay, iEndDay;
            //DateTime dtStartDate, dtEndDate;
            bool bDateValid;
            DateTime dtTempValue;

            string sStartDate, sEndDate;

            // int iPreviousLocation, iCurrentLocation;

            iStartYear = 0;
            iEndYear = 0;
            iStartMonth = 0;
            iEndMonth = 0;
            iStartDay = 0;
            iEndDay = 0;


            if (textBox1.Text != "")
                iStartYear = int.Parse(textBox1.Text);

            if (textBox2.Text != "")
                iEndYear = int.Parse(textBox2.Text);

            if (textBox3.Text != "")
                iStartMonth = int.Parse(textBox3.Text);

            if (textBox4.Text != "")
                iEndMonth = int.Parse(textBox4.Text);

            if (textBox5.Text != "")
                iStartDay = int.Parse(textBox5.Text);
            if (textBox6.Text != "")
                iEndDay = int.Parse(textBox6.Text);

            

            sStartDate = iStartYear.ToString() + "-" + iStartMonth.ToString("D2") + "-" + iStartDay.ToString("D2") + " 00:00:00 ";
            sEndDate = iEndYear.ToString() + "-" + iEndMonth.ToString("D2") + "-" + iEndDay.ToString("D2") + " 23:59:59 ";


            bDateValid = true;
            if (DateTime.TryParse(sStartDate, out dtTempValue) == false)
            {
                bDateValid = false;
                MessageBox.Show(sStartDate + "is Invalid date");
            }

            if (DateTime.TryParse(sEndDate, out dtTempValue) == false)
            {
                bDateValid = false;
                MessageBox.Show(sEndDate + "is Invalid date");
            }

            DialogResult result = MessageBox.Show("Do you want to Delete Historical Record from " + sStartDate +" to " + sEndDate, "Confirmation", MessageBoxButtons.YesNoCancel);

            if ((bDateValid == true) && (result == DialogResult.Yes))
            {


                sStartDate = "#" + iStartYear.ToString() + "-" + iStartMonth.ToString("D2") + "-" + iStartDay.ToString("D2") + " 00:00:00 " + "#";
                sEndDate = "#" + iEndYear.ToString() + "-" + iEndMonth.ToString("D2") + "-" + iEndDay.ToString("D2") + " 23:59:59 " + "#";

                OleDbConnection connection = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source = " + GlbByte.msCurrentDirName + @"\TrinetData.mdb");

                connection.Open();

                OleDbCommand custCMD = new OleDbCommand("DELETE FROM RadData WHERE dtDateTime BETWEEN " + sStartDate + " AND " + sEndDate, connection);


                custCMD.ExecuteNonQuery();

                custCMD.Dispose();


                OleDbCommand deleteAlarmCMD = new OleDbCommand("DELETE FROM AlarmWarnning WHERE dtDateTime BETWEEN " + sStartDate + " AND " + sEndDate, connection);


                deleteAlarmCMD.ExecuteNonQuery();

                deleteAlarmCMD.Dispose();

                connection.Close();

            }
        }

        private void btnNum2_Click(object sender, EventArgs e)
        {
            saveFileDialog1.FileName = saveFileDialog1.FileName + "1";
        }

        private void btnNum1_Click(object sender, EventArgs e)
        {
            saveFileDialog1.FileName = saveFileDialog1.FileName + "2";
        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
