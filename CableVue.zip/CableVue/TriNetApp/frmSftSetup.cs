﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ModbusTCP;

using Modbus;
namespace TriNet
{
    public partial class frmSetup : Form
    {
        private ModbusTCP.Master MBmaster;

        public frmSetup()
        {
            InitializeComponent();
        }

        private void frmSetup_Load(object sender, EventArgs e)
        {

            textBox2.Text = GlbByte.msIPAddress;
            textBox3.Text =GlbByte.miHistSaveInterval.ToString();
            //System.Diagnostics.Process.Start("osk.exe");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            GlbByte.msIPAddress = textBox2.Text;
            writeLinesToFile();
            MessageBox.Show("Please Check the COM Port Number By Device Manager, then save and restart this Trinet Siftware! ");            
        }

        private void button4_Click(object sender, EventArgs e)
        {

            if (Int32.Parse(textBox3.Text) > -1)
            {
                GlbByte.miHistSaveInterval = Int32.Parse(textBox3.Text);
                writeLinesToFile();
            }
        }

       

        public void writeLinesToFile()
        {
            string msConfigFile;
            try
            {


                msConfigFile = GlbByte.msCurrentDirName + @"\SystemCfg.txt";
                //Pass the filepath and filename to the StreamWriter Constructor
                System.IO.StreamWriter sw = new System.IO.StreamWriter(msConfigFile);

                //Write a line of text
                sw.WriteLine(GlbByte.msIPAddress);
                sw.WriteLine(GlbByte.miHistSaveInterval.ToString());
                sw.WriteLine(GlbByte.giPassword.ToString());
                sw.WriteLine(GlbByte.giLocationSelect.ToString());
                sw.WriteLine(GlbByte.giLocationTimmingArry[0].ToString());
                sw.WriteLine(GlbByte.giLocationTimmingArry[1].ToString());
                sw.WriteLine(GlbByte.giLocationTimmingArry[2].ToString());
                sw.WriteLine(GlbByte.giLocationTimmingArry[3].ToString());
                sw.WriteLine(GlbByte.giLocationTimmingArry[4].ToString());
                sw.WriteLine(GlbByte.giEngineeringUnitSelected.ToString());

                //Close the file
                sw.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.Message);
            }
            finally
            {
                Console.WriteLine("Executing finally block.");
            }
        }



        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
