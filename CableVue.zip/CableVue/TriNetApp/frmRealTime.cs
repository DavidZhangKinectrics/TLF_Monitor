﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using ModbusTCP;



namespace TriNet
{
    public partial class frmRealTime : Form
    {
        

// Edit Controls
        private System.Windows.Forms.TextBox CursorX;
        private System.Windows.Forms.TextBox CursorY;

        private int i;
        private float mfTemp;

        public frmRealTime()
        {
            InitializeComponent();
        }

        private void frmRealTime_Load(object sender, EventArgs e)
        {

           

            

            //chart1.ChartAreas[0].AxisX.ScrollBar.Enabled = true;
            //// Set scrollbar size
            //chart1.ChartAreas[0].AxisX.ScrollBar.Size = 10;

            //// Show small scroll buttons only
            ////chart1.ChartAreas["Default"].AxisX.ScrollBar.Buttons = ScrollBarButtonStyle.SmallScroll;
            ////chart1.ChartAreas["Default"].AxisX.ScrollBar.Buttons = ScrollBarButtonStyle.SmallScroll;
            //chart1.ChartAreas[0].AxisX.ScrollBar.ButtonStyle = ScrollBarButtonStyles.SmallScroll;
            //// Scrollbars position
            //chart1.ChartAreas[0].AxisX.ScrollBar.IsPositionedInside = true;

            //// Change scrollbar colors
            //chart1.ChartAreas[0].AxisX.ScrollBar.BackColor = Color.LightGray;
            //chart1.ChartAreas[0].AxisX.ScrollBar.ButtonColor = Color.Gray;
            //chart1.ChartAreas[0].AxisX.ScrollBar.LineColor = Color.Black;



            //// Create cursor object
            //System.Windows.Forms.DataVisualization.Charting.Cursor cursor = null;

            //// Set cursor object
            //cursor = chart1.ChartAreas[0].CursorY;

            //// Set cursor properties 
            //cursor.LineWidth = 2;
            //cursor.LineDashStyle = ChartDashStyle.DashDot;
            //cursor.LineColor = Color.Red;
            //cursor.SelectionColor = Color.Yellow;

            //// Set cursor selection color of X axis cursor
            //chart1.ChartAreas[0].CursorX.SelectionColor = Color.Yellow;

           // SplineChartExample();


        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }


// Edit Controls
        //private System.Windows.Forms.TextBox CursorX;
       // private System.Windows.Forms.TextBox CursorY;

        // Cursor Position Changing Event
        private void chart1_CursorPositionChanging(object sender, System.Windows.Forms.DataVisualization.Charting.CursorEventArgs e)
        {
            SetPosition(e.Axis, e.NewPosition);
        }

        // Set Cursor Position to Edit control.
        private void SetPosition(Axis axis, double position)
        {
            if (double.IsNaN(position))
                return;

            if (axis.AxisName == AxisName.X)
            {
                // Convert Double to DateTime.
                DateTime dateTimeX = DateTime.FromOADate(position);

                // Set X cursor position to edit Control
                CursorX.Text = dateTimeX.ToLongDateString();
            }
            else
            {
                // Set Y cursor position to edit Control
                CursorY.Text = position.ToString();
            }
        }



       
    }

   
}
