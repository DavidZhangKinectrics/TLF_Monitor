﻿namespace TriNet
{
    partial class frmAlarm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAck = new System.Windows.Forms.Button();
            this.lstAlarm = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnAck
            // 
            this.btnAck.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAck.Location = new System.Drawing.Point(425, 611);
            this.btnAck.Name = "btnAck";
            this.btnAck.Size = new System.Drawing.Size(186, 46);
            this.btnAck.TabIndex = 0;
            this.btnAck.Text = "Acknoledge";
            this.btnAck.UseVisualStyleBackColor = true;
            // 
            // lstAlarm
            // 
            this.lstAlarm.Font = new System.Drawing.Font("Arial", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstAlarm.FormattingEnabled = true;
            this.lstAlarm.ItemHeight = 26;
            this.lstAlarm.Location = new System.Drawing.Point(51, 29);
            this.lstAlarm.Name = "lstAlarm";
            this.lstAlarm.Size = new System.Drawing.Size(991, 576);
            this.lstAlarm.TabIndex = 2;
            // 
            // frmAlarm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cyan;
            this.ClientSize = new System.Drawing.Size(1054, 686);
            this.Controls.Add(this.lstAlarm);
            this.Controls.Add(this.btnAck);
            this.Name = "frmAlarm";
            this.Text = "Alarm Screen";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnAck;
        private System.Windows.Forms.ListBox lstAlarm;
    }
}