/*************************************************************************
 *
 *    Used with ICCARM and AARM.
 *
 **************************************************************************/


#ifndef  __BitMapDISP__H
#define  __BitMapDISP__H
extern unsigned short const cstLogoBitMap[];
extern unsigned short const cstNormal[];
extern unsigned short const cstSearch[];
extern unsigned short const cstArrowLeft[];
extern unsigned short const cstArrowRight[];
extern unsigned short const cstZoomIn[];
extern unsigned short const cstZoomOut[];
extern unsigned short const cstMenu[];
extern unsigned short const cstSettingTool[];
void dispBitMap(int iLeft, int iTop, unsigned short const *BitMapDataBaseAddress);
void dispIcon(int iLeft, int iTop, unsigned short const *BitMapDataBaseAddress, unsigned short usBKcolor);
void dispIconInverted(int iLeft, int iTop, unsigned short const *BitMapDataBaseAddress, unsigned short usBKcolor);


#endif  /* __DRV_HD44780_L_H */
