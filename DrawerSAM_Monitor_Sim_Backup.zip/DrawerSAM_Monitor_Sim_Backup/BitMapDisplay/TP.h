//FT5316
/* touch panel interface define */
//sbit SDA	   =    P3^0;   //PB7
//sbit SCL       =    P3^1;       //PB6
//sbit PEN       =    P3^2;       //PB5
//sbit RESET	   =	P3^3;   //PB3

#define SET_SDA_H GPIOB->BSRRL = GPIO_Pin_7
#define SET_SDA_L GPIOB->BSRRH = GPIO_Pin_7
#define SET_SCL_H GPIOB->BSRRL = GPIO_Pin_6
#define SET_SCL_L GPIOB->BSRRH = GPIO_Pin_6
#define SET_RST_H GPIOB->BSRRL = GPIO_Pin_3
#define SET_RST_L GPIOB->BSRRH = GPIO_Pin_3
#define PEN (GPIOB->IDR & GPIO_Pin_5)
#define SDA (GPIOB->IDR & GPIO_Pin_7)

#include "stm32f4xx.h"
#include "stm32f4xx_gpio.h"
#include "DataGrabber.h"

#include "gslX680.h"

#define CONFIG_FT5X0X_MULTITOUCH    //Define the multi-touch
//Touch Status	 
#define Key_Down 0x01
#define Key_Up   0x00 

//
//typedef struct
//{
//     float fPeakSearchStartmS;
//     float fPeakSearchEndmS;
//
//     int iPeakThreshold;
//     int iRisingEdgePointsMin;
//     int  iRisingEdgePointsMax;  // It may be more than 30 since the gaussian shape- start rising slowly
//
//     int iFallingEdgePointsMin;
//     int iFallingEdgePointsMax;
//
//     float fFallingToRisingHeightRatioMin;
//     float fFallingToRisingHeightRatioMax;
//     float fPulseWidthmS_Min;
//     float fPulseWidthmS_Max;
//}PeakSearchSettingTypeDef;

//typedef struct
//{
//    uint    x1;
//    uint    y1;
//    uint    x2;
//    uint    y2;
//    uint    x3;
//    uint    y3;
//    uint    x4;
//    uint    y4;
//    uint    x5;
//    uint    y5;
//    uchar     touch_point;
//    uchar     Key_Sta;	
//}_ts_event;



//struct _ts_event
//{
//    uint    x1;
//    uint    y1;
//    uint    x2;
//    uint    y2;
//    uint    x3;
//    uint    y3;
//    uint    x4;
//    uint    y4;
//    uint    x5;
//    uint    y5;
//    uchar     touch_point;
//    uchar     Key_Sta;	
//};

_ts_event ts_event; 

//#define WRITE_ADD	0x70    // for 7 Inc
//#define READ_ADD	0x71     

#define WRITE_ADD	0x80    // 0x80
#define READ_ADD	0x81 


void TOUCH_Init(void);
void TOUCH_Start(void);
void TOUCH_Stop(void);
uchar   TOUCH_Wait_Ack(void);
void TOUCH_Ack(void);
void TOUCH_NAck(void);

void TOUCH_Send_Byte(uchar txd);
uchar TOUCH_Read_Byte(unsigned char ack);
void TOUCH_Wr_Reg(uchar RegIndex,uchar RegValue1);
void TOUCH_RdParFrPCTPFun(uchar *PCTP_Par,uchar ValFlag);
uchar   TOUCH_Read_Reg(uchar RegIndex);
void Draw_Big_Point(uint x,uint y,uint colour);
//uchar ft5x0x_read_data(void);  for 7 Inch LCD
uchar GSLX680_read_data(void);   // for  5 Inch LCD

int giunACKCnt = 0;
//IIC start
void TOUCH_Start(void)
{ 
        /*
        GPIO_InitTypeDef      GPIO_InitStructure;
        // set to output
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
        GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;//GPIO_OType_PP;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
        GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//GPIO_PuPd_NOPULL;
        GPIO_Init(GPIOB, &GPIO_InitStructure);
        */
  
	//SDA=1; 
        SET_SDA_H;
	//_nop_();
        delay_us(5);
        
        //SCL=1;
        SET_SCL_H;
	delay_us(5);
        
	//SDA=0;  
        SET_SDA_L;
	delay_us(5);
        
	//SCL=0;
        SET_SCL_L;
        delay_us(5);
	//_nop_();
     
}	  


//IIC stop
void TOUCH_Stop(void)
{
        /*
        GPIO_InitTypeDef      GPIO_InitStructure;
       
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
        GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;//GPIO_OType_PP;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
        GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//GPIO_PuPd_NOPULL;
        GPIO_Init(GPIOB, &GPIO_InitStructure);
        */
  
	//SDA=0;
        SET_SDA_L;
	//_nop_();
	//SCL=1;
        SET_SCL_H;
	delay_us(5);
	//SDA=1;
        SET_SDA_H;
	delay_us(5);
        /*
	//SCL=0;
        SET_SCL_L;
	//_nop_();;
        delay_us(5);
        */
      
}


//Wait for an answer signal
uchar TOUCH_Wait_Ack(void)
{	uchar errtime=0;

        /*
        GPIO_InitTypeDef      GPIO_InitStructure;
        
         GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
                        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
                        GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;//GPIO_OType_PP;
                        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
                        GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
                        GPIO_Init(GPIOB, &GPIO_InitStructure);

      
          */

	//SDA=1;
        //SET_SDA_H;
	//delay_us(5);
            
	//SCL=1;
        SET_SCL_H;
      
	delay_us(2);
        
  	while(SDA != 0)
	{
	  giunACKCnt++;  
          errtime++;
	    if(errtime>250)
		    {
		      TOUCH_Stop();
		      return 1;
		    }
	}
	//SCL=0;
        delay_us(2);
        SET_SCL_L;
        delay_us(1);
	//_nop_();
}




//Acknowledge
void TOUCH_Ack(void)
{	
        /*
        GPIO_InitTypeDef      GPIO_InitStructure;
        
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
        GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;//GPIO_OType_PP;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
        GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//GPIO_PuPd_NOPULL;
        GPIO_Init(GPIOB, &GPIO_InitStructure);
        */
  
        //SCL=0;
        SET_SCL_L;
        delay_us(5);
	//SDA=0;
        SET_SDA_L;
	delay_us(5);
	//SCL=1;
        SET_SCL_H;
	delay_us(5);
	//SCL=0;
        SET_SCL_L;
	//_nop_();
        delay_us(5);
        
     
}



//NO Acknowledge		    
void TOUCH_NAck(void)
{	
        /*
        GPIO_InitTypeDef      GPIO_InitStructure;
        
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
        GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;//GPIO_OType_PP;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
        GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//GPIO_PuPd_NOPULL;
        GPIO_Init(GPIOB, &GPIO_InitStructure);
        */
  
        //SCL=0;
        SET_SCL_L;
        delay_us(5);
	//SDA=1;
        SET_SDA_H;
	delay_us(5);
	//SCL=1;
        SET_SCL_H;
	delay_us(5);
	//SCL=0;
        SET_SCL_L;
	//_nop_();
        delay_us(5);
        
      
        
}	
	

//IIC send one byte		  
void TOUCH_Send_Byte(uchar Byte)
{	uchar t;  		

/*
 GPIO_InitTypeDef      GPIO_InitStructure;
        
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
        GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;//GPIO_OType_PP;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
        GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//GPIO_PuPd_NOPULL;
        GPIO_Init(GPIOB, &GPIO_InitStructure);
*/
 
    for(t=7; (t>=0)&&(t<=7); t--)
    { 	//SCL=0;  
        // SET_SCL_L;
         //delay_us(5);
         
        if((Byte>>t)&0x01)
        //SDA=1;
        SET_SDA_H;
        else
        //SDA=0;
        SET_SDA_L;
        delay_us(2);
                
	//SCL=1;
       SET_SCL_H;
       delay_us(5);
        //SCL=0;
        SET_SCL_L;
        delay_us(3);
    }	


 

} 




/******************************************************************************************
*Function name��Draw_Big_Point(u16 x,u16 y)
* Parameter��uint16_t x,uint16_t y xy
* Return Value��void
* Function��Draw touch pen nib point 2 * 2
*********************************************************************************************/		   
void Draw_Big_Point(uint x,uint y,uint colour)
{    
  	LCD_SetCursor(x,y);
  	LCD_WriteRAM_Prepare();
	LCD_DataWrite(colour);
	LCD_DataWrite(colour);

  	LCD_SetCursor(x,y+1);//Memory write position
  	LCD_WriteRAM_Prepare();					   
	LCD_DataWrite(colour);
	LCD_DataWrite(colour);



}



//Read one byte��ack=0��Send Acknowledge��ack=1��NO Acknowledge   
uchar TOUCH_Read_Byte(uchar ack)
{	uchar t,receive=0;
       

	//SCL=0;
        SET_SCL_L;
	//SDA=1;
        SET_SDA_H;
        
          
	for(t = 0; t < 8; t++)
	{	//_nop_();
	 	//SCL = 1;
                SET_SCL_H;
		//_nop_();
	 	receive<<=1;
	 	//if(SDA == 1)
                if(SDA != 0)
	 	receive=receive|0x01;
		delay_us(2);
	 	//SCL=0;
                SET_SCL_L;
		delay_us(2);
	}

     
					 
   	if (ack)  TOUCH_NAck();//NO Acknowledge 
   	else       TOUCH_Ack(); //Send Acknowledge   
    
	 return receive;
}




void TOUCH_Wr_Reg(uchar RegIndex,uchar RegValue1)
{
	TOUCH_Start();
	TOUCH_Send_Byte(WRITE_ADD);
	TOUCH_Wait_Ack();	
	TOUCH_Send_Byte(RegIndex);
	TOUCH_Wait_Ack();
	
	TOUCH_Send_Byte(RegValue1);
	TOUCH_Wait_Ack();

	TOUCH_Stop();
	delay_us(100);
}


void TOUCH_RdParFrPCTPFun(uchar *PCTP_Par,uchar ValFlag)
{	uchar k;

	TOUCH_Start();
	TOUCH_Send_Byte(READ_ADD);
	TOUCH_Wait_Ack();	
	for(k=0;k<ValFlag;k++)
	{
		if(k==(ValFlag-1))  *(PCTP_Par+k)=TOUCH_Read_Byte(1);
		else                *(PCTP_Par+k)=TOUCH_Read_Byte(0);
	}		
	TOUCH_Stop();
}


uchar TOUCH_Read_Reg(uchar RegIndex)
{	uchar receive=0;

	TOUCH_Start();
	TOUCH_Send_Byte(WRITE_ADD);
	TOUCH_Wait_Ack();
	TOUCH_Send_Byte(RegIndex);
	TOUCH_Wait_Ack();
	
	TOUCH_Start();
	TOUCH_Send_Byte(READ_ADD);
	TOUCH_Wait_Ack();	
	receive=TOUCH_Read_Byte(1);
	TOUCH_Stop();
 	 
	return receive;
}


void ft5x0x_i2c_txdata(uchar *txdata, uchar length)
{	//uchar ret =0;	
        uint num;

  	TOUCH_Start();
  	TOUCH_Send_Byte(WRITE_ADD);      
  	TOUCH_Wait_Ack();
  	for(num=0;num<length;num++)
  	{
		TOUCH_Send_Byte(txdata[num]); 
    	TOUCH_Wait_Ack();      
  	}                   
  	TOUCH_Stop();
  	delay_ms(2);


}

//uchar ft5x0x_i2c_rxdata(uchar *rxdata, uchar length)
//
//{	uchar num;	uchar *rxdatatmp =  rxdata;
//
//  	TOUCH_Start();
//  	TOUCH_Send_Byte(READ_ADD);
//  	TOUCH_Wait_Ack();            
//	for(num=0;num<length;num++)
//  	{
//		if(num==(length-1))  
//		rxdatatmp[num]=TOUCH_Read_Byte(0);   
//        else 
//    	rxdatatmp[num]=TOUCH_Read_Byte(1);   
//  	}
//
//  	TOUCH_Stop();
//	
//  	return rxdatatmp;
//}

void ft5x0x_i2c_rxdata(uchar *rxdata, uchar length)

{	uchar num;	
        //uchar *rxdatatmp =  rxdata;

  	TOUCH_Start();
  	TOUCH_Send_Byte(READ_ADD);
  	TOUCH_Wait_Ack();            
	for(num=0;num<length;num++)
  	{
		if(num==(length-1))  
		rxdata[num]=TOUCH_Read_Byte(0);   
        else 
    	rxdata[num]=TOUCH_Read_Byte(1);   
  	}

  	TOUCH_Stop();
	
  	//return rxdatatmp;
}

uchar ft5x0x_read_data(void)
{	uchar buf[32] = {0}; uchar ret = 0;

	#ifdef CONFIG_FT5X0X_MULTITOUCH
		TOUCH_RdParFrPCTPFun(buf, 31);
	#else
  		TOUCH_RdParFrPCTPFun(buf, 7);
	#endif

  	ts_event.touch_point = buf[2] & 0xf;

  	if (ts_event.touch_point == 0) 
		{
			return 0;
  		}

		#ifdef CONFIG_FT5X0X_MULTITOUCH
					switch (ts_event.touch_point) 
					{
							case 5:
				           			ts_event.x5 = (uint)(buf[0x1b] & 0x0F)<<8 | (uint)buf[0x1c];
				           			ts_event.y5 = (uint)(buf[0x1d] & 0x0F)<<8 | (uint)buf[0x1e];
				
						    case 4:
						           	ts_event.x4 = (uint)(buf[0x15] & 0x0F)<<8 | (uint)buf[0x16];
						           	ts_event.y4 = (uint)(buf[0x17] & 0x0F)<<8 | (uint)buf[0x18];
						
						    case 3:
						           	ts_event.x3 = (uint)(buf[0x0f] & 0x0F)<<8 | (uint)buf[0x10];
						           	ts_event.y3 = (uint)(buf[0x11] & 0x0F)<<8 | (uint)buf[0x12];
						
						    case 2:
						           	ts_event.x2 = (uint)(buf[9] & 0x0F)<<8 | (uint)buf[10];
						           	ts_event.y2 = (uint)(buf[11] & 0x0F)<<8 | (uint)buf[12];
						
						    case 1:
						           	ts_event.x1 = (uint)(buf[3] & 0x0F)<<8 | (uint)buf[4];
						           	ts_event.y1 = (uint)(buf[5] & 0x0F)<<8 | (uint)buf[6];
				
						    break;
						    default:
						    return 0;
					}
		#else

				  	if (ts_event.touch_point == 1)
				  	{
				    	ts_event.x1 = (uint)(buf[3] & 0x0F)<<8 | (uint)buf[4];
				    	ts_event.y1 = (uint)(buf[5] & 0x0F)<<8 | (uint)buf[6];
				    	ret = 1;
				  	}
				  	else
				  	{
						ts_event.x1 = 0xFFFF;
				    	ts_event.y1 = 0xFFFF;
				    	ret = 0;
				  	}
		#endif

    
	return ret;
}


void inttostr(uint value,uchar *str)
{
	str[0]=value/1000+48;
	str[1]=value%1000/100+48;
	str[2]=value%1000%100/10+48;
 	str[3]=value%1000%100%10+48;
}



//
//////////////////////////////////////
//void  counter0(void) interrupt 0
//{
// 	if(PEN==0)										//Detect the occurrence of an interrupt
// 	{
//		ts_event.Key_Sta=Key_Down;                              
//
// 	}
//}


/*

//Read one byte��ack=0��Send Acknowledge��ack=1��NO Acknowledge   
uchar TOUCH_Read_Byte(uchar ack)
{	uchar t,receive=0;

	SCL=0;
	SDA=1;
	for(t = 0; t < 8; t++)
	{	_nop_();
	 	SCL = 1;
		_nop_();
	 	receive<<=1;
	 	if(SDA == 1)
	 	receive=receive|0x01;
		delay_us(2);
	 	SCL=0;
		delay_us(2);
	}

					 
   	if (ack)  TOUCH_NAck();//NO Acknowledge 
   	else       TOUCH_Ack(); //Send Acknowledge   
    
	 return receive;
}

*/

//GSLX680_I2C_Write
static void GSLX680_I2C_Write(uchar *reg, uchar *addr, ulong cnt)
{
	uint i=0;

	
	TOUCH_Start();
	TOUCH_Send_Byte(WRITE_ADD);
	TOUCH_Wait_Ack();	
	TOUCH_Send_Byte(*reg);
	TOUCH_Wait_Ack();

	for(i=0;i<cnt;i++,addr++)//data
	{		
		TOUCH_Send_Byte(*addr);
		TOUCH_Wait_Ack();
	}
	TOUCH_Stop();
}

//GSLX680_I2C_Read
static void GSLX680_I2C_Read(uchar *reg, uchar *addr, ulong cnt)
{
       uint num=0;

	TOUCH_Start();
	TOUCH_Send_Byte(WRITE_ADD);
	TOUCH_Wait_Ack();	
	TOUCH_Send_Byte(*reg);
	TOUCH_Wait_Ack();
	TOUCH_Stop();

	TOUCH_Start();	
	TOUCH_Send_Byte(READ_ADD);//chip adress
	TOUCH_Wait_Ack();	
	
	for(num=0;num<cnt;num++)
  	{
		if(num==(cnt-1))  
		addr[num]=TOUCH_Read_Byte(1);   
        else 
    	addr[num]=TOUCH_Read_Byte(0);   
  	}	
	
	TOUCH_Stop();


}


//get the most data about capacitive touchpanel.
uchar GSLX680_read_data(void)
{	uchar touch_data[24] = {0}; 
	uchar reg = 0x80;
	GSLX680_I2C_Read(&reg, touch_data, 24);





				
				           			ts_event.y5 = (uint)(touch_data[23])<<8 | (uint)touch_data[22];
				           			ts_event.x5 = (uint)(touch_data[21])<<8 | (uint)touch_data[20];
				
						   
						           	ts_event.y4 = (uint)(touch_data[19])<<8 | (uint)touch_data[18];
						           	ts_event.x4 = (uint)(touch_data[17])<<8 | (uint)touch_data[16];
						
						
						           	ts_event.y3 = (uint)(touch_data[15])<<8 | (uint)touch_data[14];
						           	ts_event.x3 = (uint)(touch_data[13])<<8 | (uint)touch_data[12];
						
						  
						           	ts_event.y2 = (uint)(touch_data[11])<<8 | (uint)touch_data[10];
						           	ts_event.x2 = (uint)(touch_data[9])<<8 | (uint)touch_data[8];
						
						 
						           	ts_event.y1 = (uint)(touch_data[7])<<8 | (uint)touch_data[6];
						           	ts_event.x1 = (uint)(touch_data[5])<<8 | (uint)touch_data[4];
				
	

	return 0;	
}



/*
void inttostr(uint value,uchar *str)
{
	str[0]=value/1000+0x30;
	str[1]=value%1000/100+0x30;
	str[2]=value%1000%100/10+0x30;
	str[3]=value%1000%100%10+0x30;

}

*/


//TP interrrupt    GSL1680 is high levels interrrupt   MCU is low levels interrrupt     So here need to connect an inverter
////////////////////////////////////
/*
void  counter0(void) interrupt 0
{
 	if(PEN==0)										//Detect the occurrence of an interrupt
 	{
		ts_event.Key_Sta=Key_Down;                              
		led=~led;
 	}
}
*/

//GSLX680 Clear reg
static void _GSLX680_clr_reg(void)
{
	uchar addr;	
	uchar Wrbuf[4];

	addr = 0xe0;
	Wrbuf[0] = 0x88;
	//GSLX680_I2C_Write(0xe0, Wrbuf, 1); 	
        GSLX680_I2C_Write(&addr, Wrbuf, 1); 
	delay_us(2000);  // was 200 wit nACK
	addr = 0x80;
	Wrbuf[0] = 0x01;
	GSLX680_I2C_Write(&addr, Wrbuf, 1); 	
	delay_us(500);
	addr = 0xe4;
	Wrbuf[0] = 0x04;
	GSLX680_I2C_Write(&addr, Wrbuf, 1); 	
	delay_us(500);
	addr = 0xe0;
	Wrbuf[0] = 0x00;
	GSLX680_I2C_Write(&addr, Wrbuf, 1); 	
	delay_us(500);
}
//_GSLX680 Reset
static void _GSLX680_reset_chip(void)
{
	uchar addr;	
	uchar Wrbuf[4];
	

	addr = 0xe0;
	Wrbuf[0] = 0x88;
       GSLX680_I2C_Write(&addr,Wrbuf, 1);
	delay_us(500);

	addr = 0xe4;
	Wrbuf[0] = 0x04;
       GSLX680_I2C_Write(&addr,Wrbuf, 1);
	delay_us(500);

	addr = 0xbc;
	Wrbuf[0] = 0x00;
	Wrbuf[1] = 0x00;
	Wrbuf[2] = 0x00;
	Wrbuf[3] = 0x00;
       GSLX680_I2C_Write(&addr,Wrbuf, 4);
	delay_us(500);
	   
}
 
//GSLX680 Main Down
static void _GSLX680_load_fw(void)
{
	uchar addr;
	uchar Wrbuf[4];
	uint source_line=0;
	uint source_len = sizeof(GSLX680_FW)/sizeof(struct fw_data);
	

	for (source_line=0; source_line<source_len; source_line++)
	{
		addr = GSLX680_FW[source_line].offset;
		Wrbuf[0] = (char)(GSLX680_FW[source_line].val & 0x000000ff);
		Wrbuf[1] = (char)((GSLX680_FW[source_line].val & 0x0000ff00) >> 8);
		Wrbuf[2] = (char)((GSLX680_FW[source_line].val & 0x00ff0000) >> 16);
		Wrbuf[3] = (char)((GSLX680_FW[source_line].val & 0xff000000) >> 24);

		GSLX680_I2C_Write(&addr,Wrbuf, 4);
	}
	

}
//startup chip
static void _GSLX680_startup_chip(void)
{
	uchar addr;	
	uchar Wrbuf[4];

	addr = 0xe0;
	Wrbuf[0] = 0x00;
       GSLX680_I2C_Write(&addr,Wrbuf, 1);

}



void TOUCH_Init(void)
{		

  	//WAKE=1;	
        SET_RST_H;
	delay_ms(20);
	//WAKE=0;	
        SET_RST_L;	
	delay_ms(20);
	//WAKE=1;	
        SET_RST_H;	
	delay_ms(20);
	_GSLX680_clr_reg();
        delay_ms(20);
	_GSLX680_reset_chip();
        delay_ms(20);
	_GSLX680_load_fw();
//	_GSLX680_startup_chip();
        delay_ms(20);
	_GSLX680_reset_chip();
        delay_ms(20);
	_GSLX680_startup_chip();
          
        delay_ms(20);
                  GSLX680_read_data();  // for 5 Inch LCD
                
}

// return  giNewKey 
unsigned char gucNewKey;
void TouchScan(void)
{
  //static unsigned char s_ucKeyPressed_SAVE = 0;
  static unsigned char s_Key_UpCnt = 0;
  static unsigned char s_Key_State;
//  if(ts_event.Key_Sta==Key_Down)        //The touch screen is pressed
//  {	
//    gucNewKey = 1;
//    ft5x0x_read_data();
//    ts_event.Key_Sta=Key_Up;
//  }
//  else
//  {
//    gucNewKey = 0;    
//  }

   
   //if(((GPIOB->IDR & GPIO_Pin_5)==0)&&(s_Key_State == Key_Up))
   
   if(((GPIOB->IDR & GPIO_Pin_5)!=0)&&(s_Key_State == Key_Up))
   {
      ts_event.Key_Sta=Key_Down;
      gucNewKey = 1;
    
      //ft5x0x_read_data();  for 7 Inch LCD
      GSLX680_read_data();  // for 5 Inch LCD
   }
   
   GSLX680_read_data();  // for 5 Inch LCD
  
  // if((GPIOB->IDR & GPIO_Pin_5)!=0)  
   if((GPIOB->IDR & GPIO_Pin_5)==0)  
   {
     s_Key_UpCnt++;
     if(s_Key_UpCnt > 1)
     {
       s_Key_State=Key_Up;
       ts_event.Key_Sta=Key_Up;
     }
   }
   else
   {
     s_Key_UpCnt = 0;
     s_Key_State=Key_Down;
   }
   //s_ucKeyPressed_SAVE = ts_event.Key_Sta;
     
//   if((GPIOB->IDR & GPIO_Pin_5)==0)
//   {
//     s_ucKeyPressed_SAVE = 1;   // Key Down
//   }
//  else
//     s_ucKeyPressed_SAVE = 0; 
//  
  
  //				do
//				{
//					ft5x0x_read_data();
//					ts_event.Key_Sta=Key_Up;
//		
//                     
//				}while(PEN==0);
				
//			}
  
}


void TPTEST(void)
{
	uchar ss[4];	
	 //IT0=1;        //Falling edge trigger  
	 //EX0=1;
	 //EA=1;

	 TOUCH_Init();

	Select_Main_Window_16bpp();
	Main_Image_Start_Address(0);				
	Main_Image_Width(1024);							
	Main_Window_Start_XY(0,0);

	Canvas_Image_Start_address(0);//Layer 1
	Canvas_image_width(1024);//
    Active_Window_XY(0,0);
	Active_Window_WH(1024,600);

 	Foreground_color_65k(White);
	Line_Start_XY(0,0);
	Line_End_XY(1024,600);
	Start_Square_Fill();
        Font_Width_X1(); 

	//while(next)
        for(;;)
	{	Foreground_color_65k(Black);
		Background_color_65k(White);
		CGROM_Select_Internal_CGROM();
		Font_Select_8x16_16x16();
		Goto_Text_XY(40,200);
		Show_String("Touch to display the coordinate");

			if(ts_event.Key_Sta==Key_Down)        //The touch screen is pressed
			{
				//EX0=0;//Close interrupt
				do
				{
					ft5x0x_read_data();
					ts_event.Key_Sta=Key_Up;
		

					inttostr(ts_event.x1,ss);	

					Foreground_color_65k(Black);
					Background_color_65k(White);
					CGROM_Select_Internal_CGROM();
					Font_Select_8x16_16x16();
					Goto_Text_XY(100,60);
					Show_String("X = ");	

					Text_Mode();
					LCD_CmdWrite(0x04);							
				  	LCD_DataWrite(ss[0]);
					//delay_ms(1);
				  	LCD_DataWrite(ss[1]);
					//delay_ms(1);
				  	LCD_DataWrite(ss[2]);
					//delay_ms(1);
 				  	LCD_DataWrite(ss[3]);	 

					inttostr(ts_event.y1,ss);
					Goto_Text_XY(100,140);   //Set the display position
				  	LCD_CmdWrite(0x02);
					Show_String("Y = ");	
					Text_Mode();
					LCD_CmdWrite(0x04);	
				  	LCD_DataWrite(ss[0]);
					//delay_ms(1);
				  	LCD_DataWrite(ss[1]);
					//delay_ms(1);
				  	LCD_DataWrite(ss[2]);
					//delay_ms(1);
 				  	LCD_DataWrite(ss[3]);


    				Graphic_Mode(); //back to graphic mode
					Draw_Big_Point(1024-ts_event.x1,600-ts_event.y1,Red);
					Draw_Big_Point(1024-ts_event.x2,600-ts_event.y2,Green);	
					Draw_Big_Point(1024-ts_event.x3,600-ts_event.y3,Blue);
					Draw_Big_Point(1024-ts_event.x4,600-ts_event.y4,Cyan);	
					Draw_Big_Point(1024-ts_event.x5,600-ts_event.y5,Magenta);

                     
				}while(PEN==0);
				//EX0=1;
			}



    }

	// IT0=0;        //Falling edge trigger  
	 //EA=0;

}

