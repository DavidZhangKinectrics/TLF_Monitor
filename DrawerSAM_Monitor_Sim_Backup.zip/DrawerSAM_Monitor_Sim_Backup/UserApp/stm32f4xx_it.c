/**
  ******************************************************************************
  * @file    TIM/TIM1_Synchro/stm32f4xx_it.c 
  * @author  MCD Application Team
  * @version V1.0.0
  * @date    30-September-2011
  * @brief   Main Interrupt Service Routines.
  *          This file provides template for all exceptions handler and peripherals
  *          interrupt service routine.
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  ******************************************************************************
  */ 

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_it.h"
#include "stm32f4xx.h"
#include "DataGrabber.h"
#include "stm32f4xx_gpio.h"
#include "Peripheral.h"
#include "usart.h"
#include "DataProcess.h"
#include "LCDControl_l.h"

//#define Enable_HV()  (GPIOD->BSRRL = GPIO_Pin_3) /* Set PD3 to High*/
//#define Disable_HV() (GPIOD->BSRRH = GPIO_Pin_3) /* Set PD3 to Low*/

//#define SET_HV_Positive() (GPIOE->BSRRH = GPIO_Pin_13) /* Set PE13 to LOW*/
//#define SET_HV_Negative() (GPIOE->BSRRL = GPIO_Pin_13) /* Set PE133 to High*/
  

extern unsigned short usScanDataBuf0[NUM_DATA_BUF];
extern unsigned short usScanDataBuf1[NUM_DATA_BUF];
//extern int giBackGroundCPS[];

unsigned int uiNewScanFlag;

extern unsigned short usScanPeriod;
extern unsigned short usSamplePeriod;

int giTxCounter;
extern unsigned char gucCommDataBuf0[];
//extern unsigned char gucCommDataBuf1[2500];

unsigned int guiBuf0_SAVED; // DMA Buffer 0 has been saved


int uiSampleIndex;

unsigned char gucFrontDetectorDetected,gucRearDetectorDetected;

//extern structDataResponseByT_SpareProcessor_TypeDef gstructDataResponseByT_SpareProcessor;
extern structDataRequestByHMI_TypeDef gstructDataRequestByHMI;
extern SETTING_TypeDef gstructParameter;

extern TouchStatusDef gstructTouchStatus;
/** @addtogroup STM32F4xx_StdPeriph_Examples
  * @{
  */

/** @addtogroup TIM_TIM1_Synchro
  * @{
  */ 

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/******************************************************************************/
/*            Cortex-M4 Processor Exceptions Handlers                         */
/******************************************************************************/

/**
  * @brief  This function handles NMI exception.
  * @param  None
  * @retval None
  */
void NMI_Handler(void)
{}

/**
  * @brief  This function handles Hard Fault exception.
  * @param  None
  * @retval None
  */
void HardFault_Handler(void)
{
  /* Go to infinite loop when Hard Fault exception occurs */
  while (1)
  {}
}

/**
  * @brief  This function handles Memory Manage exception.
  * @param  None
  * @retval None
  */
void MemManage_Handler(void)
{
  /* Go to infinite loop when Memory Manage exception occurs */
  while (1)
  {}
}

/**
  * @brief  This function handles Bus Fault exception.
  * @param  None
  * @retval None
  */
void BusFault_Handler(void)
{
  /* Go to infinite loop when Bus Fault exception occurs */
  while (1)
  {}
}

/**
  * @brief  This function handles Usage Fault exception.
  * @param  None
  * @retval None
  */
void UsageFault_Handler(void)
{
  /* Go to infinite loop when Usage Fault exception occurs */
  while (1)
  {}
}

/**
  * @brief  This function handles Debug Monitor exception.
  * @param  None
  * @retval None
  */
void DebugMon_Handler(void)
{}

/**
  * @brief  This function handles SVCall exception.
  * @param  None
  * @retval None
  */
void SVC_Handler(void)
{}

/**
  * @brief  This function handles PendSV_Handler exception.
  * @param  None
  * @retval None
  */
void PendSV_Handler(void)
{}

/**
  * @brief  This function handles SysTick Handler.
  * @param  None
  * @retval None
  */
extern unsigned char guc25mSTick,guc1000mSTick;

extern unsigned short gusADC1DataBuf0[];

StepMotorTypeDef gstructStepMotorControl;
unsigned int   guiSystemTick = 0;
//unsigned int guiDetectedCPS[10];
//DetectorTypeDef gstruDetector[10];

int giADC_ResultSum[10];
int giADC_ResultAve[10];
// Maximum 1.5uS
void SysTick_Handler(void)
{
  
  int i;
  i = 0;
  static int siTenThmSCnt = 0;
  
  //Set_WTD_Hi;
 
  // Note: The INT pin will has 1mS pulse wevery 20mS when Touch panel pressed and hold
  if((GPIOB->IDR & GPIO_Pin_5)!=0)
  {
    gstructTouchStatus.iTouchPressed = 1;    
      
    if(gstructTouchStatus.iTouchReleased == 1)
    {
      gstructTouchStatus.iNewTouchButton = 1;
    }
    gstructTouchStatus.iTouchRleaseTimeOutTenthMsCnt = 0;  
    gstructTouchStatus.iTouchReleased = 0;
  }
  else
  {
    if(gstructTouchStatus.iTouchRleaseTimeOutTenthMsCnt < 1000) 
    {
      gstructTouchStatus.iTouchRleaseTimeOutTenthMsCnt++;
    }
    else
    {
      // 100mS no touch detected
      gstructTouchStatus.iTouchPressed = 0;
      gstructTouchStatus.iTouchReleased = 1;
    }    
  }
  
  
  
  siTenThmSCnt++;  // 0.1mS count
  if(siTenThmSCnt == 10)
  {
    siTenThmSCnt = 0;
    
    
  
  //while(ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC) == RESET);
  //i= (int)ADC_GetConversionValue(ADC1);
  //giADC_ResultSum = giADC_ResultSum+i;
  for(i =0;i <10;i++)
  {
    giADC_ResultSum[i]+=gusADC1DataBuf0[i];
  }
  //giADC_ResultSum = giADC_ResultSum + gusADC1DataBuf0[6];
  ADC_SoftwareStartConv(ADC1);
  
  
  guiSystemTick++;
  if((guiSystemTick%25) == 0)
  {
    guc25mSTick = 1;    
  }
  if(guiSystemTick == 1000)
  {
     guc1000mSTick = 1; 
     guiSystemTick = 0;
     
     for(i=0;i<10;i++)
     {
       giADC_ResultAve[i] = giADC_ResultSum[i]/1000;
       giADC_ResultSum[i] = 0;
     }
     /*
     gstruDetector[0].uiCPS = guiDetectedCPS[0];   // TIM10->CNT;  // Front #1 
     gstruDetector[1].uiCPS = guiDetectedCPS[1];   // Front #2 
     gstruDetector[2].uiCPS = guiDetectedCPS[2];   // Front #3 
     gstruDetector[3].uiCPS = guiDetectedCPS[3];   // Front #4 
     
     gstruDetector[4].uiCPS  = guiDetectedCPS[4];  // Rear #1 
     gstruDetector[5].uiCPS  = guiDetectedCPS[5];  // Rear #2 
     gstruDetector[6].uiCPS  = guiDetectedCPS[6];  // Rear #3 
     gstruDetector[7].uiCPS  = guiDetectedCPS[7];  // Rear #4 
     
     
     // Update Maximum CPS  and check if over the threshold
     for(i = 0; i < 8; i++)
     {
       if(gstruDetector[i].uiMaxCPS <  gstruDetector[i].uiCPS)
       {
         gstruDetector[i].uiMaxCPS = gstruDetector[i].uiCPS;
       }
       

       
       // Low alarm detection
       if(gstruDetector[i].uiCPS == 0)
       {
         if(gstruDetector[i].ucZeroCPSCnt < 200)
         {
           gstruDetector[i].ucZeroCPSCnt++;
         }       
         
         if(gstruDetector[i].ucZeroCPSCnt> 150)   // 150 seconds No pulse detected  // was 20
         {
           gstruDetector[i].ucWarning |= 0x1;
         }
       }
       else
       {
         gstruDetector[i].ucWarning &= 0xfe;       
         gstruDetector[i].ucZeroCPSCnt = 0;
         
       }
       
     }
    
     for(i = 0; i < 8; i++)
     {
       guiDetectedCPS[i] = 0;
     }
     */
     
     
    }
  }
  
  //Set_WTD_Low;
}


// Note: The INT pin will has 1mS pulse wevery 20mS when Touch panel pressed and hold

void TouchDetection(void)
{
  
  if((GPIOB->IDR & GPIO_Pin_5)!=0)
  {
    gstructTouchStatus.iTouchPressed = 1;    
      
    if(gstructTouchStatus.iTouchReleased == 1)
    {
      gstructTouchStatus.iNewTouchButton = 1;
    }
    gstructTouchStatus.iTouchRleaseTimeOutTenthMsCnt = 0;  
    gstructTouchStatus.iTouchReleased = 0;
  }
  else
  {
    if(gstructTouchStatus.iTouchRleaseTimeOutTenthMsCnt < 1000) 
    {
      gstructTouchStatus.iTouchRleaseTimeOutTenthMsCnt++;
    }
    else
    {
      // 100mS no touch detected
      gstructTouchStatus.iTouchPressed = 0;
      gstructTouchStatus.iTouchReleased = 1;
    }    
  }
  

  
}


/******************************************************************************/
/*                 STM32F4xx Peripherals Interrupt Handlers                   */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_stm32f4xx.s).                                            */
/******************************************************************************/



extern int giHV_ON_Reg;
extern int giHV_OFF_Reg;


extern unsigned short usBlankingPulseStartCnt;
extern unsigned short usBlankingPulseEndCnt;


extern unsigned short usScanIndex;
extern unsigned short usSliceIndex;



unsigned short gusCurrentInNegMode;

extern int guiStartNewPolarityFlag;


extern DataGrabber_InitTypeDef gstructDataGrabberInit;
void TIM5_IRQHandler(void)
{
   
}






  
extern int giNewScanFlag;

int icount;



int giScanTick;

unsigned char gusRemoteDataReceived;
unsigned char gusRemoteDataProcessReq;


//extern unsigned char guc25mSTick,guc1000mSTick;

extern unsigned short gusDataPointIndex;
//interrupt every 0.5mS


extern u32 uiTempNum,uiTempFlag;
extern unsigned char gucU2RXBufForProcess[];
extern unsigned char  gucU2RXBuf[];
extern unsigned char gucU2StateMechine;
extern unsigned short gusRxReceivedCnt_TEST;
extern unsigned char gucDMASTARTED;
extern unsigned char gucU2TXDData[];


int giReceivingTimeOut;
int giUARTReceivingDone;  

u8 guRxBuffer1[200];
int giRxReceivedCnt;
u8 gucCommandReceivedFromRemote[200];


int giUARTReqReveived;
int giTxCounter1;     
u8 guTxBuffer1[200];
int giNbrOfDataToTransfer;
u8 guSendingReq;
u8 guStartSendingDelayNeeded;



int guEnableRS485OffDelReq;


void TIM1_UP_TIM10_IRQHandler(void)
{
 
  static unsigned char sucDispIndex = 0;
  static unsigned char sucIntCntFor25mS = 0;
  static unsigned char sucIntCnt2mS = 0;
  static unsigned short susUSART2_DMACnt,susUSART2_DMACnt_SAVED; 
  static unsigned short susUSART2_DMATXCnt, susUSART2_DMATXCnt_SAVED; 
  static unsigned char sucCntForOneS = 0;
  static unsigned char sucTXDelay2mSCnt = 0;
  
  
  static int s_iSendSerialDataDelay = 0;
  static int s_iEnableRS485OFFDel = 0;
  
  unsigned int uiPortCShadow;
  unsigned short  i,usRxReceivedCnt;
  if (TIM_GetITStatus(TIM1, TIM_IT_Update) != RESET)
  {   
    
    sucDispIndex++;
    if(sucDispIndex == 13)
      sucDispIndex = 0;

    sucIntCnt2mS++;
    if(sucIntCnt2mS > 3)  // process U2 Rx and TX
    {
       sucIntCnt2mS = 0;
       
    }       
    
    
    sucIntCntFor25mS++;
    if(sucIntCntFor25mS == 50)
    {
      sucIntCntFor25mS = 0;
      //guc25mSTick = 1;      
      sucCntForOneS++;
            
      if(sucCntForOneS == 40)
      {
        sucCntForOneS = 0;
       // guc1000mSTick = 1;  
      }
      
      
     
    }
    

    
    TIM_ClearITPendingBit(TIM1, TIM_IT_Update);
   
    
  }
   
   
   
}

int giUpdateHVReg;




void TIM1_CC_IRQHandler(void)
{
//  float fTemp; 
//  if (TIM_GetITStatus(TIM1, TIM_IT_CC1) != RESET)
//   { 
//   
//    /* Set PE11 for PA_CLR*/
//    //GPIOE->BSRRL = GPIO_Pin_11;    
//    
//    TIM_ClearITPendingBit(TIM1, TIM_IT_CC1);
//   }
//   
//   // Blanking start for switch mode and new polarity start
//   if (TIM_GetITStatus(TIM1, TIM_IT_CC2) != RESET)
//   { 
//    TIM_ClearITPendingBit(TIM1, TIM_IT_CC2);
//   }
//   
//   // Set the HV 
//   if (TIM_GetITStatus(TIM1, TIM_IT_CC3) != RESET)
//   { 
//      
//    TIM_ClearITPendingBit(TIM1, TIM_IT_CC3);
//  }
//   
//  // stop Blanking and also set the flag to correct the HV setting
//  if (TIM_GetITStatus(TIM1, TIM_IT_CC4) != RESET)
//  { 
//    
//    TIM_ClearITPendingBit(TIM1, TIM_IT_CC4);
//    
//    
// }
//   
     
}




void USART1_IRQHandler(void)
{
  
  u8 uTemp;
//  u8 nLRC;
//  static u8 uHiNibble, uLoNibble;
//  static u8 uReadyForHiNibble;
//  static u8 suHiNibbleSendPending;
//  int i;
  
  if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)
  {
    /* Read one byte from the receive data register */
    uTemp = USART_ReceiveData(USART1);
    
    giReceivingTimeOut = 0;
    giUARTReceivingDone = 0;
    
     guRxBuffer1[giRxReceivedCnt++] = uTemp;  
     if(giRxReceivedCnt >199)
         giRxReceivedCnt = 0;
   
  }
  
  if(USART_GetITStatus(USART1, USART_IT_TXE) != RESET)
  {  
    
      if(giTxCounter1 < giNbrOfDataToTransfer)
      {
         // Write one byte to the transmit data register 
          USART_SendData(USART1, guTxBuffer1[giTxCounter1++]);                    
      }
      else
      {        
        USART_ITConfig(USART1, USART_IT_TXE, DISABLE);           
        guEnableRS485OffDelReq = 1;
      }
   }
        

  
}




extern int giCurrentSrcHV;



// Tested the process time is 90uS
void TIM8_CC_IRQHandler(void)
{

    
  if (TIM_GetITStatus(TIM8, TIM_IT_CC1) != RESET)
  { 
    
     
     
     TIM_ClearITPendingBit(TIM8, TIM_IT_CC1);
     
    
  }
     
}

int giEnterKeyState;
int giDownKeyState;
int giUpKeyState;
int giEscKeyState;

void EXTI0_IRQHandler(void)
{
  if(EXTI_GetITStatus(EXTI_Line0) != RESET)
  {
    //giEnterKeyState = 1;
    giEscKeyState = 1;
    /* Clear the EXTI line 0 pending bit */
    EXTI_ClearITPendingBit(EXTI_Line0);
  }
}

void EXTI1_IRQHandler(void)
{
  if(EXTI_GetITStatus(EXTI_Line1) != RESET)
  {
    
    //guiDetectedCPS[5]++;   // Rear #2
    /* Clear the EXTI line 1 pending bit */
    EXTI_ClearITPendingBit(EXTI_Line1);
 
    gucRearDetectorDetected = 1;
  }
}


// Rear #1 Input 
void EXTI2_IRQHandler(void)
{
  
  if(EXTI_GetITStatus(EXTI_Line2) != RESET)
  {
    //TURN_ON_RED_LED;

    //guiDetectedCPS[4]++;
    
    EXTI_ClearITPendingBit(EXTI_Line2);
    //TURN_OFF_RED_LED;
    gucRearDetectorDetected = 1;
  }
  
  
  
}

void EXTI3_IRQHandler(void)
{
  
  if(EXTI_GetITStatus(EXTI_Line3) != RESET)
  {
    //TURN_ON_GRN_LED;
    //guiDetectedCPS[1]++;  // Front #2   
    EXTI_ClearITPendingBit(EXTI_Line3);
    //TURN_OFF_GRN_LED;
    
    gucFrontDetectorDetected = 1;
  }
  
  
}

extern _ts_event ts_event; 



void EXTI9_5_IRQHandler(void)
{

  if(EXTI_GetITStatus(EXTI_Line9) != RESET)
  {   
   
    //guiDetectedCPS[0]++;  // Front #1   
    
    /* Clear the EXTI line 8 pending bit */
    EXTI_ClearITPendingBit(EXTI_Line9);
    
    gucFrontDetectorDetected = 1;
   
  }
  
   if(EXTI_GetITStatus(EXTI_Line5) != RESET)
  {   
    //TURN_ON_GRN_LED;
    //guiDetectedCPS[2]++;  // Front #3   
    
    /* Clear the EXTI line 5 pending bit */
    EXTI_ClearITPendingBit(EXTI_Line5);
    //TURN_OFF_GRN_LED;
    gucFrontDetectorDetected = 1;
  }
  
  if(EXTI_GetITStatus(EXTI_Line6) != RESET)
  { 
    //TURN_ON_GRN_LED;
    //guiDetectedCPS[3]++;  // Front #4   
    
    /* Clear the EXTI line 6 pending bit */
    EXTI_ClearITPendingBit(EXTI_Line6);
    //TURN_OFF_GRN_LED;
    gucFrontDetectorDetected = 1;
  }
  
  if(EXTI_GetITStatus(EXTI_Line8) != RESET)
  {   
    //TURN_ON_RED_LED;
    //guiDetectedCPS[7]++;  // Rear #4   
    
    /* Clear the EXTI line 8 pending bit */
    EXTI_ClearITPendingBit(EXTI_Line8);
    //TURN_OFF_RED_LED;
    
    gucRearDetectorDetected = 1;
  }
}
void EXTI15_10_IRQHandler(void)
{
  if(EXTI_GetITStatus(EXTI_Line14) != RESET)
  {
    //TURN_ON_RED_LED;
    //guiDetectedCPS[6]++;  // Rear #3 
    EXTI_ClearITPendingBit(EXTI_Line14);
    //TURN_OFF_GRN_LED;
    gucRearDetectorDetected = 1;
  }
}

void processU1ReceivedData(void)
{
        unsigned short ushtTemp;
        unsigned char ucNumOfBytes, uci;
        
       // U1 Receiving Process
        if(giUARTReceivingDone == 1)
        {
           giUARTReceivingDone = 0;
      
           //giPortReceivedDataTimeout = 5;
          //CRC Check
          if(giRxReceivedCnt > 4)
          {
            ushtTemp = CRC16(guRxBuffer1,giRxReceivedCnt-2); 
            if((guRxBuffer1[giRxReceivedCnt-2] == (u8)(ushtTemp%256)) && (guRxBuffer1[giRxReceivedCnt-1] == (u8)(ushtTemp/256)))
            {
              //giMasterRequestTimmeout = 60;  //60
              if((guRxBuffer1[0] == 10)&&(guRxBuffer1[1] == 16))   // feed back from PLC function code 16 
              {
                
                
              }
              
              if((guRxBuffer1[0] == 10)&&(guRxBuffer1[1] == 3))   // feed back from PLC function code 0x3 
              {
                ucNumOfBytes = guRxBuffer1[2];
                for(uci = 0; uci < ucNumOfBytes; uci++)
                {
                  gucCommandReceivedFromRemote[uci] = guRxBuffer1[3+uci];                  
                }
                
                gusRemoteDataReceived = 1;
                gusRemoteDataProcessReq = 1;
              }
              
              if((guRxBuffer1[0] == 1)&&(guRxBuffer1[1] == 16))   // feed back from VFD function code 16 
              {
                
              }
              
              if((guRxBuffer1[0] == 1)&&(guRxBuffer1[1] == 3))   // feed back from VFD function code 0x3 
              {
                
              }
            }
          }
          
          giRxReceivedCnt = 0;   // reset the communication
        }
}

extern int giSampleLocationNum,giLocationSampledTime;




/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
