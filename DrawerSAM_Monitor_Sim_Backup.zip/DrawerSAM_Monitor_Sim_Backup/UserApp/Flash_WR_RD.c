/**
  ******************************************************************************
  * @file    FLASH/Program/Read.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  ******************************************************************************
  */ 

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"

#include "Flash_WR_RD.h"
/* Private typedef -----------------------------------------------------------*/
typedef enum {FAILED = 0, PASSED = !FAILED} TestStatus;


/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
uint32_t StartSector = 0, EndSector = 0, Address = 0, SectorCounter = 0;
__IO uint32_t data32 = 0 , MemoryProgramStatus = 0;
  
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
uint32_t GetSector(uint32_t Address);

int eraseFlash(void)
{
  
  int i, iReturn;
  /* Unlock the Flash to enable the flash control register access *************/
  iReturn = 0;
  FLASH_Unlock();
    
  /* Erase the user Flash area
    (area defined by FLASH_USER_START_ADDR and FLASH_USER_END_ADDR) ***********/

  /* Clear pending flags (if any) */  
  FLASH_ClearFlag(FLASH_FLAG_EOP | FLASH_FLAG_OPERR | FLASH_FLAG_WRPERR | 
                  FLASH_FLAG_PGAERR | FLASH_FLAG_PGPERR|FLASH_FLAG_PGSERR); 

  /* Get the number of the start and end sectors */
  StartSector = GetSector(FLASH_DATA_START_ADDR);
  EndSector = GetSector(FLASH_DATA_END_ADDR);

  for (SectorCounter = StartSector; SectorCounter < EndSector; SectorCounter += 8)
  {
    /* Device voltage range supposed to be [2.7V to 3.6V], the operation will
       be done by word */ 
    if (FLASH_EraseSector(SectorCounter, VoltageRange_3) != FLASH_COMPLETE)
    { 
      /* Error occurred while sector erase. 
         User can add here some code to deal with this error  */
      //while (1)
      //{
      //}
      iReturn = 1;
    }
  }
}

int  writeIntToFlash(int *ptriData, unsigned int iStartFlashAddress, int iLength)
{
   int i, iReturn;
  /* Unlock the Flash to enable the flash control register access *************/
  iReturn = 0;
  
  Address = iStartFlashAddress;
  for(i = 0; i < iLength; i++)
  {
    
    
    if (FLASH_ProgramWord(Address, ptriData[i]) == FLASH_COMPLETE)
    {
      Address = Address + 4;
    }
    else
    { 
      /* Error occurred while writing data in Flash memory. 
         User can add here some code to deal with this error */
      
      //while (1)
      //{
      //}
      iReturn = 2;
    }
  }
  
  return iReturn;
  
}

void readIntToFlash(int *ptriData, unsigned int iStartFlashAddress, int iLength)
{
  
  int i;
  Address = iStartFlashAddress;
  
  for(i = 0; i < iLength; i++)
  {
    ptriData[i] = *(__IO uint32_t*)Address; 
    Address = Address + 4;
  }   
  
}




/**
  * @brief   Main program
  * @param  None
  * @retval None
  */
int programFlash(unsigned short *ptrusData,int iLength)
{
  
  int i, iReturn;
  /* Unlock the Flash to enable the flash control register access *************/
  iReturn = 0;
  FLASH_Unlock();
    
  /* Erase the user Flash area
    (area defined by FLASH_USER_START_ADDR and FLASH_USER_END_ADDR) ***********/

  /* Clear pending flags (if any) */  
  FLASH_ClearFlag(FLASH_FLAG_EOP | FLASH_FLAG_OPERR | FLASH_FLAG_WRPERR | 
                  FLASH_FLAG_PGAERR | FLASH_FLAG_PGPERR|FLASH_FLAG_PGSERR); 

  /* Get the number of the start and end sectors */
  StartSector = GetSector(FLASH_DATA_START_ADDR);
  EndSector = GetSector(FLASH_DATA_END_ADDR);

  for (SectorCounter = StartSector; SectorCounter < EndSector; SectorCounter += 8)
  {
    /* Device voltage range supposed to be [2.7V to 3.6V], the operation will
       be done by word */ 
    if (FLASH_EraseSector(SectorCounter, VoltageRange_3) != FLASH_COMPLETE)
    { 
      /* Error occurred while sector erase. 
         User can add here some code to deal with this error  */
      //while (1)
      //{
      //}
      iReturn = 1;
    }
  }

  /* Program the user Flash area word by word
    (area defined by FLASH_USER_START_ADDR and FLASH_USER_END_ADDR) ***********/

  Address = FLASH_DATA_START_ADDR;

  for(i = 0; i < iLength; i++)
  {
    
    if (FLASH_ProgramHalfWord(Address, ptrusData[i]) == FLASH_COMPLETE)
    {
      Address = Address + 2;
    }
    else
    { 
      /* Error occurred while writing data in Flash memory. 
         User can add here some code to deal with this error */
      
      //while (1)
      //{
      //}
      iReturn = 2;
    }
  }

  /* Lock the Flash to disable the flash control register access (recommended
     to protect the FLASH memory against possible unwanted operation) *********/
  FLASH_Lock();
  return iReturn;

}
 
void readFlash(unsigned short *ptrusData,int iLength)
{
  int i;
  Address = FLASH_DATA_START_ADDR;
  
  for(i = 0; i < iLength; i++)
  {
    ptrusData[i] = *(__IO uint16_t*)Address; 
    Address = Address + 2;
  }   
 
}

/**
  * @brief  Gets the sector of a given address
  * @param  None
  * @retval The sector of a given address
  */
uint32_t GetSector(uint32_t Address)
{
  uint32_t sector = 0;
  
  if((Address < ADDR_FLASH_SECTOR_1) && (Address >= ADDR_FLASH_SECTOR_0))
  {
    sector = FLASH_Sector_0;  
  }
  else if((Address < ADDR_FLASH_SECTOR_2) && (Address >= ADDR_FLASH_SECTOR_1))
  {
    sector = FLASH_Sector_1;  
  }
  else if((Address < ADDR_FLASH_SECTOR_3) && (Address >= ADDR_FLASH_SECTOR_2))
  {
    sector = FLASH_Sector_2;  
  }
  else if((Address < ADDR_FLASH_SECTOR_4) && (Address >= ADDR_FLASH_SECTOR_3))
  {
    sector = FLASH_Sector_3;  
  }
  else if((Address < ADDR_FLASH_SECTOR_5) && (Address >= ADDR_FLASH_SECTOR_4))
  {
    sector = FLASH_Sector_4;  
  }
  else if((Address < ADDR_FLASH_SECTOR_6) && (Address >= ADDR_FLASH_SECTOR_5))
  {
    sector = FLASH_Sector_5;  
  }
  else if((Address < ADDR_FLASH_SECTOR_7) && (Address >= ADDR_FLASH_SECTOR_6))
  {
    sector = FLASH_Sector_6;  
  }
  else if((Address < ADDR_FLASH_SECTOR_8) && (Address >= ADDR_FLASH_SECTOR_7))
  {
    sector = FLASH_Sector_7;  
  }
  else if((Address < ADDR_FLASH_SECTOR_9) && (Address >= ADDR_FLASH_SECTOR_8))
  {
    sector = FLASH_Sector_8;  
  }
  else if((Address < ADDR_FLASH_SECTOR_10) && (Address >= ADDR_FLASH_SECTOR_9))
  {
    sector = FLASH_Sector_9;  
  }
  else if((Address < ADDR_FLASH_SECTOR_11) && (Address >= ADDR_FLASH_SECTOR_10))
  {
    sector = FLASH_Sector_10;  
  }
  else/*(Address < FLASH_END_ADDR) && (Address >= ADDR_FLASH_SECTOR_11))*/
  {
    sector = FLASH_Sector_11;  
  }

  return sector;
}


/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
