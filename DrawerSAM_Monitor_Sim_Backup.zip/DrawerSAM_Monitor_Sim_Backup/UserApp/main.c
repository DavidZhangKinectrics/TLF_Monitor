/**
  ******************************************************************************
  * @file    PlasticSAM/main.c 
  * @author  David Zhang
  * @version V2.0
  * @date    Dec.15,2025
  * @brief   Main program body
  ******************************************************************************
  * Version History
  * 1.0 Jan. 18, 2024, Initial 
  * 2.0 Dec. 15, 2025, added Background cancellation and change the CPS unit to CPM.
  ******************************************************************************
  */ 

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"
#include "DataGrabber.h"
#include "usart.h"
#include "Peripheral.h"
#include "Flash_WR_RD.h"



#include "LCDControl_l.h"
#include "BitMapDisplay.h"
#include "PID.h"
#include "DataProcess.h"
#include"RA8876.h" 
#include"8876demo.h" 
#include"TP.h"  
#define cstDAC_NUM_TO_SET_HV_TO_1500V 200
#define cstDAC_NUM_TO_SET_HV_TO_1900V 3900
//
//#define cstScrnMain     1
//#define cstScrnTrend    2
//#define cstScrnSetup    3
//#define cstScrnStatus   4

#define cstDETECTOR_DISP_GAP            30
#define cstDETECTOR_DISP_R_A            75
#define cstDETECTOR_DISP_R_B            40

#define cstDETECTOR_DISP_FRONT_START_X  20+cstDETECTOR_DISP_R_A
#define cstDETECTOR_DISP_FRONT_Y        420
    
#define cstDETECTOR_DISP_REAR_START_X   75 + cstDETECTOR_DISP_FRONT_START_X
#define cstDETECTOR_DISP_REAR_Y         320    

#define TREND_X_ZOOM_OUT            60   // 60 seconds/Per Pixel


/** @addtogroup STM32F4xx_StdPeriph_Examples
  * @{
  */

/** @addtogroup TIM_TIM1_Synchro
  * @{
  */ 


/* Private functions ---------------------------------------------------------*/

/**
  * @brief  Main program
  * @param  None
  * @retval None
  */

void systick_setup(uint32_t sys_freq);


extern int giReceivingTimeOut;
extern int giUARTReceivingDone;
extern int giScanTick;


extern int giNewScanFlag;   
extern unsigned short gusDataPointIndex;
extern int giUpdateHVReg;

extern unsigned char guRxBuffer1[];

extern int giRxReceivedCnt;


//unsigned short gusNegHV_DAC_Cnt;
//unsigned short gusPosHV_DAC_Cnt;
//unsigned short gusFlashTempData[100];


 
extern unsigned char  gucU2TXBuf[];
extern unsigned char  gucU2RXBuf[];

extern unsigned char  gucU3TXBuf[];
extern unsigned char  gucU3RXBuf[];
extern int giU3ReceivedCnt;
unsigned short giU3NumByteToSend;

unsigned char gucDataBinary[100];
unsigned char gucDataBinaryToSend;

unsigned char gucU2TXDData[100];
unsigned char gucU2TXDCnt;
unsigned char gucU2RXBufForProcess[200];
unsigned char gucU2StateMechine;

extern unsigned char gusRemoteDataProcessReq;



int  giTrendX_Start;
int  giTrendY_LowValue,giTrendY_HighValue;

short gusCursorPosition;
int giInZoomedMode;
 
extern int giEnterKeyState;
extern int giDownKeyState;
extern int giUpKeyState;
extern int giEscKeyState;
//extern int giUpdateStatusScreenReq;

//extern PIDTypeDef gstructIMS_PID;
//extern PIDTypeDef gstructInnetPID;
//extern PIDTypeDef gstructDopantPID;
//extern PIDTypeDef gstructCalibPID;
//extern PIDTypeDef gstructPValvePID;
//extern PIDTypeDef gstructSamplePumpPID;

//extern int giEngineeringValue[];


extern int giRGSRequestToPurge;
extern int giRGSRequestToDry;

extern int giIMSRequestToNegMode;


extern int giUpdateMenuScreenReq;
extern unsigned char  gucU1TXBuf[];
extern int giRx1ReceivedCnt;

//extern int giRGSDeviceControlReq ;
//extern unsigned char gucRGSDeviceCommand_H;
//extern unsigned char gucRGSDeviceCommand_L;



extern unsigned short gucCommandForMain_RGS_Cnt;

//unsigned short gusTrendDataBufMax[1000],gusTrendDataBufMin[1000],gucRefreshTrendReq;  //giTrendStartHour, giTrendStartMinute,
unsigned short gusTrendEndPos,gusTrendStartPos; 
int giTrendStartTimeInSec;
int giStartNewTrend;
unsigned char gucCurrentYear, gucCurrentMonth, gucCurrentDay, gucCurrentHour, gucCurrentMinute, gucCurrentSecond;

SETTING_TypeDef gstructParameter;

//structDataRequestByHMI_TypeDef gstructDataRequestByHMI;

structDataRequestByHMI_TypeDef gstructDataRequestByHMI;

//extern unsigned short gusEngineeringUnitFactor[]; 
unsigned short gusMainScreenBackColor;

unsigned char guc25mSTick,guc1000mSTick;
unsigned char gucScrnNo;
unsigned char gucSystemStatus;


unsigned char gucSystemAlarmFlag,gucSystemWarningFlag;

unsigned short gusRxReceivedCnt_TEST, gusRxReceivedCnt_TEST_Max;
unsigned char gucDMASTARTED;

extern unsigned char gucSuperUserMode;
extern unsigned char gucLoggedIn;

unsigned char gucSaveParameterReq;

extern int giCommunicationTimeoutCnt;

//unsigned char gucScreenNum_SAVED = 0;

extern unsigned char g_ucItemSelected;

int giSampleLocationNum, giLocationSampledTime;
extern unsigned char  gucCommandReceivedFromRemote[];
extern unsigned char gucPumpOverLoaded;

extern StepMotorTypeDef gstructStepMotorControl;

//SYS_CONTROL_TypeDef gstructSystemControl;
//SYS_STATUS_TypeDef gstructSystemStatus;  

//extern int giDetectedCPS[];
//extern DetectorTypeDef gstruDetector[];

extern unsigned char gucFrontDetectorDetected,gucRearDetectorDetected;

extern int giADC_ResultAve[];


TouchStatusDef gstructTouchStatus;

int giBothButtonPressed25mSCnt = 0;

short gsProcessEng[10]; // Engineering values of Devices Pressure, O2, CH2, Flow

SysStateTypeDef gtSysState;
SysControlTypeDef gtSysControl;

int giPV_Sum[14];
int giSummingCnt = 0;

unsigned char gucScreen_Shadow = 0;
unsigned char gucUpdateScreenReg = 0;


PIDTypeDef gstructRechargePVPID;
PIDTypeDef gstructPumpPID;


short gsInO2,gsInCH4,gsInFS1,gsInPS1,gsPump,gsSV1,gsPV_Rech,gsFS_Rech,gsOut_FS2,gsOutO2,gsOutCH4,gsOutPS2;
 

int main(void)
{
  /*!< At this stage the microcontroller clock setting is already configured, 
       this is done through SystemInit() function which is called from startup
       file (startup_stm32f4xx.s) before to branch to application main.
       To reconfigure the default setting of SystemInit() function, refer to
       system_stm32f4xx.c file
     */   
  
  int i,j;
  short si; 
 // int miTIM8TickCnt;
  float fTemp;
  //unsigned short usUSART1_DMACnt,usUSART1_DMACnt_SAVED;
  //unsigned short usUSART2_DMACnt,usUSART2_DMACnt_SAVED;
  //unsigned short usUSART3_DMACnt,usUSART3_DMACnt_SAVED;
  unsigned short usTemp;
  //unsigned char *puc;
  //unsigned char ucStr[10];
  unsigned char ucModeSwitchStateCnt[5];  // Count the position state - over 10x25mS, switch to teh State
  
  unsigned char ucSystemWarmuped = 0;

  //unsigned int TestBit;
  

  
  //int iTrendSectionIndex; // total 8 sections, each ms as a section and cursor values as a section
  //int iScreenNoSAVED;
  
  //int i10mSCnt;
  
  //unsigned char mucSrnNo_SAVED,mucSetupSrnBeenRefreshed;
 // unsigned char mucSystemAlarmFlag_SAVED,mucSystemWarningFlag_SAVED;
  
  //unsigned char mucBeeperOnFlag,mucToggleBeep;
  
  //unsigned char mucCurrentSecondSaved;
  
 // unsigned char mucPowerOnStartup;
  
  //unsigned char mucU1CommandFlag_Saved;
  //int miLocationSaved;
  
 // static int siHV_LOWDetectionCnt = 0;
  static int siSoundControl25mSIndex = 0;  
  
  
  delay_ms(30);
  
  gucU2StateMechine = 0; ;
  
  gusRemoteDataProcessReq = 0;
 
  giTrendStartTimeInSec = 12*3600;
    

  

  gucSuperUserMode = 0;
  gucLoggedIn = 0;
  g_ucItemSelected = 1;
  
  giLocationSampledTime = 0;
  
  gstructStepMotorControl.ucStart = 0;
  gstructStepMotorControl.ucFORWARDDIR = 0;
  gstructStepMotorControl.ucInHalfStepMode =  1;
  
  gstructRechargePVPID.fKp = 1;//10.0;//
  gstructRechargePVPID.fKi = 0.1;//1.0;
  gstructRechargePVPID.fKd = 0.01;
  gstructRechargePVPID.fPID_Int = 400.0; // Preload 40%
  gstructRechargePVPID.fLowLimit = 0.0;
  gstructRechargePVPID.fHighLimit = 999.0;   // 99.9%
  gstructRechargePVPID.fDeadBand = 0.0; // Not set 
  
  gstructPumpPID.fKp = 0.5;//1.0;//
  gstructPumpPID.fKi = 0.1;//1.0;
  gstructPumpPID.fKd = 0.01;
  gstructPumpPID.fPID_Int = 300.0; // Preload 30%
  gstructPumpPID.fLowLimit = 0.0;
  gstructPumpPID.fHighLimit = 999.0;   // 99.9%
  gstructPumpPID.fDeadBand = 0.0; // Not set 
  
  
  gtSysState.sCurrentPV_Point = 0;
  gtSysState.sPV_NextIndex = 0;
  gtSysState.sTrendDataInMinute = 0;
  
  for(i = 0; i < 5; i++)
    ucModeSwitchStateCnt[i] = 0;
   
  readIntToFlash((int *)(&gstructParameter), FLASH_PeakSeachSettingDATA_START_ADDR, 40);  
  if(gstructParameter.iValidDataFlag != 0xA5AA55AA)
  {
      
        //SetFlowInMormal_H;
        gstructParameter.iValidDataFlag = 0xA5AA55AA;
        gstructParameter.iFlowLowAlarmSetting = 100;  // 10.0 mL/M  The Inlet flow from Whole Body Monitor is low to detectPin Hole in WBM
        gstructParameter.iOutFlowO2LevelAlarmSetting = 10;    // 1.0% O2 level 
   
         // Inlet Pressure     MP3H6115AC         VS x (0.009 x P � 0.095)
         gstructParameter.iZero[0] =  -389;      // Zero ADC Counts = 3.3*(-0.095) /3.3*4095
         gstructParameter.iUpScale[0] = 3849;     // Full Scale 115 KPa Output   = VS x (0.009 x 115) 
         gstructParameter.iRange[0]  = 167;     // 115.0 Kpa(16.7-14.7)
         
         // Inlet Flow sensor : D6F-P0001A1           0 ml/M - 0.5V, 20ml/M - 0.9V, 40mL/M - 1.3V
         gstructParameter.iZero[1] =  620;      // Zero ADC Counts = 0.5
         gstructParameter.iUpScale[1] = 3102;     // Full Scale 115 KPa Output   = 2.5 
         gstructParameter.iRange[1]  = 1000;     // 100.0 mL/M
         
          // Outlet Flow sensor : D6F-P0001A1           0 ml/M - 0.5V, 20ml/M - 0.9V, 40mL/M - 1.3V
         gstructParameter.iZero[2] =  620;      // Zero ADC Counts = 0.5
         gstructParameter.iUpScale[2] = 3102;     // Full Scale 115 KPa Output   = 2.5 
         gstructParameter.iRange[2]  = 1000;     // 100.0 mL/M
         
         //  Not used Exhaust Flow sensor : D6F-P0001A1           0 ml/M - 0.5V, 20ml/M - 0.9V, 40mL/M - 1.3V
         gstructParameter.iZero[3] =  620;      // Zero ADC Counts = 3.3*(0.5) /3.3*4095
         gstructParameter.iUpScale[3] = 3102;     // Full Scale 115 KPa Output   = VS x (0.009 x 115) 
         gstructParameter.iRange[3]  = 1000;     // 100.0 mL/M
         
         // Not Used - Recharge Flow sensor : D6F-P0001A1           0 ml/M - 0.5V, 20ml/M - 0.9V, 40mL/M - 1.3V
         gstructParameter.iZero[4] =  620;      // Zero ADC Counts = 3.3*(0.5) /3.3*4095
         gstructParameter.iUpScale[4] = 3102;     // Full Scale 115 KPa Output   = VS x (0.009 x 115) 
         gstructParameter.iRange[4]  = 1000;     // 100.0 mL/M         
         
         // Outlet Pressure     MP3H6115AC         VS x (0.009 x P � 0.095)
         gstructParameter.iZero[5] =  -389;      // Zero ADC Counts = 3.3*(-0.095) /3.3*4095
         gstructParameter.iUpScale[5] = 3849;     // Full Scale 115 KPa Output   = VS x (0.009 x 115-0.095)/3.3*4095
         gstructParameter.iRange[5]  = 167;     // 115.0 Kpa (16.7-14.7)
         
          // Inlet O2 Sensor     SGX-4OX-ROHS         
         gstructParameter.iZero[6] = 2038;      // Zero ADC Counts = (-0.015 + 3.3)/2/3.3*4095 - here 0.015 is 0.0015(0.3% of V%)*10K
         gstructParameter.iUpScale[6] = 1375;     // Full Scale 20% Output   = (-1.000 + 3.3)/2/3.3*4095 - here -1.0 is 0.1(20% of V%)*10K
         gstructParameter.iRange[6]  = 200;     // 20.0 %
         
         //Outlet O2 Sensor     SGX-4OX-ROHS         
         gstructParameter.iZero[7] = 2038;      // Zero ADC Counts = (-0.015 + 3.3)/2/3.3*4095 - here 0.015 is 0.0015(0.3% of V%)*10K
         gstructParameter.iUpScale[7] = 1375;     // Full Scale 20% Output   = (-1.000 + 3.3)/2/3.3*4095 - here -1.0 is 0.1(20% of V%)*10K
         gstructParameter.iRange[7]  = 200;     // 20.0 %
         
          // Inlet CH4 Sensor     JNT-CH4        
         gstructParameter.iZero[8] =  500;      // Zero ADC Counts = 500
         gstructParameter.iUpScale[8] = 2500;     // Full Scale 10% Output
         gstructParameter.iRange[8]  = 100;     // 10.0 %
         
           // Inlet CH4 Sensor     JNT-CH4        
         gstructParameter.iZero[9] =  500;      // Zero ADC Counts = 500
         gstructParameter.iUpScale[9] = 2500;     // Full Scale 10% Output
         gstructParameter.iRange[9]  = 100;     // 10.0 %
   
         gstructParameter.iPassword = 123;
         gstructParameter.iCH4_FlowSetting =  400;  // 40.0mL/M  
         gstructParameter.iStartRecoveryO2Level = 250;//40;      // 4.0%
         gstructParameter.iPumpBaseSetting = 500;  //50.0%
         gstructParameter.iPumpModifier = 0;   // Pump final speed = iPumpBaseSetting + (iCH4_FlowSetting-InletFlow)*iPumpModifier
         gstructParameter.iSpare0 = 0;
         gstructParameter.iPanelAddress = 321;  

        i = eraseFlash();  // unlock in this subroutine      
        i = writeIntToFlash((int *)(&gstructParameter), FLASH_PeakSeachSettingDATA_START_ADDR, 40); //maximum 23 integer  
      
        FLASH_Lock();
        
      
    
      }
 
//      giBackGroundCPS[0] = gstructParameter.iBackGroundCPSDet0;
//      giBackGroundCPS[1] = gstructParameter.iBackGroundCPSDet1;
//      giBackGroundCPS[2] = gstructParameter.iBackGroundCPSDet2;
//      giBackGroundCPS[3] = gstructParameter.iBackGroundCPSDet3;
//      giBackGroundCPS[4] = gstructParameter.iBackGroundCPSDet4;
//      giBackGroundCPS[5] = gstructParameter.iBackGroundCPSDet5;
//      giBackGroundCPS[6] = gstructParameter.iBackGroundCPSDet6;
//      giBackGroundCPS[7] = gstructParameter.iBackGroundCPSDet7;
    
      InitPorts_Timers();
    
  
      delay_ms(10);//delay for RA8876 power on
      RA8876_HW_Reset();
      delay_ms(100);
      
      RA8876_initial();
        
      Write_Dir(0X01,0X80);//display on
	   
      //full display test
      Test();
        
       ////////////RA8875 internal input character test
       Text_Foreground_Color1(color_yellow);//Set the foreground color
       Write_Dir(0x2E,0x01);//Set the characters mode 16 x16 / spacing 1
       Write_Dir(0x40,0x80);//Set the character mode
       Write_Dir(0x21,0x10);//Select the internal CGROM  ISO/IEC 8859-1.
       FontWrite_Position(80,5);//Text written to the position
                    
       /////// Geometric pattern drawing test
       gusMainScreenBackColor = color65k_black;
       
       ClearWholeScreen(gusMainScreenBackColor);
        
        //Draw_Ellipse(210,120,205,105);
        Draw_Circle(200,200,100);
        Text_Foreground_Color1(color_cyan);//Color Settings
        Write_Dir(0XA0,0X10);//Setting parameters
        Write_Dir(0XA0,0X90);//Start drawing
        
         i = outXYColorWithScale(10, 100, 3, "P10    Recovery    System", color65k_white, gusMainScreenBackColor, 2, 2);
         i = outXYColorWithScale(190, 200, 3, "Sensetecz  Enineering   Inc.", color65k_white, gusMainScreenBackColor, 1, 1);
         i = outXYColorWithScale(190, 250, 3, "Version    1.0", color65k_white, gusMainScreenBackColor, 1, 1);
         
         //drawEllipse(100, 400,41, 21, color65k_black, color65k_white, color65k_red, 0,1);
         
         //drawLine(10, 10, 200, 200, color65k_white, gusMainScreenBackColor);

         
         for(i = 0; i < 7; i++)
         {
           delay_ms(50);
         }
         
         //delay_ms(3000);
         
      TOUCH_Init();
 
      //giIMSRequestToPosMode = 0;
      gucU2TXDData[0] = 1;
      gucU2TXDData[1] = 16;
           
      gucU2TXDData[2] = 0;
      gucU2TXDData[3] = 0;
           
      gucU2TXDData[4] = 0;
      gucU2TXDData[5] = 2;
      gucU2TXDData[6] = 4;
      gucU2TXDData[7] = 0;
      gucU2TXDData[8] = 0x1;
      gucU2TXDData[9] = 0;
      gucU2TXDData[10] = 0;  // Pos
      usTemp = CRC16(gucU2TXDData,11);
      gucU2TXDData[11] = (unsigned char)(usTemp%256);
      gucU2TXDData[12] = (unsigned char)(usTemp/256);
      USART2_TX_DMA_Config(gucU2TXDData, 13);

      giTrendX_Start = 80;//0;
      giTrendY_LowValue = 0;    // -330mV
      giTrendY_HighValue = 51188;//3300mV
  
      gusCursorPosition = 175;
  
      giInZoomedMode = 0;
  


      //PAR_CycleTime = 170; // 17.0 Seconds

      //giIMSRequestToPosMode = 0;
      gucU2TXDData[0] = 1;
      gucU2TXDData[1] = 16;
           
      gucU2TXDData[2] = 0;
      gucU2TXDData[3] = 0;
           
      gucU2TXDData[4] = 0;
      gucU2TXDData[5] = 2;
      gucU2TXDData[6] = 4;
      gucU2TXDData[7] = 0;
      gucU2TXDData[8] = 0x1;
      gucU2TXDData[9] = 0;
      gucU2TXDData[10] = 0;  // Pos
      usTemp = CRC16(gucU2TXDData,11);
      gucU2TXDData[11] = (unsigned char)(usTemp%256);
      gucU2TXDData[12] = (unsigned char)(usTemp/256);
      USART2_TX_DMA_Config(gucU2TXDData, 13);
      
      if(gstructParameter.iPanelAddress == 0)         
        gstructDataRequestByHMI.ucFrameStartPulse =0xaa;
      else
        gstructDataRequestByHMI.ucFrameStartPulse =0x55;
  
      gstructDataRequestByHMI.ucRequestBits1 = 0;    // bit.7 request to change Date/Time, .6 for Offset, .5 for Unit ID
      gstructDataRequestByHMI.ucRequestBits2 =0;
      gstructDataRequestByHMI.ucNewYear = 3;    
      gstructDataRequestByHMI.ucNewMonth = 4;
      gstructDataRequestByHMI.ucNewDay = 5;
      gstructDataRequestByHMI.ucNewHour = 6;
      gstructDataRequestByHMI.ucNewMinute =7;
      gstructDataRequestByHMI.ucNewSecond =8;
  
      gstructDataRequestByHMI.iNewOffset = 9;
  
      gstructDataRequestByHMI.iNewUnitID =10;
      gstructDataRequestByHMI.iNewT_SpareAlarmLevel = 11;
      gstructDataRequestByHMI.iNewGammaAlarmLevel = 12;
      gstructDataRequestByHMI.iNewT_SpareAlarmLevelGain = 13;
      gstructDataRequestByHMI.iNewPressureKpa = 14;
      gstructDataRequestByHMI.iNewFlowRate = 15;
      gstructDataRequestByHMI.ssNewBodyTempSetting = 16;
      gstructDataRequestByHMI.ssNewHumSetting = 17;
      gstructDataRequestByHMI.ssNewDataLoggingInterval = 18;
      gstructDataRequestByHMI.ucPumpSpeed = 19;
      gstructDataRequestByHMI.ucPressureCompensation = 20;
   
      gstructDataRequestByHMI.iSpare1= 21;
  
      gstructDataRequestByHMI.iSpare2 = 22;
  
      gucDMASTARTED = 1;
            

         
       playMusic();
       delay_ms(500);  
 
      systick_setup(SystemCoreClock);    
      NVIC_SetPriority(SysTick_IRQn,5);
 
      //gstructSystemControl.ucSysMode = 0;
      //gstructSystemControl.ucFirstScan = 1;
 
      EN_HV;  
 
      //gstructSystemStatus.ucButtonStatus_Saved = 0;
  
      gusMainScreenBackColor = color_blue;
      ClearWholeScreen(gusMainScreenBackColor);
      gucScrnNo = cstScrnMain;
      
      
      Set_V3_Exhaust_PWM(0);
      //Set_V2_Recir_PWM(0);
      gtSysControl.sSV_Exhaust = 0;
      if (gtSysControl.sSV_Exhaust == 0)        
        TurnOffExhaustSV1;
      else
        TurnOnExhaustSV1;
      
      Set_V1_Refill_PWM(0);
      Set_Pump_PWM(0);
      
      giSummingCnt = 0;
      for(i = 0; i < 14; i++)
      {
        giPV_Sum[i] = 0;
      }
      
  gtSysControl.sAutoRecoveryStateM = AUTO_RECOVERY_IN_PURGE;
  gtSysControl.sReturnedFlowSearchCnt = 0;
  
  while (1)
  {
        
        // Task for every 25mS
        if(guc25mSTick==1)
        {          
          guc25mSTick = 0;          
          Set_WTD_Hi;
          
          TouchScan();  // Takes 0.8mS 
          
          TURN_OFF_GRN_LED;
          TURN_OFF_RED_LED;
          
            
          if SWITCH_IN_IDLE     
          {
            if(ucModeSwitchStateCnt[0] < 20)
              ucModeSwitchStateCnt[0]++;
            if(ucModeSwitchStateCnt[0] == 10)
            {
              gtSysState.ucSysState = E_IDLE;
              gucScrnNo = cstScrnMain;              
            }
          }
          else
            ucModeSwitchStateCnt[0] = 0;
         
          if SWITCH_IN_PURGE   
          {
            if(ucModeSwitchStateCnt[1] < 20)
              ucModeSwitchStateCnt[1]++;           
            if(ucModeSwitchStateCnt[1] == 10)
            {
              gtSysState.ucSysState = E_PURGE;    // PUMP IS OFF, 40mL/M in RECHARGE 
              gucScrnNo = cstScrnMain;              
            }
          }
          else
            ucModeSwitchStateCnt[1] = 0;
          
          if SWITCH_IN_RECIR    
          {
            if(ucModeSwitchStateCnt[2] < 20)
              ucModeSwitchStateCnt[2]++;             
            if(ucModeSwitchStateCnt[2] == 10)
            {
              gtSysState.ucSysState = E_AUTO_CIRCULATE;      // AUTO CIRCULATE MODE, <40mL/M in RECHARGE
              gucScrnNo = cstScrnMain;              
            }
          }
          else
            ucModeSwitchStateCnt[2] = 0;
          
          if SWITCH_IN_SETUP  
          {
            if(ucModeSwitchStateCnt[3] < 20)
              ucModeSwitchStateCnt[3]++; 
            if(ucModeSwitchStateCnt[3] == 10)
            {
               gtSysState.ucSysState = E_SETUP;      // SETUP MOde
               gucScrnNo = cstScrnSetup;
               ucModeSwitchStateCnt[3] = 10;
            }
          }
          else          
            ucModeSwitchStateCnt[3] = 0;
          
          
          // Update the screen 
          if (ucSystemWarmuped > 0)
          {
            if(gucScrnNo == cstScrnMain)
            {            
              if(gucScreen_Shadow != cstScrnMain)
              {   
                refreshMainScreen();  //max. 150mS
                gucScreen_Shadow = cstScrnMain;
              }
              else
              {                          
                updateMainScreen();              
              }  
            }          
           
            if(gucScrnNo==cstScrnTrend)
            {    
 
              if(gucScreen_Shadow != cstScrnTrend)
              {       
                refreshTrendScreen();  //max. 150mS
                gucScreen_Shadow = cstScrnTrend;
              }
              else
              {                          
                updateTrendScreen();              
              } 
            }    
          
            if(gucScrnNo==cstScrnSetup)
            {  
              if(gucScreen_Shadow != cstScrnSetup)
              { 
                refreshSetupScreen();//max. 150mS
                gucScreen_Shadow = cstScrnSetup;
              }
              else
              {                          
                updateSetupScreen();              
              } 
            }
         }
          /*
          if(j !=0)
          {
            if(siSoundControl25mSIndex == 0)
            {
              SoundControl(1, 1344);    // Turn ON  // was 1344
            }
            
            if(siSoundControl25mSIndex == 5)  // 250mS
            {
              SoundControl(0,1344);   // Turn OFF
            }
            
            if(siSoundControl25mSIndex == 20)
            {
              SoundControl(1, 2058);    // Turn ON  // was 1344
            }
            
            if(siSoundControl25mSIndex == 25)  // 250mS
            {
              SoundControl(0,2058);   // Turn OFF
            }
            
            siSoundControl25mSIndex++;
            if(siSoundControl25mSIndex == 80)
            {
              siSoundControl25mSIndex = 0;
            }
          }
          else
          {
             SoundControl(0, 1000);   // Turn OFF
             siSoundControl25mSIndex = 0;
          }
          */
         
          Set_WTD_Low;
          
        }
        // End of 25mSTask
        
        
        // Task for every 1000mS
        if(guc1000mSTick==1)
        {          
          guc1000mSTick = 0;          
          
          if(ucSystemWarmuped < 10)
            ucSystemWarmuped++;

          //Calculate engineering Value 
          for(i=0; i<10;i++)
          {
            fTemp =  gstructParameter.iRange[i]*1.0*(giADC_ResultAve[i]-gstructParameter.iZero[i]);
            fTemp = fTemp/(gstructParameter.iUpScale[i]-gstructParameter.iZero[i]);
            if((fTemp < 0)&&(i != 1)&&(i != 2)&&(i != 4))
               fTemp = 0;
            gsProcessEng[i] = (int)fTemp;
          }
                 
          gsInO2 = gsProcessEng[6];            
          gsInCH4 = gsProcessEng[8];
          gsInFS1 = gsProcessEng[1];
         
          gsInPS1 = gsProcessEng[0];
          gsPump = gtSysControl.sPump;          
          gsSV1 = gtSysControl.sSV_Exhaust;
           
          gsPV_Rech = gtSysControl.sPV_Recharge;
          gsOut_FS2 = gsProcessEng[2];
          if(gsSV1!=0)
            gsFS_Rech = gsOut_FS2;
          else
            gsFS_Rech = gsOut_FS2-gsInFS1;// gsProcessEng[4];
          
          
          gsOutO2 = gsProcessEng[7];
          gsOutCH4 = gsProcessEng[9];
          gsOutPS2 = gsProcessEng[5];  
           
          //Operation Control 
          switch(gtSysState.ucSysState)
          {
            case E_IDLE:
              gtSysControl.sPump = 0;
              gtSysControl.sSV_Exhaust = 10;
              gtSysControl.sPV_Recharge = 0;
              gtSysControl.sAutoRecoveryStateM = AUTO_RECOVERY_IN_PURGE;
              gtSysControl.sReturnedFlowSearchCnt = 0;
              gtSysControl.fReturnFlow = 0.0;
              break;
              
            case E_PURGE:
              gtSysControl.sPump = 0;
              gtSysControl.sSV_Exhaust = 10;  // ON 
               //  Recharge Proportional Valve PID
              gstructRechargePVPID.fPV = (float)gsOut_FS2*0.1;
              gstructRechargePVPID.fSP = (float)gstructParameter.iCH4_FlowSetting*0.1;             
              PID_Heating(&gstructRechargePVPID);
              gtSysControl.sPV_Recharge = (short)gstructRechargePVPID.fPID_out;
              gtSysControl.sAutoRecoveryStateM = AUTO_RECOVERY_IN_PURGE;
              gtSysControl.sReturnedFlowSearchCnt = 0;
              gtSysControl.fReturnFlow = 0.0;
              break;
              
            case E_AUTO_CIRCULATE:
            case E_SETUP:
              
              switch(gtSysControl.sAutoRecoveryStateM )
              {
                case AUTO_RECOVERY_IN_PURGE:
                  // Action:
                  //  Recharge Proportional Valve PID
                  gstructRechargePVPID.fPV = (float)gsOut_FS2*0.1;
                  gstructRechargePVPID.fSP = (float)gstructParameter.iCH4_FlowSetting*0.1;             
                  PID_Heating(&gstructRechargePVPID);
                  gtSysControl.sPV_Recharge = (short)gstructRechargePVPID.fPID_out;
                  gtSysControl.sSV_Exhaust = 10;  // ON 
                  gtSysControl.sPump = 0;         // Pump Off
                  gtSysControl.sDelayTimer = 0;
                  // Transition:
                  if((gsInO2 < gstructParameter.iStartRecoveryO2Level) && (gsOut_FS2 > gstructParameter.iCH4_FlowSetting - 30))
                  {
                    if(gtSysControl.sReturnedFlowSearchCnt < O2_LEVEL_LOW_TIME_REQUIRED)
                    {
                      gtSysControl.sReturnedFlowSearchCnt++;
                      gtSysControl.fReturnFlow += (float)gsInFS1/O2_LEVEL_LOW_TIME_REQUIRED;
                    }
                    else
                    {
                      gtSysControl.sReturnedFlowSearchCnt = 0; //Reset the Count
                      gtSysControl.sAutoRecoveryStateM = AUTO_RECOVERY_PRESET_RECHARGE_FLOW;
                    }
                  }
                  else
                  {
                    gtSysControl.sReturnedFlowSearchCnt = 0;
                    gtSysControl.fReturnFlow = 0.0;
                  }
                  break;
                  
                case AUTO_RECOVERY_PRESET_RECHARGE_FLOW:
                  // Action:
                  //  Preset the recharge 
                  gstructRechargePVPID.fPV = (float)gsOut_FS2*0.1;
                  fTemp = (float)gstructParameter.iCH4_FlowSetting*0.1 - gtSysControl.fReturnFlow*0.1;
                  if(fTemp < 2.0)
                    fTemp = 4.0;  // 90%
                  if(fTemp > (float)gstructParameter.iCH4_FlowSetting*0.1)
                    fTemp = 30.0;  // Maximum 30                    
                  gstructRechargePVPID.fSP = fTemp;             
                  PID_Heating(&gstructRechargePVPID);
                  gtSysControl.sPV_Recharge = (short)gstructRechargePVPID.fPID_out;
                  gtSysControl.sSV_Exhaust = 10;  // ON 
                  gtSysControl.sPump = 0;         // Pump Off
                  // Transition:
                  fTemp = gstructRechargePVPID.fPV - gstructRechargePVPID.fSP;
                  
                  if((fTemp > -2) && (fTemp < 2))
                  {
                    if(gtSysControl.sDelayTimer < 5)  // 5 second delay
                    {
                      gtSysControl.sDelayTimer++;                      
                    }
                    else
                    {
                      gtSysControl.sDelayTimer = 0;
                      gtSysControl.sAutoRecoveryStateM = AUTO_RECOVERY_CLOSE_EXHAUST_SET_PUMP_SPEED;
                    }
                  }
                  else
                  {
                    gtSysControl.sDelayTimer = 0;                    
                  }
                  break;
                
               case AUTO_RECOVERY_CLOSE_EXHAUST_SET_PUMP_SPEED:
                  // Action:  
                  gtSysControl.sSV_Exhaust = 0;  // OFF 
                  // Find Pump Speed by PID                  
                  gstructPumpPID.fPV = (float)gsInFS1*0.1;                                   
                  gstructPumpPID.fSP = gtSysControl.fReturnFlow*0.1;  // Target flow in mL/M           
                  PID_Heating(&gstructPumpPID);
                  gtSysControl.sPump = (short)gstructPumpPID.fPID_out;         // Update Pump Speed
                  // Transition:
                  fTemp = gstructPumpPID.fPV - gstructPumpPID.fSP;
                  
                  if((fTemp > -5) && (fTemp < 5))
                  {
                    if(gtSysControl.sDelayTimer < 5)  // 5 second delay
                    {
                      gtSysControl.sDelayTimer++;                      
                    }
                    else
                    {
                      gtSysControl.sDelayTimer = 0;
                      gtSysControl.sAutoRecoveryStateM = AUTO_RECOVERY_NORMAL;
                    }
                  }
                  else
                  {
                    gtSysControl.sDelayTimer = 0;                    
                  }
                  break;
                  
              case AUTO_RECOVERY_NORMAL:
                  // Action:  
                  gtSysControl.sSV_Exhaust = 0;  // OFF 
                                  
                  //  Recharge Proportional Valve PID
                  gstructRechargePVPID.fPV = (float)gsOut_FS2*0.1;
                  gstructRechargePVPID.fSP = (float)gstructParameter.iCH4_FlowSetting*0.1;             
                  PID_Heating(&gstructRechargePVPID);
                  gtSysControl.sPV_Recharge = (short)gstructRechargePVPID.fPID_out;
                  gtSysControl.sSV_Exhaust = 0;  // OFF
                  // gtSysControl.sPump = 0;         // Pump will keep the setting in previous step
                  
                  // Transition:
                  if(gsInO2 > gstructParameter.iStartRecoveryO2Level)
                  {
                    if(gtSysControl.sDelayTimer < O2_LEVEL_LOW_TIME_REQUIRED)
                    {
                      gtSysControl.sDelayTimer++;                      
                    }
                    else
                    {                      
                      gtSysControl.sAutoRecoveryStateM = AUTO_RECOVERY_IN_PURGE;
                    }
                  }
                  else
                  {
                    gtSysControl.sDelayTimer= 0;                    
                  }
                  break;
                  
                default:
                  break;
              }
              break;
                
              
            
           
              
            default:
              break;
          }
          
                    
          // Trend data 
          si = gtSysState.sPV_NextIndex;
         
          if (gtSysState.sTrendDataInMinute == 0)  // In second Mode
          { 
            gtSysState.sCurrentPV_Point = si;
                      
            gtSysState.sInO2[si] = gsProcessEng[6];
            
            gtSysState.sInCH4[si] = gsProcessEng[8];
            gtSysState.sInFS1[si] = gsProcessEng[1];
         
            gtSysState.sInPS1[si] = gsProcessEng[0];
            gtSysState.sPump[si] = gtSysControl.sPump;          
            gtSysState.sSV1[si] = gtSysControl.sSV_Exhaust;
            //gtSysState.sPV1[si] = gtSysControl.sPV_Recharge;
            
            gtSysState.sPV_Rech[si] = gtSysControl.sPV_Recharge;
          
            //gtSysState.sFS3[si] = gsProcessEng[3];
           
            gtSysState.sOut_FS2[si] = gsProcessEng[2];
            if(gtSysState.sSV1[si] != 0)
              gtSysState.sFS_Rech[si] = gtSysState.sOut_FS2[si];
            else
              gtSysState.sFS_Rech[si] = gtSysState.sOut_FS2[si]- gtSysState.sInFS1[si];//gsProcessEng[4];
            gtSysState.sOutO2[si] = gsProcessEng[7];
            gtSysState.sOutCH4[si] = gsProcessEng[9];
            gtSysState.sOutPS2[si] = gsProcessEng[5];          
  
            si++;
           
          }
          else
          {
            for(i = 0; i < 10; i++)
            {
              giPV_Sum[i] = giPV_Sum[i] + (int)gsProcessEng[i];
            }
            giPV_Sum[10] =  giPV_Sum[10]+(int)gtSysControl.sPump;
            giPV_Sum[11] =  giPV_Sum[11]+(int)gtSysControl.sSV_Exhaust;
            //giPV_Sum[12] =  giPV_Sum[12]+(int)gtSysControl.sPV1;
            giPV_Sum[13] =  giPV_Sum[13]+(int)gtSysControl.sPV_Recharge;
            
            
            giSummingCnt++;
            if(giSummingCnt == TREND_X_ZOOM_OUT)              
            {
              giSummingCnt = 0;
              gtSysState.sCurrentPV_Point = si;
              
              gtSysState.sInO2[si] =  (short)(giPV_Sum[6]/TREND_X_ZOOM_OUT);
              gtSysState.sInCH4[si] = (short)(giPV_Sum[8]/TREND_X_ZOOM_OUT);
              gtSysState.sInFS1[si] = (short)(giPV_Sum[1]/TREND_X_ZOOM_OUT);
         
              gtSysState.sInPS1[si] = (short)(giPV_Sum[0]/TREND_X_ZOOM_OUT);
              gtSysState.sPump[si] = (short)(giPV_Sum[10]/TREND_X_ZOOM_OUT);          
              gtSysState.sSV1[si] = (short)(giPV_Sum[11]/TREND_X_ZOOM_OUT);
              //gtSysState.sPV1[si] = (short)(giPV_Sum[12]/60);
              gtSysState.sPV_Rech[si] = (short)(giPV_Sum[13]/TREND_X_ZOOM_OUT);
          
              //gtSysState.sFS3[si] = (short)(giPV_Sum[3]/TREND_X_ZOOM_OUT);
             
              gtSysState.sOut_FS2[si] = (short)(giPV_Sum[2]/TREND_X_ZOOM_OUT);
              if(gtSysState.sSV1[si] != 0)
                gtSysState.sFS_Rech[si] = gtSysState.sOut_FS2[si];
              else
                gtSysState.sFS_Rech[si] = gtSysState.sOut_FS2[si]- gtSysState.sInFS1[si];//(short)(giPV_Sum[4]/TREND_X_ZOOM_OUT);
          
              gtSysState.sOutO2[si] = (short)(giPV_Sum[7]/TREND_X_ZOOM_OUT);
              gtSysState.sOutCH4[si] = (short)(giPV_Sum[9]/TREND_X_ZOOM_OUT);
              gtSysState.sOutPS2[si] = (short)(giPV_Sum[5]/TREND_X_ZOOM_OUT);   
              
              for(i = 0; i < 14; i++)
              {
                giPV_Sum[i] = 0;
              }
              
              si++;
              
            }
          }
          
          if(si == MAX_PV_NUM )
          {
            if (gtSysState.sTrendDataInMinute == 0)  // was startup
            {
              // Change the data to Minute Mode
              
              for(j = 0; j < (MAX_PV_NUM/TREND_X_ZOOM_OUT); j++)
              {
                for(i = 0; i < 14; i++)
                {
                  giPV_Sum[i] = 0;
                }
                for(i = (j*TREND_X_ZOOM_OUT); i < (j*TREND_X_ZOOM_OUT+TREND_X_ZOOM_OUT); i++)
                {
                  giPV_Sum[0]+=(int)gtSysState.sInO2[i]; 
                  giPV_Sum[1]+=(int)gtSysState.sInCH4[i];
                  giPV_Sum[2]+=(int)gtSysState.sInFS1[i];
                  giPV_Sum[3]+=(int)gtSysState.sInPS1[i]; 
                  giPV_Sum[4]+=(int)gtSysState.sPump[i];
                  giPV_Sum[5]+=(int)gtSysState.sSV1[i];
                  
                 // giPV_Sum[6]+=(int)gtSysState.sPV1[i]; 
                  giPV_Sum[7]+=(int)gtSysState.sPV_Rech[i];
                  //giPV_Sum[8]+=(int)gtSysState.sFS3[i];
                  giPV_Sum[9]+=(int)gtSysState.sFS_Rech[i]; 
                  giPV_Sum[10]+=(int)gtSysState.sOut_FS2[i];
                  
                  giPV_Sum[11]+=(int)gtSysState.sOutO2[i];
                  giPV_Sum[12]+=(int)gtSysState.sOutCH4[i];
                  giPV_Sum[13]+=(int)gtSysState.sOutPS2[i]; 
                }
                
                gtSysState.sInO2[j] = (short)(giPV_Sum[0]/TREND_X_ZOOM_OUT);
                gtSysState.sInCH4[j] = (short)(giPV_Sum[1]/TREND_X_ZOOM_OUT);           
                gtSysState.sInFS1[j] = (short)(giPV_Sum[2]/TREND_X_ZOOM_OUT);
         
                gtSysState.sInPS1[j] = (short)(giPV_Sum[3]/TREND_X_ZOOM_OUT);
                gtSysState.sPump[j] = (short)(giPV_Sum[4]/TREND_X_ZOOM_OUT);
              
                gtSysState.sSV1[j] = (short)(giPV_Sum[5]/TREND_X_ZOOM_OUT);
                //gtSysState.sPV1[j] =(short)(giPV_Sum[6]/60);
                gtSysState.sPV_Rech[j] = (short)(giPV_Sum[7]/TREND_X_ZOOM_OUT);
          
                //gtSysState.sFS3[j] = (short)(giPV_Sum[8]/60);
                gtSysState.sFS_Rech[j] = (short)(giPV_Sum[9]/TREND_X_ZOOM_OUT);
                gtSysState.sOut_FS2[j] = (short)(giPV_Sum[10]/TREND_X_ZOOM_OUT);
          
                gtSysState.sOutO2[j] =(short)(giPV_Sum[11]/TREND_X_ZOOM_OUT);
                gtSysState.sOutCH4[j] = (short)(giPV_Sum[12]/TREND_X_ZOOM_OUT);
                gtSysState.sOutPS2[j] =(short)(giPV_Sum[13]/TREND_X_ZOOM_OUT);
              }              
              gtSysState.sCurrentPV_Point = j-1;
              si = j;
              gtSysState.sTrendDataInMinute = 1;
              
              //refreshTrendScreen();
              if(gucScrnNo==cstScrnTrend) 
                gucScreen_Shadow = cstScrnUndefined; // Force to refresh Trend screen
              // Clear Summing Buffers after being used in this section
              for(i = 0; i < 14; i++)
              {
                giPV_Sum[i] = 0;
              }
            }
            else
            {
              //shift the data from MAX_PV_NUM to PV_RESTART
              j = MAX_PV_NUM - PV_RESTART_POINT;
              for(i = 0; i < PV_RESTART_POINT; i++)
              {
                gtSysState.sInO2[i] = gtSysState.sInO2[i+j];
                gtSysState.sInCH4[i] = gtSysState.sInCH4[i+j];           
                gtSysState.sInFS1[i] = gtSysState.sInFS1[i+j];
         
                gtSysState.sInPS1[i] = gtSysState.sInPS1[i+j];
                gtSysState.sPump[i] = gtSysState.sPump[i+j];
              
                gtSysState.sSV1[i] = gtSysState.sSV1[i+j];
                //gtSysState.sPV1[i] = gtSysState.sPV1[i+j];
                gtSysState.sPV_Rech[i] = gtSysState.sPV_Rech[i+j];
          
                //gtSysState.sFS3[i] = gtSysState.sFS3[i+j];
                gtSysState.sFS_Rech[i] = gtSysState.sFS_Rech[i+j];
                gtSysState.sOut_FS2[i] = gtSysState.sOut_FS2[i+j];
          
                gtSysState.sOutO2[i] = gtSysState.sOutO2[i+j];
                gtSysState.sOutCH4[i] = gtSysState.sOutCH4[i+j];
                gtSysState.sOutPS2[i] = gtSysState.sOutPS2[i+j];          
              }   
            
              gtSysState.sCurrentPV_Point = PV_RESTART_POINT-1;
              si = PV_RESTART_POINT;
              //refreshTrendScreen();
              if(gucScrnNo==cstScrnTrend)  // only in Trend screeen
                gucScreen_Shadow = cstScrnUndefined; // Force to refresh Trend screen 
            }
          }
          gtSysState.sPV_NextIndex = si;
          
          //update Screen Request to 25mS Task
          gucUpdateScreenReg = 1;  
          
          // Set The output based on 
          // gtSysControl.sPump;
          // gtSysControl.sSV_Exhaust; 
          // gtSysControl.sPV_Recharge;   
          Set_Pump_PWM(gtSysControl.sPump);
          if (gtSysControl.sSV_Exhaust == 0)        
            TurnOffExhaustSV1;
          else
            TurnOnExhaustSV1;
          Set_V1_Refill_PWM(gtSysControl.sPV_Recharge);
        }
        // end of 1000mS Task
      
    }      
        

}

void systick_setup(uint32_t sys_freq) 
{
    //SysTick->LOAD = (sys_freq / 1000U) - 1U; //1ms tick
    SysTick->LOAD = (sys_freq / 10000U) - 1U; //0.1ms tick
    //SysTick->LOAD = (sys_freq / 20000U) - 1U; //0.056s tick
    SysTick->VAL = 0x00; //explicitly set start value (undefined on reset)
    SysTick->CTRL |= (1U << SysTick_CTRL_TICKINT_Pos) | (1U << SysTick_CTRL_CLKSOURCE_Pos); //enable systick interrupt, source processor clock
    SCB->SHP[8] = 5U; //set SysTick interrupt priority (default: 0, the highest)  // set to level 5 Lower than EXTI
  
    SysTick->CTRL |= (1U << SysTick_CTRL_ENABLE_Pos); //enable SysTick
    
    
}


#ifdef  USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  while (1)
  {}
}

#endif

/**
  * @}
  */ 

/**
  * @}
  */ 

/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
