/*************************************************************************
 *
 *    Used with ICCARM and AARM.
 *
 **************************************************************************/


#ifndef  __DRV_CFAF320240F_H
#define  __DRV_CFAF320240F__H

#define LCD_LIGHT                 GPIO_Pin_11
#define LCD_LIGHT_PORT            GPIOD


#define LCD_RST                   GPIO_Pin_10
#define LCD_CS                    GPIO_Pin_12
#define LCD_RST                   GPIO_Pin_10
#define LCD_CD                    GPIO_Pin_14



#define EscKeyHoldingDown ((GPIOE->IDR & GPIO_Pin_0) == 0)
#define UpKeyHoldingDown ((GPIOE->IDR & GPIO_Pin_1) == 0)
#define DownKeyHoldingDown ((GPIOE->IDR & GPIO_Pin_2) == 0)
#define EnterKeyHoldingDown ((GPIOE->IDR & GPIO_Pin_3) == 0)
#define StartButtonPressed ((GPIOE->IDR & GPIO_Pin_14) != 0)

#define PowerOnSwitchClosed ((GPIOD->IDR & GPIO_Pin_3) != 0)
#define PumpOnSwitchClosed ((GPIOD->IDR & GPIO_Pin_2) != 0)

#define PushbuttonPressed ((GPIOD->IDR & GPIO_Pin_4) == 0)  //



#define LCD_LIGHT_ON()            GPIO_WriteBit(LCD_LIGHT_PORT,LCD_LIGHT,Bit_SET)
#define LCD_LIGHT_OFF()           GPIO_WriteBit(LCD_LIGHT_PORT,LCD_LIGHT,Bit_RESET)

#define Set_RES_H()               GPIO_WriteBit(GPIOD,LCD_RST,Bit_SET)
#define Set_RES_L()               GPIO_WriteBit(GPIOD,LCD_RST,Bit_RESET)

#define Set_LCD_CS_H()               GPIO_WriteBit(GPIOB,LCD_CS,Bit_SET)
#define Set_LCD_CS_L()               GPIO_WriteBit(GPIOB,LCD_CS,Bit_RESET)

#define Set_LCD_CD_H_Data()               GPIO_WriteBit(GPIOB,LCD_CD,Bit_SET)
#define Set_LCD_CD_L_Cmd()               GPIO_WriteBit(GPIOB,LCD_CD,Bit_RESET)


#define TURN_ON_RED_LED           GPIO_WriteBit(GPIOD,GPIO_Pin_3,Bit_RESET)
#define TURN_OFF_RED_LED             GPIO_WriteBit(GPIOD,GPIO_Pin_3,Bit_SET)

#define TURN_ON_GRN_LED               GPIO_WriteBit(GPIOD,GPIO_Pin_2,Bit_RESET)
#define TURN_OFF_GRN_LED             GPIO_WriteBit(GPIOD,GPIO_Pin_2,Bit_SET)


#define colorRED  0xf800
#define colorGREEN  0x07e0
#define colorBLUE  0x001f
#define colorPINK  0xf81f      //RED + BLUE
#define colorYELLOW  0xffe0   // RED + GREEN
#define colorBROWN  0xfc00     // RED + HALF GREEN
#define colorSEABLUE  0xffe0    // GREEN + BLUE
#define colorGRAY  0x8410    // Half RED + Half Green + Half BLUE
//#define colorGRAY  0x31e6
#define colorWHITE  0xffff
#define colorBLACK  0x0

// color definitions
#define	BLACK	  0x0000
#define	BLUE	  0x001F
#define	RED 	  0xF800
#define	GREEN   0x07E0
#define CYAN	  0x07FF
#define MAGENTA 0xF81F
#define YELLOW  0xFFE0
#define WHITE	  0xFFFF
   
/* Definition for DMAx resources */
#define SPI_PORT_DR_ADDRESS                SPI2->DR

#define SPI_PORT_DMA                       DMA1
#define SPI_PORT_DMAx_CLK                  RCC_AHB1Periph_DMA1

#define SPI_PORT_TX_DMA_CHANNEL            DMA_Channel_0
#define SPI_PORT_TX_DMA_STREAM             DMA1_Stream4
#define SPI_PORT_TX_DMA_FLAG_FEIF          DMA_FLAG_FEIF4
#define SPI_PORT_TX_DMA_FLAG_DMEIF         DMA_FLAG_DMEIF4
#define SPI_PORT_TX_DMA_FLAG_TEIF          DMA_FLAG_TEIF4
#define SPI_PORT_TX_DMA_FLAG_HTIF          DMA_FLAG_HTIF4
#define SPI_PORT_TX_DMA_FLAG_TCIF          DMA_FLAG_TCIF4

#define SPI_PORT_DMA_TX_IRQn               DMA1_Stream4_IRQn
#define SPI_PORT_DMA_TX_IRQHandler         DMA1_Stream4_IRQHandler


//
//typedef struct
//{
//  int iValidDataFlag;
//  int iHighAlarmSetting;
//  int iWarningSetting;
//  int iEngineeringUnit;
//  int iBackGroundCPSDet0;
//  int iBackGroundCPSDet1;
//  int iBackGroundCPSDet2;
//  int iBackGroundCPSDet3;
//  int iBackGroundCPSDet4;
//  int iBackGroundCPSDet5;
//  int iBackGroundCPSDet6;
//  int iBackGroundCPSDet7;
//  int iPassword;
//  int iChamberTempSet;
//  int iFlowCalibrationFactor;
//  int iOperatorPassword;
//  int iCompensationInPressureCalFactor;
//  int iMotorSpeed;
//  int iHumditySwitchAlarmSetting;
//  int iDataLogPeriodInSec;   
//  int iCompChamberOffsetCnt;
//  int iSpare1;
//  int iPanelAddress;  
//} SETTING_TypeDef;
//  

typedef struct
{
  int iValidDataFlag;
  int iFlowLowAlarmSetting;  // The Inlet flow from Whole Body Monitor is low to detectPin Hole in WBM
  int iOutFlowO2LevelAlarmSetting;  // The level
   
  int iZero[10];
  int iUpScale[10];
  int iRange[10];
   
  int iPassword;
  int iCH4_FlowSetting;
  int iStartRecoveryO2Level;
  int iPumpBaseSetting;
  int iPumpModifier;
  int iSpare0;
  int iPanelAddress;  
} SETTING_TypeDef;



typedef struct
{
  int iNewTouchButton;
  int iTouchPressed;
  int iTouchReleased;
  int iTouchRleaseTimeOutTenthMsCnt;  
} TouchStatusDef;


void refreshMainScreen(void);
void refreshTrendScreen(void);
void refreshSetupScreen(void);

void updateMainScreen(void);
void updateTrendScreen(void);
void updateSetupScreen(void);
void showBatteryInMainScreen(unsigned short usBackColor);

void refreshLogInWindow(unsigned char *ptrTitleStr, unsigned char *ptrHelpMessage);

void printLongLetterButton(unsigned char *ptrStr, unsigned short usLeft, unsigned short usTop, unsigned short usFrontColor, unsigned short usBackColor);
void printLetterButton(unsigned char *ptrStr, unsigned short usLeft, unsigned short usTop, unsigned short usButtonLength, unsigned short usBackColor);
void printNumButton(unsigned char ucNum, unsigned short usLeft, unsigned short usTop, unsigned short usLetterOffset, unsigned short usBackColor);
void indicateNumButtonState(unsigned char ucNum, unsigned short usLeft, unsigned short usTop, unsigned short usLetterOffset, unsigned short usBackColor);

void increaseTrendIndex(void);
void addTrendData(void);
void updateDataInSetupScreen(void);

//int dispEngineeringUnit(unsigned short usX, unsigned short usY,unsigned short usFrontColor,unsigned short usBackColor);
//int dispEngineeringUnitSelection(unsigned short usX, unsigned short usY,unsigned short usFrontColor,unsigned short usBackColor);
void convertIntHourMinute(int iTemp, unsigned char *pStr);
   
void SPI2_DMA_Config(void);



void initLCD(void);

void clearScreen(int iLeft, int iTop, int iRight,int iBottom, unsigned short iFillColor);

void sendSPI_Data(unsigned char Data_SPI);

void write_command(unsigned short CMDData_SPI);
void write_data(unsigned short Data_SPI);

void writeOneGRAMdata(unsigned short Data_SPI);

void writeGRAMData(unsigned short usStartFromRightX_Pos, unsigned short usStartFromTopY_Pos, unsigned short NumPoint);
int outXYColor(int left, int top, int font, unsigned char *strToBeDispAddr, unsigned short frontColor,unsigned short bkColor);
int outXYColorFast(int left, int top, int font, unsigned char *strToBeDispAddr,unsigned short frontColor,unsigned short bkColor);
int outXYColorWithScale(int left, int top, int font, unsigned char *strToBeDispAddr, unsigned short frontColor,unsigned short bkColor, unsigned short iXScale, unsigned short iYScale);
void generateTrendArray(void);

void Display_Home();
void LCD_test();
void clrLCDScrn(unsigned short usBKColor);
void drawVertLine(unsigned short usStartX,unsigned short usStartY, unsigned char uLength, unsigned short usColor);

void updateTrend(int iTrendSection);
void updateIMSStatusScreen(void);
void updateRGSStatusScreen(void);
void updateMenuScreen(void);
void drawFrameScanScreen(void);
void drawFrameZoomedScanScreen(void);
void drawFrameMenuScreen(void);
void drawFrameRGSStatusScreen(void);

void findMaxMin(void);

void drawVert2SectionLine(unsigned short usStartX,unsigned short usStartY, unsigned char uTopSectionLength, unsigned char uBotSectionLength, unsigned short usTopColor, unsigned short usBotColor);

void drawProgressBar(unsigned short usStartX,unsigned short usStartY, unsigned short usWidth, unsigned char uTopSectionLength, unsigned char uBotSectionLength, unsigned short usTopColor, unsigned short usBotColor);

void drawEllipse(unsigned short usX, unsigned short usY, unsigned short usA, unsigned short usB, unsigned short usBackColor,unsigned short usLineColor, unsigned short usFillColor, unsigned short usFill_Reqed, unsigned short usThickerLine);
//usLeftX,usTopY, Length usA, Height usB
void drawRectangle(unsigned short usLeftX, unsigned short usTopY, unsigned short usA, unsigned short usB, unsigned short usBackColor,unsigned short usLineColor, unsigned short usFillColor, unsigned short usFill_Reqed, unsigned short usThickerLine);
void drawVerticalValve(unsigned short usLeftX, unsigned short usTopY, unsigned short usA, unsigned short usB, unsigned short usBackColor,unsigned short usLineColor, unsigned short usFillColor, unsigned short usFill_Reqed, unsigned short usThickerLine);

void drawLine(unsigned short usStartX, unsigned short usStartY, unsigned short usEndX, unsigned short usEndY, unsigned short usLineColor, unsigned short usBackColor);

void drawPropValve(unsigned short usVlvX, unsigned short usVlvY, unsigned short usBackColor,unsigned short usLineColor, unsigned short usFillColor, unsigned short usFill_Reqed);
void drawPropValve_Left(unsigned short usVlvX, unsigned short usVlvY, unsigned short usBackColor,unsigned short usLineColor, unsigned short usFillColor, unsigned short usFill_Reqed);

void drawHorizArrow(unsigned short usStartX,unsigned short usEndX, unsigned short usY, unsigned short usBackColor,unsigned short usLineColor);

// Fixed for 3 pixel thinkless
void drawVertArrow(unsigned short usX,unsigned short usStartY, unsigned short usEndY, unsigned short usBackColor,unsigned short usLineColor);
  

void processKeyInMainScreen(void);

void Dly100us(void *arg);

// Mode 0 - no . "1234" will be converted into 1234
// Mode 1 - 1.2   "1.2" will be converted into 12
// Mode 2 - 1.002 "1.002 will be converted into 1002
int convertStrToInt(unsigned char *pStr, unsigned char Mode);

// Note: the input range has to be - 999 to 9999
void convertIntToStrNoLeadingZero(int iTemp, unsigned char *pStr);

// Note: the input range has to be - 999 to 199,999
void convertIntToStrNoLeadingZero6(int iTemp, unsigned char *pStr);

// Note: the input range has to be - 99,999 to 9,999,999
void convertIntToStrNoLeadingZero7(int iTemp, unsigned char *pStr);
void clrRectBox32(int iX, int iY, int iLen, unsigned short uscolorCode);
void clrRectBox(int iX, int iY, int iLen, int iWidth, unsigned short uscolorCode);

// Note: the input range has to be 0 to 999,999: eg 1 will be 0.001
void convertIntToFloatStrNoLeadingZero(int iTemp, unsigned char *pStr);

// Note: The input range has to be 0 to -9,999 to 99,999 ;  eg 1 will be 0.1,
//       So output range will be -999.9 to 9999.9
void convertIntToOneDecStrNoLeadingZero(int iTemp, unsigned char *pStr);
void convertIntToTwoDecStrNoLeadingZero(int iTemp, unsigned char *pStr);

// Note: The input range has to be 0 to -9,999 to 99,999 ;  eg 1 will be 0.1,
//       So output range will be -999.9 to 9999.9
void convertIntToOneDecStrNoLeadingZero7(int iTemp, unsigned char *pStr);

void convertIntToStrNoLeadingZero10(unsigned int iTemp, unsigned char *pStr, int iDecimalPoint);

void convertIntTo4Dig(int iTemp, unsigned char *pStr);

void convertT_SpareGammaReadingToLedSegCode(void);

void playMusic(void);
void SoundControl(unsigned char ucON, unsigned short usFreqData);
void ClearWindow(unsigned short usLeftX, unsigned short usTopY, unsigned short usRightX, unsigned short usBottomY, unsigned short usColor);

#endif  /* __DRV_HD44780_L_H */
