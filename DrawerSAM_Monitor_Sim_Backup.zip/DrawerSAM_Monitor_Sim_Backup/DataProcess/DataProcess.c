/******************** (C) COPYRIGHT 2007 STMicroelectronics ********************
* File Name          : usart.c
* Author             : MCD Application Team
* Version            : V1.0
* Date               : 10/10/2007
* Description        : This file provides USART firmware functions
********************************************************************************
* THE PRESENT SOFTWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
* AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
* CONTENT OF SUCH SOFTWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*******************************************************************************/

//* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"
#include "DataProcess.h"
#include "usart.h"
#include "LCDControl_l.h"







unsigned short gusCycleTimeCnt;
// call every 100mS by Interrupt TIM8

int giStartCycleFlag;




//SubstanceTypeDef structSubstance[20];  //20




unsigned char calculateCheckSumForNumByte(unsigned char *ucPTR, int iNumberOfByte)
{
  int i;
  unsigned char ucTemp;
  ucTemp = 0;
  for(i = 0; i < iNumberOfByte; i++)
     ucTemp = ucTemp + ucPTR[i];
  
  return ucTemp;
    
}



extern unsigned char gucU2TXDData[]; //gucU2OutputArray[];

extern structDataRequestByHMI_TypeDef gstructDataRequestByHMI;
extern unsigned int guiInputData;
extern SETTING_TypeDef gstructParameter;



extern unsigned char gucCommandReceivedFromRemote[];

 void startDev1(void)
 {
   
 }
 
 void stopDev1(void)
 {
  
 }
     
 void startDev2(void)
 {
   
 
 }
 
 void stopDev2(void)
 {
   
 }
     
 void startSamplePump(void)  
 {
   
 }     
  

void EnergizedExaustValve(void)
{
   
}
//
//void De_energizedExaustValve(void)
//{
//   //gucRGSDeviceCommand_L &= ~0x2;
//   //giRGSDeviceControlReq = 1; 
//}
//
//void startExcitePump(void)
// {
//   //gucRGSDeviceCommand_L |= 0x4;
//   //giRGSDeviceControlReq = 1;   
// }
// 
// void stopExcitePump(void)
// {
//   //gucRGSDeviceCommand_L &= ~0x4;
//   //giRGSDeviceControlReq = 1;   
// }


int    gidubug, giDeBugMonitorEnabled;  
extern int giInZoomedMode;

int giTestTemp;                     


void clearCycle(void)
{

}  

#define RIP_SEARCH_START_uS 3000  // 3ms
#define RIP_SEARCH_END_uS 4200  // 4ms

#define RIN_SEARCH_START_uS 4500  // 4.0ms
#define RIN_SEARCH_END_uS 6000  // 6ms

#define RIN_Ko 1.752
#define RIP_Ko 2.536
#define ChannelScanInterval 375  //12.5*15*2  mS


  
/******************* (C) COPYRIGHT 2007 STMicroelectronics *****END OF FILE****/
