/******************** (C) COPYRIGHT 2007 STMicroelectronics ********************
* File Name          : usart.h
* Author             : MCD Application Team
* Version            : V1.0
* Date               : 10/10/2007
* Description        : This file contains all the functions prototypes for the
*                      USART firmware library
********************************************************************************
* THE PRESENT SOFTWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
* AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
* CONTENT OF SUCH SOFTWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*******************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __DATA_PROCESS_H
#define __DATA_PROCESS_H


#define EnableRS485Rx()            GPIO_WriteBit(GPIOB,GPIO_Pin_11,Bit_RESET)
#define DisableRS485Rx()           GPIO_WriteBit(GPIOB,GPIO_Pin_11,Bit_SET)

#define EnableRS485Tx()           GPIO_WriteBit(GPIOA,GPIO_Pin_8,Bit_SET)
#define DisableRS485Tx()          GPIO_WriteBit(GPIOA,GPIO_Pin_8,Bit_RESET)

#define En_U1_RS485_Transmitter      GPIO_WriteBit(GPIOA,GPIO_Pin_11,Bit_SET)
#define Dis_U1_RS485_Transmitter     GPIO_WriteBit(GPIOA,GPIO_Pin_11,Bit_RESET)

#define Set_WTD_Hi      GPIO_WriteBit(GPIOB,GPIO_Pin_12,Bit_SET)
#define Set_WTD_Low     GPIO_WriteBit(GPIOB,GPIO_Pin_12,Bit_RESET)

#define En_MOTOR        GPIO_WriteBit(GPIOC,GPIO_Pin_4,Bit_SET)
#define Dis_MOTOR       GPIO_WriteBit(GPIOC,GPIO_Pin_4,Bit_RESET)

#define Set_Motor_A_Positive       GPIO_WriteBit(GPIOC,GPIO_Pin_0,Bit_SET)
#define Clr_Motor_A_Positive       GPIO_WriteBit(GPIOC,GPIO_Pin_0,Bit_RESET)

#define Set_Motor_A_Neg       GPIO_WriteBit(GPIOC,GPIO_Pin_1,Bit_SET)
#define Clr_Motor_A_Neg       GPIO_WriteBit(GPIOC,GPIO_Pin_1,Bit_RESET)

#define Set_Motor_B_Positive       GPIO_WriteBit(GPIOC,GPIO_Pin_2,Bit_SET)
#define Clr_Motor_B_Positive       GPIO_WriteBit(GPIOC,GPIO_Pin_2,Bit_RESET)

#define Set_Motor_B_Neg       GPIO_WriteBit(GPIOC,GPIO_Pin_3,Bit_SET)
#define Clr_Motor_B_Neg       GPIO_WriteBit(GPIOC,GPIO_Pin_3,Bit_RESET)

#define PushButtonStopPressed ((GPIOD->IDR & GPIO_Pin_1) != 0)
#define PushButtonStopNotPressed ((GPIOD->IDR & GPIO_Pin_1) == 0)
#define PushButtonStartPressed ((GPIOD->IDR & GPIO_Pin_0) != 0)

#define SWITCH_IN_IDLE ((GPIOD->IDR & GPIO_Pin_14) != 0)        // RECHARGE VALVE CLOSED
#define SWITCH_IN_PURGE ((GPIOD->IDR & GPIO_Pin_15) != 0)      // PUMP IS OFF, 40mL/M in RECHARGE 
#define SWITCH_IN_RECIR ((GPIOD->IDR & GPIO_Pin_0) != 0)      // AUTO CIRCULATE MODE, <40mL/M in RECHARGE
#define SWITCH_IN_SETUP ((GPIOD->IDR & GPIO_Pin_1) != 0)      // SETUP MOde



#define LimitSwitchLoadingClosed ((GPIOA->IDR & GPIO_Pin_11) != 0)
#define LimitSwitchHomeClosed ((GPIOA->IDR & GPIO_Pin_12) != 0)


#define MOTOR_REACH_HOME ((gstructStepMotorControl.ucLimitSwitchLocationReached & 0x1) != 0)
#define MOTOR_REACH_LOADING  ((gstructStepMotorControl.ucLimitSwitchLocationReached & 0x2) != 0)

#define MOTOR_TRAVEL_TOTAL_LENGTH_IN_CYCLE  26118//1301 // Cycles

typedef enum E_SYS_MODE {E_IDLE, E_PURGE, E_AUTO_CIRCULATE, E_SETUP} T_SYS_MODE;

#define cstScrnUndefined     0
#define cstScrnMain     1
#define cstScrnTrend    2
#define cstScrnSetup    3
#define cstScrnStatus   4


union unInt_To4Bytes 
{
     int iIntData;
     unsigned char ucByte[4];      
};

union ssShort_To2Bytes 
{
     signed short ssData;
     unsigned char ucByte[2];      
};

union usShort_To2Bytes 
{
     unsigned short usData;
     unsigned char ucByte[2];      
};


typedef struct
{

  unsigned char ucStart;                // 1 Start , 0 - Stop
  unsigned char ucFORWARDDIR;          //  1 Forward , 0 - BackWard
  unsigned char ucStep;                 // Step Number
  unsigned char ucInHalfStepMode;       //  1 HalfStep , 0 - Full Step
  unsigned char uncSpeedSetting;        // from 1- to 10, 10 is the highest
  int iCycleCnt;
  unsigned char ucLimitSwitchLocationReached; // Bit0  - Reached Home, Bit 1 - Reached LOading
  int iTimeInMotion;                  // Track how many seconds in Motion
                               
} StepMotorTypeDef;

typedef struct
{
  //unsigned int uiCPS;
  int uiCPS;
  //unsigned int uiMaxCPS;
  int uiMaxCPS;
  unsigned char ucAlarm;                // Bit 0 Radiation Level H , Bit 1  - Radiation Level HH
  unsigned char ucWarning;             // Bit 0  Low Alarm , Bit 1 HV low alarm
  unsigned char ucAlarmWarningAcknoledged;
  unsigned char ucZeroCPSCnt;
                               
} DetectorTypeDef;


typedef struct
{
  unsigned char ucFrameStartPulse;//[0]
  unsigned char ucResponseBits1, ucResponseBits2;   //3 byte;  Bits1 D7 - Pressure Compensation Enabled, D6 to D0 for Pump speed
  unsigned char ucYear,ucMonth,ucDay,ucHour,ucMinute,ucSecond;   //[8] 9 Bytes
  unsigned char ucStatusFlag;  // Bit0(D0) -  Pump is On, Bit1(D1)- In Background cancellation processing
  unsigned char ucAlarmWarningFlag; // Bit0 -T_Spare, Bit1- Gamma, Bit2 -Flow   // [10] 11Bytes
  int iT_SpareInTenth;
  int iGammaInTenth;
  int iUnitId;
  int iMeasureCnt1;
  int iMeasureCnt2;
  int iCompCnt1;
  int iCompCnt2;
  int iOffset;
  int iGammaCnt;                                                               //[46] 47Byte
  signed short ssBodyTemp;
  signed short ssBatTemp;
  signed short ssMeasRH;
  signed short ssCompRH;
  signed short ssHVVolt;
  signed short ssElectroVolt;
  signed short ssPowerVolt;
  signed short ssDrierAlarmSetting;//ssDischargeA;
  signed short ssLogInterval;                                                      //65 Bytes
  int iMiKpa;
  int iCiKpa;
  unsigned short usDpKpa;                                                       //75 Bytes
  signed short ssFlow;                                                         //77 Bytes
  int iCompBkg;                                                                 //81 Bytes
  signed short ssBodyTempSetting; //83 Bytes
  int iT_SpareAlarmLevel;    
  int iGammaAlarmLevel;   
  unsigned short usT_SpareGain;               //93 Bytes             
  unsigned short usGammaGain;
  unsigned short usMeaPressCalFactor;
  unsigned short usCompPressCalFactor;
  unsigned short usFlowCalFactor;     //101                      
  unsigned char ucCheckSum;        //102 Bytes 
} structDataResponseByT_SpareProcessor_TypeDef;



typedef struct
{
  unsigned char ucFrameStartPulse;
  unsigned char ucRequestBits1, ucRequestBits2;
  unsigned char ucNewYear,ucNewMonth,ucNewDay,ucNewHour,ucNewMinute,ucNewSecond;   // 9 Bytes
  int iNewOffset;
  int iNewUnitID;
  int iNewT_SpareAlarmLevel;
  int iNewGammaAlarmLevel;
  int iNewT_SpareAlarmLevelGain;
  int iNewGammaGain;
  int iNewPressureKpa;
  int iNewFlowRate;                                         // 41 Bytes
  signed short ssNewBodyTempSetting;
  signed short ssNewHumSetting;
  signed short ssNewDataLoggingInterval;                    // 47 Bytes
  unsigned char ucPumpSpeed;
  unsigned char ucPressureCompensation;                     // 50 Bytes
  int iSpare1;
  int iSpare2;                                              // 57 Bytes
  unsigned char ucCheckSum;                                 // 58 Bytes
} structDataRequestByHMI_TypeDef;




typedef struct
{
     float fPeakSearchStartmS;
     float fPeakSearchEndmS;

     int iPeakThreshold;
     int iRisingEdgePointsMin;
     int  iRisingEdgePointsMax;  // It may be more than 30 since the gaussian shape- start rising slowly

     int iFallingEdgePointsMin;
     int iFallingEdgePointsMax;

     float fFallingToRisingHeightRatioMin;
     float fFallingToRisingHeightRatioMax;
     float fPulseWidthmS_Min;
     float fPulseWidthmS_Max;
}PeakSearchSettingTypeDef;


typedef struct
{
     float fPeakKo;
     int iPeakWindow;
     int iPeakInNegPolarity;     
     int iAmpThreshold;
     int iStartDetection_mS;
     int iStopDetection_mS; 
     int iPeakOccur_mS_Min;
     int iPeakOccur_IsContinue;   // 1 continue, 0 any time
     int iIsMust;    // 1 Must, 0 Option
     

     int iPeakMatchedCnt; 
     int iPeakAmp_Max;
     int iPeakMaxPosition;
     int iPeakMaxKo;                    //???
     int iScanCompleted;
     int iFound;
}ChannelTypeDef;

typedef struct
{
    unsigned char sName[100];
    int iSearchChannelTotalCnt;
    int iSearchChannelID[10];
    
    int iMainPeakPosition;
    int iMainPeakKo;                     //????
    int iMainPeakStrength;
    int iChannelMatchedCnt ; 
    int iFound;
}SubstanceTypeDef;

typedef struct
{   
    int iCycleTimeTotal_mS;
    int iSearchSubstanceCnt;
    
    int iDev1_Parameter[5];
    
    int iDev2_Parameter[5];
      
    int iDev3_Parameter[5];
    
    int iDev4_Parameter[5];
    
    int iDev5_Parameter[5];
    
    int iDone;
}CycleTypeDef;

//
//typedef struct
//{
//  unsigned char ucFirstScan;
//  unsigned char ucSysMode;  //  0-  Startup (Idle), 1 - Scan mode , 2 - Setup mode
//  unsigned char ucMotor_StateMachine;  //  0-  idle 1- Move to loading Position, 2- Move to Home position, 
//  
//} SYS_CONTROL_TypeDef;

#define MODE_IDLE   0
#define MODE_SCAN   1
//#define MODE_SETUP  2

//#define MOTOR_STATE_IDLE        0
//#define MOTOR_STATE_TO_LOADING  1
//#define MOTOR_STATE_TO_HOME     2

//typedef struct
//{
//  unsigned char ucSysState;  //  0 - Idle, 1 - In scanning, 2- In steup mode,  
//  unsigned char ucMotorStatus;  // 0 - Idle, 1 - at loading position, 2- at home position
//  unsigned char ucButtonStatus_Saved; // Bit 0 Start Button Pressed, Bit 1 - STop Button Pressed 
//  unsigned char ucScanningSteps; // count from 10 (Ready at Loading Position) to 5  ( Home) , - 0 ( Back to READY
//  
//} SYS_STATUS_TypeDef;

#define O2_LEVEL_LOW_TIME_REQUIRED  30  // 30 second

#define AUTO_RECOVERY_IN_PURGE                                  0   // Transition to Next (1)  when InO2 is lower than the setting for O2_LEVEL_LOW_TIME_REQUIRED and same time get average of  ReturnedFlow
#define AUTO_RECOVERY_PRESET_RECHARGE_FLOW                      1   // Set the Recharge Flow to Total Flow - ReturnedFlow + 2 when flow close to the setting for 5 seconds,  fixed PV1 setting to PV1Preset, then to Next
#define AUTO_RECOVERY_CLOSE_EXHAUST_SET_PUMP_SPEED              2  // close EXhaust and same time turn on the pump, until Return flow close to ReturnedFlow for 5 seconds, Fixed PumpSetting
#define AUTO_RECOVERY_NORMAL                                    3  // Set PV1 in PID mode,  Target for OutCH4Setting (40ml/M)


#define MAX_PV_NUM  720
#define PV_RESTART_POINT MAX_PV_NUM*5/6  // Restart at 50 minute
typedef struct
{
  //unsigned char ucSysState;  //  0 - Idle, 1 - Purge, 2- Normal,  Setup 
  T_SYS_MODE ucSysState;
  short sTrendDataInMinute;      // 0 - every second, 1 Every Minute
  short sCurrentPV_Point;                    // Data saved 
  short sPV_NextIndex;                     // from 0 to MAX_PV_NUM-1,
 
  short sInO2[MAX_PV_NUM];                    // O2 in unit of 0.1%
  short sInCH4[MAX_PV_NUM];                    //CH4 in unit of 0.1%
  short sInFS1[MAX_PV_NUM];                    // O2 in unit of 0.1%
  short sInPS1[MAX_PV_NUM];  
  
  short sPump[MAX_PV_NUM];                    // Pump PWM in unit of 0.1%
  short sSV1[MAX_PV_NUM];                    //SV1 , 0- OFF, 1 ON
 //short sPV1[MAX_PV_NUM];                    // Proportional Valve  in unit of 0.1%
 //short sFS3[MAX_PV_NUM];
    
  short sFS_Rech[MAX_PV_NUM];                    // Pump PWM in unit of 0.1%
  short sPV_Rech[MAX_PV_NUM];                    //SV1 , 0- OFF, 1 ON
  short sOut_FS2[MAX_PV_NUM];                    // Proportional Valve  in unit of 0.1%
  short sOutO2[MAX_PV_NUM];                    // O2 in unit of 0.1%
  short sOutCH4[MAX_PV_NUM];                    //CH4 in unit of 0.1%              
  short sOutPS2[MAX_PV_NUM];  
  
} SysStateTypeDef;

typedef struct
{
  short sPump;                          // Pump PWM in unit of 0.1%
  short sSV_Exhaust;                    //SV1 , 0- OFF, 1 ON
  short sPV_Recharge;                   // Proportional Valve  in unit of 0.1%
  
  short sReturnedFlowSearchCnt;                // Returned flow serach Count;
  
  short sDelayTimer;                          // General delay timer for step sleep function
    
  short sAutoRecoveryStateM; 
  
  float fReturnFlow;                    // in unit of 0.1mL/M
  //float fPV1_Preset;                    // in unit of 0.1%
  //float fPumpFixedSpeed                 // in Unit of 0.1%
  
} SysControlTypeDef;

#define SYS_IDLE   0
#define SYS_SCAN   1
#define SYS_STS_SETUP  2

#define MTR_IDLE   0
#define MTR_REACHED_LOADING   1
#define MTR_REACHED_HOME  2



 void startDev1(void);
 void stopDev1(void);
 void startDev2(void);
 void stopDev2(void);
 void startSamplePump(void);
 
void EnergizedExaustValve(void);
//void De_energizedExaustValve(void);

//void startExcitePump(void);
 
//void stopExcitePump(void);







//void loadCycleDefaultSetting(void);

void clearCycle(void);



//void detectSubstance(void);


unsigned char calculateCheckSumForNumByte(unsigned char *ucPTR, int iNumberOfByte);



void processU1ReceivedData(void);


         



void TouchDetection(void);

#endif /* __USART_H */

/******************* (C) COPYRIGHT 2007 STMicroelectronics *****END OF FILE****/
