/******************** (C) COPYRIGHT 2007 STMicroelectronics ********************
* File Name          : usart.h
* Author             : MCD Application Team
* Version            : V1.0
* Date               : 10/10/2007
* Description        : This file contains all the functions prototypes for the
*                      USART firmware library
********************************************************************************
* THE PRESENT SOFTWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
* AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
* CONTENT OF SUCH SOFTWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*******************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __USART_H
#define __USART_H

typedef union
{        unsigned short usData;
        unsigned char ucByte[2];
} unionUnsignedShort;


typedef union
{       int iData;
        unsigned short usData[2];        
} unionInt;


 
// Resolution 0.1 V //
// range 0 --> 1000 ---> 2000   to represent +-100.0V

void initUSART(void);
void USART_puts(unsigned char *strToBeSentAddr);
u8 USART_Scan(void);

unsigned short CRC16(unsigned char *puchMsg,unsigned short usDataLen);


//void processUART1ReceivedData(void);

void initUSART2(void);
void processUART2ReceivedData(void);


void initUSART3(void);
void processUART3ReceivedData(void);

//void filterFIR(unsigned char ucFilterPositivePlasma);

void USART1_RX_DMA_Config(unsigned char *ptrBufStartAddr, unsigned short usBufferSize);
void USART1_TX_DMA_Config(unsigned char *ptrBufStartAddr, unsigned short usBufferSize);



//USART2 RX DMA1 channel 4 and stream 5
void USART2_RX_DMA_Config(unsigned char *ptrBufStartAddr, unsigned short usBufferSize);


//USART2 TX DMA1 channel 4 and stream 6
void USART2_TX_DMA_Config(unsigned char *ptrBufStartAddr, unsigned short usBufferSize);



//USART3 RX DMA1 channel 4 and stream 1
void USART3_RX_DMA_Config(unsigned char *ptrBufStartAddr, unsigned short usBufferSize);


//USART3 TX DMA1 channel 7 and stream 4
void USART3_TX_DMA_Config(unsigned char *ptrBufStartAddr, unsigned short usBufferSize);


void processMethodData(void);

#endif /* __USART_H */

/******************* (C) COPYRIGHT 2007 STMicroelectronics *****END OF FILE****/
