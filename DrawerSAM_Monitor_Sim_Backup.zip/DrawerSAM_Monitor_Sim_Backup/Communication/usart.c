/******************** (C) COPYRIGHT 2007 STMicroelectronics ********************
* File Name          : usart.c
* Author             : MCD Application Team
* Version            : V1.0
* Date               : 10/10/2007
* Description        : This file provides USART firmware functions
********************************************************************************
* THE PRESENT SOFTWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
* AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
* CONTENT OF SUCH SOFTWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*******************************************************************************/

//* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"
#include "usart.h"
#include "Flash_WR_RD.h"
#include "DataProcess.h"


/*******************************************************************************
* Function Name  : GPIO_ConfigUSART
* Description    : Configures GPIO for USART1 using.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
extern unsigned char gucCommDataBuf0[]; // was 2500

unsigned char  gucU1TXBuf[30];  // was 3000
unsigned short gucCommandForMain_RGS_Cnt;

void initUSART(void)
{  
  
  /*
  GPIO_InitTypeDef GPIO_InitStructure;
  
  USART_InitTypeDef USART_InitStructure;  
  USART_ClockInitTypeDef USART_ClockInitStructure;
  NVIC_InitTypeDef NVIC_InitStructure;
  
 
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,ENABLE);
  
  // Configure USART1 Tx (PA.09) as alternate function push-pull
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;;//GPIO_Speed_50MHz;//GPIO_Speed_100MHz;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//GPIO_PuPd_NOPULL;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
 
  // Connect UART1 pins to AF1 
  GPIO_PinAFConfig(GPIOA, GPIO_PinSource9, GPIO_AF_USART1);  
  
  
  // Configure USART1 Rx (PA.10) as input floating 
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;;//GPIO_Speed_50MHz;//GPIO_Speed_100MHz;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
  
   // Connect UART1 pins to AF1 
  GPIO_PinAFConfig(GPIOA, GPIO_PinSource10, GPIO_AF_USART1);  
  
  
  
  USART_InitStructure.USART_BaudRate = 9600;//115200;//230400;
  USART_InitStructure.USART_WordLength = USART_WordLength_8b;
  USART_InitStructure.USART_StopBits = USART_StopBits_1;
  USART_InitStructure.USART_Parity = USART_Parity_No;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
 
  USART_Init(USART1, &USART_InitStructure);
  
   // Enable USART1 Receive interrupts 
  USART_ITConfig(USART1, USART_IT_RXNE, ENABLE); 
  
  USART_ITConfig(USART1, USART_IT_TXE, ENABLE); 
  //USART_DMACmd(USART1, USART_DMAReq_Tx, ENABLE);
  //USART_DMACmd(USART1, USART_DMAReq_Rx, ENABLE);


   Enable USART1 
  USART_Cmd(USART1, ENABLE); 
  

  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;;//GPIO_Speed_50MHz;//GPIO_Speed_100MHz;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
  
  
  gucCommDataBuf0[0] = 0xff;
  gucCommDataBuf0[1] = 0xfa;  
  gucCommDataBuf0[2] = 0xff;
  gucCommDataBuf0[3] = 0xfa;
  */
  

  
}



 

unsigned char  gucU2RXBuf[30]; // was 3000
  
void initUSART2(void)
{  
  
  
  GPIO_InitTypeDef GPIO_InitStructure;
  
  USART_InitTypeDef USART_InitStructure;  
  USART_ClockInitTypeDef USART_ClockInitStructure;
  NVIC_InitTypeDef NVIC_InitStructure;
  /* Enable ADC1, DMA2 and GPIO clocks ****************************************/  
  //RCC_AHB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);	 // 1.
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD,ENABLE); // 2.

  
  
  /* Configure USART2 Tx (D5) as alternate function push-pull */  
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;;//GPIO_Speed_50MHz;//GPIO_Speed_100MHz;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  
  GPIO_Init(GPIOD, &GPIO_InitStructure);
 
  /* Connect UART2 pins to AF1 */
  GPIO_PinAFConfig(GPIOD, GPIO_PinSource5, GPIO_AF_USART2);  
  
  
  /* Configure USART2 Rx (D6) as input floating */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF; 
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//GPIO_PuPd_NOPULL;
  GPIO_Init(GPIOD, &GPIO_InitStructure);
  
   /* Connect UART2 pins to AF1 */
  GPIO_PinAFConfig(GPIOD, GPIO_PinSource6, GPIO_AF_USART2);  
  
  
/* USART2 configuration ------------------------------------------------------*/
  /* USART1 configured as follow:
        - BaudRate = 115200 baud  
        - Word Length = 8 Bits
        - One Stop Bit
        - No parity
        - Hardware flow control disabled (RTS and CTS signals)
        - Receive and transmit enabled
        - USART Clock disabled
        - USART CPOL: Clock is active low
        - USART CPHA: Data is captured on the middle 
        - USART LastBit: The clock pulse of the last data bit is not output to 
                         the SCLK pin
  */
  
  
  USART_InitStructure.USART_BaudRate = 19200;//115200;//230400;
  USART_InitStructure.USART_WordLength = USART_WordLength_8b;
  USART_InitStructure.USART_StopBits = USART_StopBits_1;
  USART_InitStructure.USART_Parity = USART_Parity_No;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
 
  USART_Init(USART2, &USART_InitStructure);
  
 
  USART_DMACmd(USART2, USART_DMAReq_Tx, ENABLE);
  USART_DMACmd(USART2, USART_DMAReq_Rx, ENABLE);


  /* Enable USART2 */
  USART_Cmd(USART2, ENABLE); 
  

 
  
  

  
}


unsigned char  gucU3TXBuf[21];  // was 210
unsigned char  gucU3RXBuf[21];  // was 210
  
void initUSART3(void)
{  
  
  
  GPIO_InitTypeDef GPIO_InitStructure;
  
  USART_InitTypeDef USART_InitStructure;  
  USART_ClockInitTypeDef USART_ClockInitStructure;
  NVIC_InitTypeDef NVIC_InitStructure;
  /* Enable ADC1, DMA2 and GPIO clocks ****************************************/  
  //RCC_AHB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);	 // 1.
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD,ENABLE); // 2.

  
  
  /* Configure USART3 Tx (D8) as alternate function push-pull */  
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;;//GPIO_Speed_50MHz;//GPIO_Speed_100MHz;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  
  GPIO_Init(GPIOD, &GPIO_InitStructure);
 
  /* Connect UART3 pins to AF1 */
  GPIO_PinAFConfig(GPIOD, GPIO_PinSource8, GPIO_AF_USART3);  
  
  
  /* Configure USART3 Rx (D9) as input floating */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF; 
  GPIO_Init(GPIOD, &GPIO_InitStructure);
  
   /* Connect UART3 pins to AF1 */
  GPIO_PinAFConfig(GPIOD, GPIO_PinSource9, GPIO_AF_USART3);  
  
  
/* USART3 configuration ------------------------------------------------------*/
  /* USART1 configured as follow:
        - BaudRate = 115200 baud  
        - Word Length = 8 Bits
        - One Stop Bit
        - No parity
        - Hardware flow control disabled (RTS and CTS signals)
        - Receive and transmit enabled
        - USART Clock disabled
        - USART CPOL: Clock is active low
        - USART CPHA: Data is captured on the middle 
        - USART LastBit: The clock pulse of the last data bit is not output to 
                         the SCLK pin
  */
  
  
  USART_InitStructure.USART_BaudRate = 115200;//230400;
  USART_InitStructure.USART_WordLength = USART_WordLength_8b;
  USART_InitStructure.USART_StopBits = USART_StopBits_1;
  USART_InitStructure.USART_Parity = USART_Parity_No;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
 
  USART_Init(USART3, &USART_InitStructure);
  
 
  USART_DMACmd(USART3, USART_DMAReq_Tx, ENABLE);
  USART_DMACmd(USART3, USART_DMAReq_Rx, ENABLE);


  /* Enable USART2 */
  USART_Cmd(USART3, ENABLE); 
  
  
}

 
extern int giRxReceivedCnt;

extern unsigned char  gucU1TXBuf[];
void processUART2ReceivedData(void)
{ 
  unsigned short ushtTemp;
  unsigned char ucCheckSum;
  u32 uiTemp,i;
  u32 iStartAddress,iNumOfRegister;
  unionUnsignedShort unTemp;
  
  
}





int giU3ReceivedCnt;
//gucU3RXBuf[210];
extern unsigned short gusRGSStatus;
extern unsigned short gusPressureKpa;
extern unsigned short gusPumpPercent;

extern unsigned short gusTower1PurgedPercent;
extern unsigned short gusTower2PurgedPercent;
extern unsigned short gusTower1Temp;
extern unsigned short gusTower2Temp;
extern unsigned short gusTower1PWM;
extern unsigned short gusTower2PWM; 
extern unsigned short gusBatPercent;

int giWriteCommandReplied;
unsigned short int giRGS_Status[50];
void processUART3ReceivedData(void)
{
  int i, j;
  
  unsigned char mnDataArray[100];
  unsigned short iStartRegister, iNumOfReg;
  
  
  if((gucU3RXBuf[giU3ReceivedCnt-1] == 0xa) && (gucU3RXBuf[0] == ':'))
  {
    j = giU3ReceivedCnt-3;
    for( i = 0; i < j; i++)  
      gucU3RXBuf[i] = gucU3RXBuf[i+1];
    
    j = j/2;
    for( i = 0; i < j; i++)
    {
      if(gucU3RXBuf[2*i] < 58)
      {        
        mnDataArray[i] = gucU3RXBuf[2*i]-'0';
      }
      else
      {
        mnDataArray[i] = gucU3RXBuf[2*i]-'A'+10;
      }
      
      if(gucU3RXBuf[2*i+1] < 58)
      {        
        mnDataArray[i] =  mnDataArray[i]*16 + gucU3RXBuf[2*i+1]-'0';
      }
      else
      {
        mnDataArray[i] = mnDataArray[i]*16 + gucU3RXBuf[2*i+1]-'A'+10;
      }
    }
    
    
     if(mnDataArray[1] == 16)
         giWriteCommandReplied ++;
        
     if(mnDataArray[1] == 3)
     {     
        iStartRegister = mnDataArray[2] * 256 + mnDataArray[3];
        iNumOfReg = mnDataArray[4] * 256 + mnDataArray[5];

        if(iStartRegister < 256) 
        {
          i=0;   // does nothing
                   // For i = iStartRegister To iStartRegister + iNumOfReg - 1
                  //      giParameter_CPU(i) = mnDataArray(6 + (i - iStartRegister) * 2) * 256 + mnDataArray(7 + (i - iStartRegister) * 2)
                   // Next
                  //  pbReadParameterCompleted = True
        }
        else
        {
          iStartRegister = iStartRegister - 256;
          for(i = iStartRegister; i <(iStartRegister + iNumOfReg); i++)            
            giRGS_Status[i] = mnDataArray[6 + (i - iStartRegister) * 2] * 256 + mnDataArray[7 + (i - iStartRegister) * 2];
                  
        }
        
        gusRGSStatus = giRGS_Status[0];        
        gusTower1PWM = giRGS_Status[1];
        gusTower2PWM = giRGS_Status[2];
        gusTower1PurgedPercent = giRGS_Status[3];
        gusTower2PurgedPercent = giRGS_Status[4];
        gusTower1Temp = giRGS_Status[5];
        gusTower2Temp = giRGS_Status[6];
    
        gusBatPercent = giRGS_Status[10];
        
        gusPressureKpa = giRGS_Status[11];
        gusPumpPercent = giRGS_Status[12];
        
     }
  
    
  }
  

}


extern unsigned char gucDataBinary[];
extern unsigned char gucDataBinaryToSend;
extern unsigned short giU3NumByteToSend;
// convert the binaary to ASC
void packDataTosend(void)
{
  
  unsigned char  uci;

  unsigned char ucHiNibble, ucLoNibble;
  unsigned char ucTemp;
  unionUnsignedShort nLRC;
  
  nLRC.usData = 0;
  for(uci = 0; uci < gucDataBinaryToSend; uci++)
     nLRC.usData = nLRC.usData + gucDataBinary[uci];
  uci = nLRC.ucByte[0];
  uci = 255 - uci;
  uci = uci + 1;
  
    
  gucDataBinary[gucDataBinaryToSend] = uci;
  gucDataBinaryToSend++;
  
  gucU3TXBuf[0] = ':';
  for(uci = 0; uci < gucDataBinaryToSend; uci++)
  {
    ucTemp = gucDataBinary[uci]/16;
    if(ucTemp < 10)
      ucHiNibble = '0' + ucTemp;
    else
      ucHiNibble = ucTemp-10 +'A';
    
    ucTemp = gucDataBinary[uci]%16;
    if(ucTemp < 10)
      ucLoNibble = '0' + ucTemp;
    else
      ucLoNibble = ucTemp-10 +'A';
    gucU3TXBuf[uci*2 +1] = ucHiNibble;
    gucU3TXBuf[uci*2 +2] = ucLoNibble;
    
  }
  gucU3TXBuf[gucDataBinaryToSend*2 +1] =0xd;
  gucU3TXBuf[gucDataBinaryToSend*2 +2] =0xa;
  giU3NumByteToSend = gucDataBinaryToSend*2 + 3;
  
  
  }  
/*
    '    'LRC calculation
    '    Dim i As Integer
    '    Dim nLRC As Integer
    '    Dim sHiNibble As String
    '    Dim sLoNibble As String
    '    Dim iTemp As Integer

    '    nLRC = 0
    '    For i = 0 To pmiNumOfDataToBeSent - 1
    '        nLRC = nLRC + pmiDataToBeSent(i)
    '    Next
    '    nLRC = nLRC - (Int(nLRC / 256)) * 256
    '    nLRC = 255 - nLRC
    '    nLRC = nLRC + 1

    '    pmiDataToBeSent(pmiNumOfDataToBeSent) = nLRC
    '    pmiNumOfDataToBeSent = pmiNumOfDataToBeSent + 1

    '    psSendBuffer = ":"
    '    For i = 0 To pmiNumOfDataToBeSent - 1
    '        iTemp = Int(pmiDataToBeSent(i) / 16)
    '        If iTemp < 10 Then
    '            sHiNibble = Format(iTemp)
    '        Else
    '            If iTemp = 10 Then
    '                sHiNibble = "A"
    '            End If
    '            If iTemp = 11 Then
    '                sHiNibble = "B"
    '            End If
    '            If iTemp = 12 Then
    '                sHiNibble = "C"
    '            End If
    '            If iTemp = 13 Then
    '                sHiNibble = "D"
    '            End If
    '            If iTemp = 14 Then
    '                sHiNibble = "E"
    '            End If
    '            If iTemp = 15 Then
    '                sHiNibble = "F"
    '            End If

    '        End If

    '        iTemp = pmiDataToBeSent(i) - iTemp * 16
    '        If iTemp < 10 Then
    '            sLoNibble = Format(iTemp)
    '        Else
    '            If iTemp = 10 Then
    '                sLoNibble = "A"
    '            End If
    '            If iTemp = 11 Then
    '                sLoNibble = "B"
    '            End If
    '            If iTemp = 12 Then
    '                sLoNibble = "C"
    '            End If
    '            If iTemp = 13 Then
    '                sLoNibble = "D"
    '            End If
    '            If iTemp = 14 Then
    '                sLoNibble = "E"
    '            End If
    '            If iTemp = 15 Then
    '                sLoNibble = "F"
    '            End If

    '        End If
    '        psSendBuffer = psSendBuffer + sHiNibble + sLoNibble
    '    Next

    'End Sub
  */


unsigned short CRC16(unsigned char *puchMsg,unsigned short usDataLen)
{
static const unsigned short wCRCTable[] = {
0X0000, 0XC0C1, 0XC181, 0X0140, 0XC301, 0X03C0, 0X0280, 0XC241,
0XC601, 0X06C0, 0X0780, 0XC741, 0X0500, 0XC5C1, 0XC481, 0X0440,
0XCC01, 0X0CC0, 0X0D80, 0XCD41, 0X0F00, 0XCFC1, 0XCE81, 0X0E40,
0X0A00, 0XCAC1, 0XCB81, 0X0B40, 0XC901, 0X09C0, 0X0880, 0XC841,
0XD801, 0X18C0, 0X1980, 0XD941, 0X1B00, 0XDBC1, 0XDA81, 0X1A40,
0X1E00, 0XDEC1, 0XDF81, 0X1F40, 0XDD01, 0X1DC0, 0X1C80, 0XDC41,
0X1400, 0XD4C1, 0XD581, 0X1540, 0XD701, 0X17C0, 0X1680, 0XD641,
0XD201, 0X12C0, 0X1380, 0XD341, 0X1100, 0XD1C1, 0XD081, 0X1040,
0XF001, 0X30C0, 0X3180, 0XF141, 0X3300, 0XF3C1, 0XF281, 0X3240,
0X3600, 0XF6C1, 0XF781, 0X3740, 0XF501, 0X35C0, 0X3480, 0XF441,
0X3C00, 0XFCC1, 0XFD81, 0X3D40, 0XFF01, 0X3FC0, 0X3E80, 0XFE41,
0XFA01, 0X3AC0, 0X3B80, 0XFB41, 0X3900, 0XF9C1, 0XF881, 0X3840,
0X2800, 0XE8C1, 0XE981, 0X2940, 0XEB01, 0X2BC0, 0X2A80, 0XEA41,
0XEE01, 0X2EC0, 0X2F80, 0XEF41, 0X2D00, 0XEDC1, 0XEC81, 0X2C40,
0XE401, 0X24C0, 0X2580, 0XE541, 0X2700, 0XE7C1, 0XE681, 0X2640,
0X2200, 0XE2C1, 0XE381, 0X2340, 0XE101, 0X21C0, 0X2080, 0XE041,
0XA001, 0X60C0, 0X6180, 0XA141, 0X6300, 0XA3C1, 0XA281, 0X6240,
0X6600, 0XA6C1, 0XA781, 0X6740, 0XA501, 0X65C0, 0X6480, 0XA441,
0X6C00, 0XACC1, 0XAD81, 0X6D40, 0XAF01, 0X6FC0, 0X6E80, 0XAE41,
0XAA01, 0X6AC0, 0X6B80, 0XAB41, 0X6900, 0XA9C1, 0XA881, 0X6840,
0X7800, 0XB8C1, 0XB981, 0X7940, 0XBB01, 0X7BC0, 0X7A80, 0XBA41,
0XBE01, 0X7EC0, 0X7F80, 0XBF41, 0X7D00, 0XBDC1, 0XBC81, 0X7C40,
0XB401, 0X74C0, 0X7580, 0XB541, 0X7700, 0XB7C1, 0XB681, 0X7640,
0X7200, 0XB2C1, 0XB381, 0X7340, 0XB101, 0X71C0, 0X7080, 0XB041,
0X5000, 0X90C1, 0X9181, 0X5140, 0X9301, 0X53C0, 0X5280, 0X9241,
0X9601, 0X56C0, 0X5780, 0X9741, 0X5500, 0X95C1, 0X9481, 0X5440,
0X9C01, 0X5CC0, 0X5D80, 0X9D41, 0X5F00, 0X9FC1, 0X9E81, 0X5E40,
0X5A00, 0X9AC1, 0X9B81, 0X5B40, 0X9901, 0X59C0, 0X5880, 0X9841,
0X8801, 0X48C0, 0X4980, 0X8941, 0X4B00, 0X8BC1, 0X8A81, 0X4A40,
0X4E00, 0X8EC1, 0X8F81, 0X4F40, 0X8D01, 0X4DC0, 0X4C80, 0X8C41,
0X4400, 0X84C1, 0X8581, 0X4540, 0X8701, 0X47C0, 0X4680, 0X8641,
0X8201, 0X42C0, 0X4380, 0X8341, 0X4100, 0X81C1, 0X8081, 0X4040 };

u8 nTemp;
unsigned short wCRCWord = 0xFFFF;

   while (usDataLen--)
   {
      nTemp = *puchMsg++ ^ wCRCWord;
      wCRCWord >>= 8;
      wCRCWord ^= wCRCTable[nTemp];
   }
   return wCRCWord;

}




//USART1 RX DMA2 channel 4 and stream 5
void USART1_RX_DMA_Config(unsigned char *ptrBufStartAddr, unsigned short usBufferSize)
{
  /*
  DMA_InitTypeDef  DMA_InitStructure;  
  // Enable ADC1, DMA2 and GPIO clocks ***************************************
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA2, ENABLE);
  
  DMA_DeInit(DMA2_Stream5);
 
  DMA_InitStructure.DMA_Channel = DMA_Channel_4;
  DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory; // Receiving
  DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)ptrBufStartAddr;
  DMA_InitStructure.DMA_BufferSize = usBufferSize;
  DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)&USART1->DR;
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
  DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
  DMA_InitStructure.DMA_Priority = DMA_Priority_High;
  DMA_InitStructure.DMA_FIFOMode =  DMA_FIFOMode_Disable;    // Disable the FIFI to let the DR immediately to Destination buff, otherwise will wait for FIFO full(4 words)     
  DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_HalfFull;
  DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;
  DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;
 
  DMA_Init(DMA2_Stream5, &DMA_InitStructure);
  
  // Enable the DMA RX Stream 
  DMA_Cmd(DMA2_Stream5, ENABLE);
  
 */

}


//USART1 TX DMA2 channel 4 and stream 7
void USART1_TX_DMA_Config(unsigned char *ptrBufStartAddr, unsigned short usBufferSize)
{
  
  /*
  DMA_InitTypeDef  DMA_InitStructure;  
  // Enable ADC1, DMA2 and GPIO clocks ***************************************
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA2, ENABLE);
  
  DMA_DeInit(DMA2_Stream7);
 
  DMA_InitStructure.DMA_Channel = DMA_Channel_4;
  DMA_InitStructure.DMA_DIR = DMA_DIR_MemoryToPeripheral; // Transmitting
  DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)ptrBufStartAddr;
  DMA_InitStructure.DMA_BufferSize = usBufferSize;
  DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)&USART1->DR;
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
  DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;//DMA_Mode_Circular; In Cicrcular Buffer mode, the DMA will keep sending data out 
  DMA_InitStructure.DMA_Priority = DMA_Priority_High;
  DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable;    // Disable the FIFI to let the DR immediately to Destination buff, otherwise will wait for FIFO full(4 words)
  DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_HalfFull;
  DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;
  DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;
 
  DMA_Init(DMA2_Stream7, &DMA_InitStructure);
  
  // Enable the DMA TX Stream 
  DMA_Cmd(DMA2_Stream7, ENABLE);
  
 */

}




//USART2 RX DMA1 channel 4 and stream 5
void USART2_RX_DMA_Config(unsigned char *ptrBufStartAddr, unsigned short usBufferSize)
{
  /*
  DMA_InitTypeDef  DMA_InitStructure;  
  // Enable ADC1, DMA2 and GPIO clocks ***************************************
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA1, ENABLE);
  
  DMA_DeInit(DMA1_Stream5);
 
  DMA_InitStructure.DMA_Channel = DMA_Channel_4;
  DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory; // Receiving
  DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)ptrBufStartAddr;
  DMA_InitStructure.DMA_BufferSize = usBufferSize;
  DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)&USART2->DR;
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
  DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
  DMA_InitStructure.DMA_Priority = DMA_Priority_High;
  DMA_InitStructure.DMA_FIFOMode =  DMA_FIFOMode_Disable;    // Disable the FIFI to let the DR immediately to Destination buff, otherwise will wait for FIFO full(4 words)     
  DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_HalfFull;
  DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;
  DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;
 
  DMA_Init(DMA1_Stream5, &DMA_InitStructure);
  
  // Enable the DMA RX Stream 
  DMA_Cmd(DMA1_Stream5, ENABLE);
  */
 

}


//USART2 TX DMA1 channel 4 and stream 6
void USART2_TX_DMA_Config(unsigned char *ptrBufStartAddr, unsigned short usBufferSize)
{
  /*
  DMA_InitTypeDef  DMA_InitStructure;  
  // Enable ADC1, DMA2 and GPIO clocks ***************************************
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA1, ENABLE);
  
  DMA_DeInit(DMA1_Stream6);
 
  DMA_InitStructure.DMA_Channel = DMA_Channel_4;
  DMA_InitStructure.DMA_DIR = DMA_DIR_MemoryToPeripheral; // Transmitting
  DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)ptrBufStartAddr;
  DMA_InitStructure.DMA_BufferSize = usBufferSize;
  DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t) & (USART2->DR);
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
  DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;//DMA_Mode_Circular; In Cicrcular Buffer mode, the DMA will keep sending data out 
  DMA_InitStructure.DMA_Priority = DMA_Priority_High;
  DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable;    // Disable the FIFI to let the DR immediately to Destination buff, otherwise will wait for FIFO full(4 words)
  DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_HalfFull;
  DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;
  DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;
 
  DMA_Init(DMA1_Stream6, &DMA_InitStructure);
  
  // Enable the DMA TX Stream 
  DMA_Cmd(DMA1_Stream6, ENABLE);
  */
 

}




//USART3 RX DMA1 channel 4 and stream 1
void USART3_RX_DMA_Config(unsigned char *ptrBufStartAddr, unsigned short usBufferSize)
{
  /*
  
  DMA_InitTypeDef  DMA_InitStructure;  
  // Enable ADC1, DMA2 and GPIO clocks ***************************************
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA1, ENABLE);
  
  DMA_DeInit(DMA1_Stream1);
 
  DMA_InitStructure.DMA_Channel = DMA_Channel_4;
  DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory; // Receiving
  DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)ptrBufStartAddr;
  DMA_InitStructure.DMA_BufferSize = usBufferSize;
  DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)&USART3->DR;
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
  DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
  DMA_InitStructure.DMA_Priority = DMA_Priority_High;
  DMA_InitStructure.DMA_FIFOMode =  DMA_FIFOMode_Disable;    // Disable the FIFI to let the DR immediately to Destination buff, otherwise will wait for FIFO full(4 words)     
  DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_HalfFull;
  DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;
  DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;
 
  DMA_Init(DMA1_Stream1, &DMA_InitStructure);
  
  // Enable the DMA RX Stream 
  DMA_Cmd(DMA1_Stream1, ENABLE);
  
 */

}


//USART3 TX DMA1 channel 4 and stream 3
void USART3_TX_DMA_Config(unsigned char *ptrBufStartAddr, unsigned short usBufferSize)
{
  /*
  DMA_InitTypeDef  DMA_InitStructure;  
  // Enable ADC1, DMA2 and GPIO clocks ***************************************
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA1, ENABLE);
  
  DMA_DeInit(DMA1_Stream3);
 
  DMA_InitStructure.DMA_Channel = DMA_Channel_4;
  DMA_InitStructure.DMA_DIR = DMA_DIR_MemoryToPeripheral; // Transmitting
  DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)ptrBufStartAddr;
  DMA_InitStructure.DMA_BufferSize = usBufferSize;
  DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t) & (USART3->DR);
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
  DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;//DMA_Mode_Circular; In Cicrcular Buffer mode, the DMA will keep sending data out 
  DMA_InitStructure.DMA_Priority = DMA_Priority_High;
  DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable;    // Disable the FIFI to let the DR immediately to Destination buff, otherwise will wait for FIFO full(4 words)
  DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_HalfFull;
  DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;
  DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;
 
  DMA_Init(DMA1_Stream3, &DMA_InitStructure);
  
  // Enable the DMA TX Stream 
  DMA_Cmd(DMA1_Stream3, ENABLE);
  */
}



//extern ChannelTypeDef structChannel[];  //50


extern u16 giModBusHoldingReg[];
void processMethodData(void)
{

}


/******************* (C) COPYRIGHT 2007 STMicroelectronics *****END OF FILE****/
