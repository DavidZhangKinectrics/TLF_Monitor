/**
  ******************************************************************************

 
*/
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __Peripheral_Control_H
#define __Peripheral_Control_H

#define EN_HV   GPIOA->BSRRL = GPIO_Pin_4
#define DIS_HV  GPIOA->BSRRH = GPIO_Pin_4



#endif 


