/**
  Data Grabber
  ******************************************************************************
  */ 

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"
#include "Peripheral.h"
#include "stm32f4xx_gpio.h"
#include "arm_math.h"
#include "DataGrabber.h"
#include "usart.h"

#define ADC1_DR_ADDRESS     ((uint32_t)0x4001204C)
#define ADC2_DR_ADDRESS     ((uint32_t)0x4001214C)


/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/







/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
