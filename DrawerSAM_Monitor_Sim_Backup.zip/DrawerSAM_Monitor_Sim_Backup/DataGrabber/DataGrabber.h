/**
  ******************************************************************************
  * @file    TIM/TIM1_Synchro/stm32f4xx_conf.h  
 
*/
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __DATA_Garbber_H
#define __DATA_Garbber_H

#define PLASMA_SCREEN               0
#define MENU_SCREEN                 1
#define IMS_STATUS_SCREEN           2
#define RGS_STATUS_SCREEN           3


#define SYSTEM_Freq        168  // MHz   // adc div has to be changed to meet the Max CLK
#define TIME_BASE           1 //MicroSeconds
#define NUM_DATA_BUF         100  // for 1 MicroSec  maximum of the scan time  500uS
#define SAMPLE_PERIOD_DEFAULT        25 // MicroSeconds, It Must be multiple of TIME_BASE
#define SCAN_PERIOD_DEFAULT          1000 //12500  // MicroScan. It Must be multiple of SAMPLE_PERIOD_DEFAULT *10
#define GATING_PULSE_WIDTH_DEFAULT   160  // 150 MicroScan. It Must be multiple of TIME_BASE

#define BLANKING_PULSE_WIDTH_DEFAULT 2000 //3000 // 3000 MicroSecond
#define BLANKING_START_TIME_DEFAULT  12000//3100 // from the end

#define SCAN_NUM_PER_SLICE_DEFAULT  10 // 
#define SLICE_NUM_PER_POLARITY_DEFAULT  1 // 3000 MicroSecond


#define POSITIVE_MODE   0  //
#define NEGATIVE_MODE   1  //
#define START_FROM_POSITIVE_MODE   2  //
#define START_FROM_NEGATIVE_MODE   3  //

//#define TURN_ON_GRN_LED GPIOB->BSRRL = GPIO_Pin_5
//#define TURN_OFF_GRN_LED GPIOB->BSRRH = GPIO_Pin_5
//#define TURN_ON_RED_LED GPIOD->BSRRL = GPIO_Pin_2
//#define TURN_OFF_RED_LED GPIOD->BSRRH = GPIO_Pin_2


#define TURN_ON_ALM_LED GPIOB->BSRRL = GPIO_Pin_1
#define TURN_OFF_ALM_LED GPIOB->BSRRH = GPIO_Pin_1
#define TURN_ON_WARN_LED GPIOB->BSRRL = GPIO_Pin_0
#define TURN_OFF_WARN_LED GPIOB->BSRRH = GPIO_Pin_0




typedef struct
{  
  unsigned short usSamplePeriod;
  unsigned short usScanPeriod;
  unsigned short usGatingPulseWidth;   
  unsigned short usBlankDistanceTime;   
  unsigned short usBlankPulseWidth;
  unsigned short usScanNumPerSlice;   
  unsigned short usSLiceNumPerPolarity;
  unsigned short usSwitchingMode; 
} DataGrabber_InitTypeDef;

typedef struct
{
    unsigned short   x1;
    unsigned short     y1;
    unsigned short     x2;
    unsigned short     y2;
    unsigned short     x3;
    unsigned short     y3;
    unsigned short     x4;
    unsigned short     y4;
    unsigned short     x5;
    unsigned short     y5;
    unsigned char      touch_point;
    unsigned char      Key_Sta;	
}_ts_event;



//void Init_DataGrabber(void);
void InitPortABCForLEDDisp(void);

void Timing_Config(void);

void ADC1_DMA_Config(unsigned short *ptrBufStartAddr);
void ADC2_DMA_Config(unsigned short *ptrBufStartAddr);
void ADC3_DMA_Config(unsigned short *ptrBufStartAddr);

void ADC3_Config(void);
void ADC2_CH6_Config(void);
void ADC1_CH7_Config(void);


void processData(void);

void InitPorts_Timers(void);


int calculateTCTemp(unsigned int iDataIn);
unsigned short calculateAPT(unsigned int uiAPTChannelDigitalCnt);


#endif /* __STM32F4xx_CONF_H */

/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
