
#ifndef __PID_H
#define __PID_H

typedef struct
{
  float fPV;              // Process Value
  float fSP;
  
  float fKp;
  float fKi;
  float fKd;
  
  float fPID_Int;
  float fPID_Pre_Err;       // Previous Error
  
  float fDeadBand;
  
  float fLowLimit;
  float fHighLimit;
  float fPID_out;            // PID Output
          
}PIDTypeDef;

#define Set_V3_Exhaust_PWM(X) TIM3->CCR3 = X  
//#define Set_V2_Recir_PWM(X) TIM4->CCR3 = X 
#define TurnOnExhaustSV1 TIM3->CCR3 = 999
#define TurnOffExhaustSV1 TIM3->CCR3 = 0


#define Set_V1_Refill_PWM(X) TIM3->CCR4 = X  
#define Set_Pump_PWM(X) TIM4->CCR4= X  

#define IDLE (((GPIOD->DR)&0x4000) == 0) 
#define PUMP_ON (((GPIOD->DR)&0x8000) == 0) 
#define STATUS (((GPIOD->DR)&0x0001) == 0)
#define SETUP (((GPIOD->DR)&0x0002) == 0)

void PID_Cooling(PIDTypeDef *structPID);
void PID_Heating(PIDTypeDef *structPID);

#endif 
/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
