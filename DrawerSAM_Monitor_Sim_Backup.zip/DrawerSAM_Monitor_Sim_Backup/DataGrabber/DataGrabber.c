/**
  Data Grabber
  ******************************************************************************
  */ 

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"
#include "DataGrabber.h"
#include "stm32f4xx_gpio.h"
#include "usart.h"
#include "arm_math.h"
#include "Peripheral.h"
#include "PID.h"

#define ADC1_DR_ADDRESS     ((uint32_t)0x4001204C)
#define ADC2_DR_ADDRESS     ((uint32_t)0x4001214C)
#define ADC3_DR_ADDRESS     ((uint32_t)0x4001224C)
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
TIM_OCInitTypeDef  TIM_OCInitStructure;
TIM_BDTRInitTypeDef TIM_BDTRInitStructure;


DAC_InitTypeDef  DAC_InitStructure;


unsigned short usScanIndex;
unsigned short usSliceIndex;


unsigned short gusADC1DataBuf0[NUM_DATA_BUF];
unsigned short gusADC1DataBuf1[NUM_DATA_BUF];
//unsigned short gusADC2DataBuf0[NUM_DATA_BUF];
//unsigned short gusADC2DataBuf1[NUM_DATA_BUF];
//unsigned short gusADC3DataBuf0[NUM_DATA_BUF];
//unsigned short gusADC3DataBuf1[NUM_DATA_BUF];


unsigned short usSaveToBuf1_Flag;


int giHV_ON_Reg;
int giHV_OFF_Reg;

int giNewScanFlag;

unsigned char gucCommDataBuf0[100];//gucCommDataBuf0[2500];
//unsigned char gucCommDataBuf1[2500];
int guiStartNewPolarityFlag;
extern unsigned short gusCurrentInNegMode;



DataGrabber_InitTypeDef gstructDataGrabberInit;



//void Init_DataGrabber(void)
//{
//   u16 usTemp;
//   gstructDataGrabberInit.usSamplePeriod = SAMPLE_PERIOD_DEFAULT;
//   usTemp = gstructDataGrabberInit.usSamplePeriod*10;
//   if(PAR_ScanPeriod%usTemp !=0)
//     PAR_ScanPeriod = (PAR_ScanPeriod/usTemp)*usTemp;
//   gstructDataGrabberInit.usScanPeriod = PAR_ScanPeriod;//SCAN_PERIOD_DEFAULT;
//   gstructDataGrabberInit.usGatingPulseWidth = PAR_GatingPulseWidth;//GATING_PULSE_WIDTH_DEFAULT;   
//   gstructDataGrabberInit.usBlankDistanceTime = BLANKING_START_TIME_DEFAULT;   
//   gstructDataGrabberInit.usBlankPulseWidth = BLANKING_PULSE_WIDTH_DEFAULT;
//   gstructDataGrabberInit.usScanNumPerSlice =PAR_NumOfScanPerSlice;// SCAN_NUM_PER_SLICE_DEFAULT;   
//   gstructDataGrabberInit.usSLiceNumPerPolarity = PAR_NumOfSlicePerPolarity;//SLICE_NUM_PER_POLARITY_DEFAULT;
// 
//   gstructDataGrabberInit.usSwitchingMode = PAR_DataGrabberSwitchingMode;
//    
//       
//}

// TIM5 is the ADC sample clock - 1 uS 1M S/Sec
// TIM5 CC1(10%PWM) to Trigger ADC1, CC2(43%PWM) to trigger ADC2, CC3(77%PWM) to Trigger ADC3
// TIM1 is Colcked by TIM5, to generate Gating Pulse (By PWM CC1),HV Balnking Start(CC2 PWM), HV ON/OFF(CC3 PWM), Blanking Stop (CC4) and update interrupt to genterate the PA_CLR
// TIM 8 is clocked by TIM5, to generate the interupt for one group of sample (10 Data points)ready, also count the datapoint
/*
// TIM6 is also clocked by TIM5 and PWM CC1 interrupt to Start Blanking     
//                                      CC2 interupt to switch the High voltage
//                                      CC3 interupt to Stop the Blanking Pulse
// TIM2 is clocked by TIM5 40K Hz to start  ADC1 
*/
unsigned short usBlankingPulseStartCnt;
unsigned short usBlankingPulseEndCnt;
unsigned short gusDataPointIndex;
void Timing_Config(void)
{
  
  
  EXTI_InitTypeDef   EXTI_InitStructure;
  GPIO_InitTypeDef   GPIO_InitStructure;
  NVIC_InitTypeDef   NVIC_InitStructure;

  /* Enable GPIOA clock */
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA | RCC_AHB1Periph_GPIOB , ENABLE);
  /* Enable SYSCFG clock */
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);
// 
//  // Front Input #1  shall change to PB9
//  /* Configure PB9 pin as input floating */
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
//  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
//  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
//  GPIO_Init(GPIOB, &GPIO_InitStructure);
//
//  /* Connect EXTI Line9 to PB9  pin */
//  SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOB, EXTI_PinSource9);
//
//  /* Configure EXTI Line9 */
//  EXTI_InitStructure.EXTI_Line = EXTI_Line9;
//  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
//  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;  
//  EXTI_InitStructure.EXTI_LineCmd = ENABLE;
//  EXTI_Init(&EXTI_InitStructure);
//
//  /* Enable and set EXTI15_10 Interrupt to the lowest priority */
//  NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;
//  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x0;//0x0F;
//  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x0;//0x0F;
//  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//
//  NVIC_Init(&NVIC_InitStructure);
//  
//  
//    // Front Detector #2 
//  /* Configure PA3 pin as input floating */
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
//  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
//  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
//  GPIO_Init(GPIOA, &GPIO_InitStructure);
//
//  /* Connect EXTI Line2 to PA2 pin */
//  SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOA, EXTI_PinSource3);
//
//  /* Configure EXTI Line3 */
//  EXTI_InitStructure.EXTI_Line = EXTI_Line3;
//  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
//  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;  
//  EXTI_InitStructure.EXTI_LineCmd = ENABLE;
//  EXTI_Init(&EXTI_InitStructure);
//
//  /* Enable and set EXTI Line2 Interrupt to the Highest priority */
//  NVIC_InitStructure.NVIC_IRQChannel = EXTI3_IRQn;//EXTI0_IRQn;
//  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x0;//0x0F;
//  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x1;//0x0F;
//  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//  NVIC_Init(&NVIC_InitStructure);
// 
//  // Front Detector #3   
//  /* Configure PA5 pin as input floating */
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
//  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
//  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
//  GPIO_Init(GPIOA, &GPIO_InitStructure);
//
//  /* Connect EXTI Line9 to PA5  pin */
//  SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOA, EXTI_PinSource5);
//
//  /* Configure EXTI Line5 */
//  EXTI_InitStructure.EXTI_Line = EXTI_Line5;
//  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
//  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;  
//  EXTI_InitStructure.EXTI_LineCmd = ENABLE;
//  EXTI_Init(&EXTI_InitStructure);
//
//  /* Enable and set EXTI15_10 Interrupt to the lowest priority */
//  NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;
//  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x0;//0x0F;
//  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x0;//0x0F;
//  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//
//  NVIC_Init(&NVIC_InitStructure);
//  
//    // Front Detector #4   
//  /* Configure PA6 pin as input floating */
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
//  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
//  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
//  GPIO_Init(GPIOA, &GPIO_InitStructure);
//
//  /* Connect EXTI Line6  to PA6  pin */
//  SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOA, EXTI_PinSource6);
//
//  /* Configure EXTI Line6 */
//  EXTI_InitStructure.EXTI_Line = EXTI_Line6;
//  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
//  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;  
//  EXTI_InitStructure.EXTI_LineCmd = ENABLE;
//  EXTI_Init(&EXTI_InitStructure);
//
//  /* Enable and set EXTI15_10 Interrupt to the lowest priority */
//  NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;
//  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x0;//0x0F;
//  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x0;//0x0F;
//  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//
//  NVIC_Init(&NVIC_InitStructure);
//  
//  
//  
//   // Rear Detector #1 
//  /* Configure PA2 pin as input floating */
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
//  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
//  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
//  GPIO_Init(GPIOA, &GPIO_InitStructure);
//
//  /* Connect EXTI Line2 to PA2 pin */
//  SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOA, EXTI_PinSource2);
//
//  /* Configure EXTI Line2 */
//  EXTI_InitStructure.EXTI_Line = EXTI_Line2;
//  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
//  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;  
//  EXTI_InitStructure.EXTI_LineCmd = ENABLE;
//  EXTI_Init(&EXTI_InitStructure);
//
//  /* Enable and set EXTI Line2 Interrupt to the Highest priority */
//  NVIC_InitStructure.NVIC_IRQChannel = EXTI2_IRQn;//EXTI0_IRQn;
//  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x0;//0x0F;
//  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x1;//0x0F;
//  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//  NVIC_Init(&NVIC_InitStructure);
// 
//  
//   // Rear Detector #2 
//  /* Configure PB1 pin as input floating */
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
//  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
//  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
//  GPIO_Init(GPIOB, &GPIO_InitStructure);
//
//  /* Connect EXTI Line1 to PB1 pin */
//  SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOB, EXTI_PinSource1);
//
//  /* Configure EXTI Line1 */
//  EXTI_InitStructure.EXTI_Line = EXTI_Line1;
//  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
//  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;  
//  EXTI_InitStructure.EXTI_LineCmd = ENABLE;
//  EXTI_Init(&EXTI_InitStructure);
//
//  /* Enable and set EXTI Line2 Interrupt to the Highest priority */
//  NVIC_InitStructure.NVIC_IRQChannel = EXTI1_IRQn;//EXTI0_IRQn;
//  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x0;//0x0F;
//  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x1;//0x0F;
//  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//  NVIC_Init(&NVIC_InitStructure);
// 
//  
//  // Rear #3
//  /* Configure PB14 pin as input floating */
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
//  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
//  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14;
//  GPIO_Init(GPIOB, &GPIO_InitStructure);
//
//  /* Connect EXTI Line14 to PB14 pin */
//  SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOB, EXTI_PinSource14);
//
//  /* Configure EXTI Line14 */
//  EXTI_InitStructure.EXTI_Line = EXTI_Line14;
//  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
//  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;  
//  EXTI_InitStructure.EXTI_LineCmd = ENABLE;
//  EXTI_Init(&EXTI_InitStructure);
//
//  /* Enable and set EXTI15_10 Interrupt to the Highest priority */
//  NVIC_InitStructure.NVIC_IRQChannel = EXTI15_10_IRQn;
//  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x0;//0x0F;
//  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x0;//0x0F;
//  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//
//  NVIC_Init(&NVIC_InitStructure);
//  
//  
//  // Rear Input #4  PA8
//  /* Configure PA8 pin as input floating */
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
//  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
//  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
//  GPIO_Init(GPIOA, &GPIO_InitStructure);
//
//  /* Connect EXTI Line8 to PA8 pin */
//  SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOA, EXTI_PinSource8);
//
//  /* Configure EXTI Line8 */
//  EXTI_InitStructure.EXTI_Line = EXTI_Line8;
//  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
//  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;  
//  EXTI_InitStructure.EXTI_LineCmd = ENABLE;
//  EXTI_Init(&EXTI_InitStructure);
//
//  /* Enable and set EXTI9_5 Interrupt to the lowest priority */
//  NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;
//  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x0;//0x0F;
//  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x0;//0x0F;
//  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//
//  NVIC_Init(&NVIC_InitStructure);
  
  
    //   PB10 to TIM2 PWM ch3
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;;//GPIO_Speed_50MHz;//GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//GPIO_PuPd_NOPULL;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
//  /* Connect TIM pins to AF */
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource10, GPIO_AF_TIM2);

 

   RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
  
  // Timer 2 for Buzzer
  TIM_TimeBaseStructure.TIM_Prescaler = SYSTEM_Freq/2;   // 0- The TIM 4 Counting Clock will be 168/4 (PCLK1) x 2  = 1/2 SYSTEM_Freq
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
  TIM_TimeBaseStructure.TIM_Period = 1000;//357;//1580;//999;//2.048K//999; // 1000 Hz: (1/0.64)/(1/84) -1
  TIM_TimeBaseStructure.TIM_ClockDivision = 0;
  TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;//4;  RepetetionCounter decreased to 0 then generate Updated Event. but PWM is still dependent on 

  TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);

   //Channel 3 onfiguration in PWM mode 
  TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;  
  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
  TIM_OCInitStructure.TIM_OutputNState = TIM_OutputNState_Enable;
  TIM_OCInitStructure.TIM_Pulse = 0;//499;//499;//99/2;
  TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;//TIM_OCPolarity_Low;
  TIM_OCInitStructure.TIM_OCNPolarity = TIM_OCNPolarity_Low;
  TIM_OCInitStructure.TIM_OCIdleState = TIM_OCIdleState_Set;
  TIM_OCInitStructure.TIM_OCNIdleState = TIM_OCIdleState_Reset;
  
  TIM_OC3Init(TIM2, &TIM_OCInitStructure); 

  // Automatic Output enable, Break, dead time and lock configuration
  TIM_BDTRInitStructure.TIM_OSSRState = TIM_OSSRState_Enable;
  TIM_BDTRInitStructure.TIM_OSSIState = TIM_OSSIState_Enable;
  TIM_BDTRInitStructure.TIM_LOCKLevel = TIM_LOCKLevel_1;
  TIM_BDTRInitStructure.TIM_DeadTime = 0;//0;
  TIM_BDTRInitStructure.TIM_Break = TIM_Break_Disable;
  TIM_BDTRInitStructure.TIM_BreakPolarity = TIM_BreakPolarity_High;
  TIM_BDTRInitStructure.TIM_AutomaticOutput = TIM_AutomaticOutput_Disable;
  TIM_BDTRConfig(TIM2, &TIM_BDTRInitStructure);
//  
  TIM_SetCounter(TIM2,0);
  TIM_Cmd(TIM2, ENABLE);  
//  
 

  //PB0 PB1 TIM3: PWM3 and PWM 4
  
   //   PB0 TIM3_PWM3 PB1  - TIM3_PWM4
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;//GPIO_Speed_50MHz;//GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//GPIO_PuPd_NOPULL;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    //  /* Connect TIM pins to AF */
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource0, GPIO_AF_TIM3);
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource1, GPIO_AF_TIM3);

   RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
  
  // Timer 3 for PWM
  TIM_TimeBaseStructure.TIM_Prescaler = SYSTEM_Freq/2;   // 0- The TIM 4 Counting Clock will be 168/4 (PCLK1) x 2  = 1/2 SYSTEM_Freq
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
  TIM_TimeBaseStructure.TIM_Period = 1000;//357;//1580;//999;//2.048K//999; // 1000 Hz: (1/0.64)/(1/84) -1
  TIM_TimeBaseStructure.TIM_ClockDivision = 0;
  TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;//4;  RepetetionCounter decreased to 0 then generate Updated Event. but PWM is still dependent on 

  TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);

   //Channel 3 onfiguration in PWM mode 
  TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;  
  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
  TIM_OCInitStructure.TIM_OutputNState = TIM_OutputNState_Enable;
  TIM_OCInitStructure.TIM_Pulse = 0;//499;//499;//99/2;
  TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_Low;//TIM_OCPolarity_High;//TIM_OCPolarity_Low;
  TIM_OCInitStructure.TIM_OCNPolarity = TIM_OCNPolarity_Low;
  TIM_OCInitStructure.TIM_OCIdleState = TIM_OCIdleState_Set;
  TIM_OCInitStructure.TIM_OCNIdleState = TIM_OCIdleState_Reset;
  
  TIM_OC3Init(TIM3, &TIM_OCInitStructure);
  TIM_OC4Init(TIM3, &TIM_OCInitStructure); 


  // Automatic Output enable, Break, dead time and lock configuration
  TIM_BDTRInitStructure.TIM_OSSRState = TIM_OSSRState_Enable;
  TIM_BDTRInitStructure.TIM_OSSIState = TIM_OSSIState_Enable;
  TIM_BDTRInitStructure.TIM_LOCKLevel = TIM_LOCKLevel_1;
  TIM_BDTRInitStructure.TIM_DeadTime = 0;//0;
  TIM_BDTRInitStructure.TIM_Break = TIM_Break_Disable;
  TIM_BDTRInitStructure.TIM_BreakPolarity = TIM_BreakPolarity_High;
  TIM_BDTRInitStructure.TIM_AutomaticOutput = TIM_AutomaticOutput_Disable;
  TIM_BDTRConfig(TIM3, &TIM_BDTRInitStructure);
  //  
  TIM_SetCounter(TIM3,0);
  TIM_Cmd(TIM3, ENABLE);  
  //  
  
  //PB8 PB9 TIM4: PWM3 and PWM 4
  
   //   PB8 TIM4_PWM3 PB9  - TIM4_PWM4
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;;//GPIO_Speed_50MHz;//GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//GPIO_PuPd_NOPULL;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    //  /* Connect TIM pins to AF */
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource8, GPIO_AF_TIM4);
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource9, GPIO_AF_TIM4);

   RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);
  
  // Timer 4 for PWM
  TIM_TimeBaseStructure.TIM_Prescaler = SYSTEM_Freq/2;   // 0- The TIM 4 Counting Clock will be 168/4 (PCLK1) x 2  = 1/2 SYSTEM_Freq
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
  TIM_TimeBaseStructure.TIM_Period = 1000;//357;//1580;//999;//2.048K//999; // 1000 Hz: (1/0.64)/(1/84) -1
  TIM_TimeBaseStructure.TIM_ClockDivision = 0;
  TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;//4;  RepetetionCounter decreased to 0 then generate Updated Event. but PWM is still dependent on 

  TIM_TimeBaseInit(TIM4, &TIM_TimeBaseStructure);

   //Channel 3 onfiguration in PWM mode 
  TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;  
  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
  TIM_OCInitStructure.TIM_OutputNState = TIM_OutputNState_Enable;
  TIM_OCInitStructure.TIM_Pulse = 0;//499;//499;//99/2;
  TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_Low;//TIM_OCPolarity_High;//TIM_OCPolarity_Low;
  TIM_OCInitStructure.TIM_OCNPolarity = TIM_OCNPolarity_Low;
  TIM_OCInitStructure.TIM_OCIdleState = TIM_OCIdleState_Set;
  TIM_OCInitStructure.TIM_OCNIdleState = TIM_OCIdleState_Reset;
  
  TIM_OC3Init(TIM4, &TIM_OCInitStructure); 
  TIM_OC4Init(TIM4, &TIM_OCInitStructure); 

  // Automatic Output enable, Break, dead time and lock configuration
  TIM_BDTRInitStructure.TIM_OSSRState = TIM_OSSRState_Enable;
  TIM_BDTRInitStructure.TIM_OSSIState = TIM_OSSIState_Enable;
  TIM_BDTRInitStructure.TIM_LOCKLevel = TIM_LOCKLevel_1;
  TIM_BDTRInitStructure.TIM_DeadTime = 0;//0;
  TIM_BDTRInitStructure.TIM_Break = TIM_Break_Disable;
  TIM_BDTRInitStructure.TIM_BreakPolarity = TIM_BreakPolarity_High;
  TIM_BDTRInitStructure.TIM_AutomaticOutput = TIM_AutomaticOutput_Disable;
  TIM_BDTRConfig(TIM4, &TIM_BDTRInitStructure);
  //  
  TIM_SetCounter(TIM4,0);
  TIM_Cmd(TIM4, ENABLE);  
  //  
  
  /* Enable the USART1 Interrupt */
  NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;//USART1_IRQChannel;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
  
 



  
}



// ADC clock 21 MHz, 15 Clks needed for 1 conversion and 5 cycles delay between each conversion
// Therefore Maximum speed will be 1.05MSample/S
void ADC3_Config(void)
{
   
//  
//  ADC_InitTypeDef       ADC_InitStructure;
//  ADC_CommonInitTypeDef structADC_CommonInit;  
//  GPIO_InitTypeDef      GPIO_InitStructure;
//
//  /* Enable ADC1, DMA2 and GPIO clocks ****************************************/
//  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA2|RCC_AHB1Periph_GPIOC, ENABLE);
//  RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC3, ENABLE);
//   
//   /* Configure PC.0,1(ADC3 Channel10,11) in analog mode */
//  GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_0 | GPIO_Pin_1;
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AN;
//  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
//  GPIO_Init(GPIOC, &GPIO_InitStructure);  
//  
//
//  /* ADC Common Init **********************************************************/
//  structADC_CommonInit.ADC_Mode = ADC_Mode_Independent;
//  structADC_CommonInit.ADC_Prescaler = ADC_Prescaler_Div4;// // 21MHZ// Since the PCLK2 = SystemClock/2, the maximum of the ADC clock should be 30MHZ;
//  structADC_CommonInit.ADC_DMAAccessMode = ADC_DMAAccessMode_Disabled;
//  structADC_CommonInit.ADC_TwoSamplingDelay = ADC_TwoSamplingDelay_5Cycles;
//  ADC_CommonInit(&structADC_CommonInit);
//
//  /* ADC32Init ****************************************************************/
//  ADC_InitStructure.ADC_Resolution = ADC_Resolution_12b;
//  ADC_InitStructure.ADC_ScanConvMode = ENABLE;
//  ADC_InitStructure.ADC_ContinuousConvMode = DISABLE;
//  ADC_InitStructure.ADC_ExternalTrigConvEdge = ADC_ExternalTrigConvEdge_Rising;
//  ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_T5_CC1;
//  ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
//  ADC_InitStructure.ADC_NbrOfConversion = 5;
//  ADC_Init(ADC3, &ADC_InitStructure);
//
// 
//   /* ADC1 regular channel0 and 3 configuration *************************************/
//  ADC_RegularChannelConfig(ADC3, ADC_Channel_10, 1, ADC_SampleTime_3Cycles);//ADC_SampleTime_3Cycles);
//  ADC_RegularChannelConfig(ADC3, ADC_Channel_10, 2, ADC_SampleTime_3Cycles);//ADC_SampleTime_3Cycles);
//  ADC_RegularChannelConfig(ADC3, ADC_Channel_10, 3, ADC_SampleTime_3Cycles);//ADC_SampleTime_3Cycles);
//  ADC_RegularChannelConfig(ADC3, ADC_Channel_11, 4, ADC_SampleTime_3Cycles);//ADC_SampleTime_3Cycles);
//  ADC_RegularChannelConfig(ADC3, ADC_Channel_11, 5, ADC_SampleTime_3Cycles);//ADC_SampleTime_3Cycles);
// 
//  
//  
//  ADC_EOCOnEachRegularChannelCmd(ADC3, ENABLE);
//  ADC_DiscModeCmd(ADC3, ENABLE);
//  
//  
//  /* Enable ADC3 */
//  ADC_Cmd(ADC3, ENABLE);  
//  
//  
//  ADC_DMARequestAfterLastTransferCmd(ADC3, ENABLE);
//   /* Enable ADC3 DMA */
//  ADC_DMACmd(ADC3, ENABLE);
//  
}


// ADC clock 21 MHz, 15 Clks needed for 1 conversion and 5 cycles delay between each conversion
// Therefore Maximum speed will be 1.05MSample/S
void ADC2_CH6_Config(void)
{
   
//  
//  ADC_InitTypeDef       ADC_InitStructure;
//  ADC_CommonInitTypeDef structADC_CommonInit;  
//  GPIO_InitTypeDef      GPIO_InitStructure;
//
//  /* Enable ADC3, DMA2 and GPIO clocks ****************************************/
//  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA2 | RCC_AHB1Periph_GPIOA | RCC_AHB1Periph_GPIOB, ENABLE);
//  RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC2, ENABLE);
//
//  /* Configure PA5,6, 7 as ADC2 Channel 5, 6  7 as analog input ******************************/
//  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7;
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AN;
//  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL ;
//  GPIO_Init(GPIOA, &GPIO_InitStructure);
//  
//  /* Configure PB0,1 as ADC2 Channel 8, 9 as analog input ******************************/
//  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1;
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AN;
//  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL ;
//  GPIO_Init(GPIOB, &GPIO_InitStructure);
//
//   //ADC Common Init *********************************************************
//  structADC_CommonInit.ADC_Mode = ADC_Mode_Independent;
//  structADC_CommonInit.ADC_Prescaler = ADC_Prescaler_Div4;//ADC_Prescaler_Div4;  // 21MHZ// Since the PCLK2 = SystemClock/2, the maximum of the ADC clock should be 30MHZ;
//  structADC_CommonInit.ADC_DMAAccessMode = ADC_DMAAccessMode_Disabled;
//  structADC_CommonInit.ADC_TwoSamplingDelay = ADC_TwoSamplingDelay_5Cycles;
//  ADC_CommonInit(&structADC_CommonInit);
//  
//  /* ADC32Init ****************************************************************/
//  ADC_InitStructure.ADC_Resolution = ADC_Resolution_12b;
//  ADC_InitStructure.ADC_ScanConvMode =  ENABLE;//DISABLE;
//  ADC_InitStructure.ADC_ContinuousConvMode = DISABLE;
//  ADC_InitStructure.ADC_ExternalTrigConvEdge = ADC_ExternalTrigConvEdge_Rising;
//  ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_T5_CC2;
//  ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
//  ADC_InitStructure.ADC_NbrOfConversion = 5;
//  ADC_Init(ADC2, &ADC_InitStructure);
//
//  /* ADC2 regular channel6 configuration *************************************/  
//  ADC_RegularChannelConfig(ADC2, ADC_Channel_5, 1, ADC_SampleTime_3Cycles);//ADC_SampleTime_3Cycles);
//  ADC_RegularChannelConfig(ADC2, ADC_Channel_6, 2, ADC_SampleTime_3Cycles);//ADC_SampleTime_3Cycles);
//  ADC_RegularChannelConfig(ADC2, ADC_Channel_7, 3, ADC_SampleTime_3Cycles);//ADC_SampleTime_3Cycles);
//  ADC_RegularChannelConfig(ADC2, ADC_Channel_8, 4, ADC_SampleTime_3Cycles);//ADC_SampleTime_3Cycles);
//  ADC_RegularChannelConfig(ADC2, ADC_Channel_9, 5, ADC_SampleTime_3Cycles);//ADC_SampleTime_3Cycles);
//
//
//  ADC_EOCOnEachRegularChannelCmd(ADC2, ENABLE);
//  ADC_DiscModeCmd(ADC2, ENABLE);
//  
//  /* Enable DMA request after last transfer (Single-ADC mode) */
//  ADC_DMARequestAfterLastTransferCmd(ADC2, ENABLE);
//
//  /* Enable ADC2 DMA */
//  ADC_DMACmd(ADC2, ENABLE);
//
//  /* Enable ADC2 */
//  ADC_Cmd(ADC2, ENABLE);  
//  
//  
  
}
void InitPortABCForLEDDisp(void)
{
   GPIO_InitTypeDef      GPIO_InitStructure;

 /* Enable GPIO clocks ****************************************/
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA | RCC_AHB1Periph_GPIOB | RCC_AHB1Periph_GPIOC | RCC_AHB1Periph_GPIOD | RCC_AHB1Periph_GPIOE, ENABLE);
    
  //GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_3 | GPIO_Pin_6 | GPIO_Pin_11;
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3 | GPIO_Pin_6;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
  
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5 ;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;//GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;//GPIO_OType_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  //GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//GPIO_PuPd_NOPULL;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//GPIO_PuPd_NOPULL;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
  
  
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;//GPIO_OType_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;  
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
  
  GPIOB->BSRRL = GPIO_Pin_7;
  GPIOB->BSRRL = GPIO_Pin_6;
  
  // PC0 to PC3 NC PC6-9 LCD Wr/Rd,CS, RS
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_6 | GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_13;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  GPIO_Init(GPIOC, &GPIO_InitStructure);
  
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;  // LCD reset
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  GPIO_Init(GPIOD, &GPIO_InitStructure);

  
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_All;  // LCD Data Port
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;//GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;//GPIO_OType_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;//GPIO_PuPd_NOPULL;
  GPIO_Init(GPIOE, &GPIO_InitStructure);
}

// ADC clock 21 MHz, 15 Clks needed for 1 conversion and 5 cycles delay between each conversion
// Therefore Maximum speed will be 1.05MSample/S
void ADC1_CH7_Config(void)
{
     
  ADC_InitTypeDef       ADC_InitStructure;
  ADC_CommonInitTypeDef structADC_CommonInit;  
  GPIO_InitTypeDef      GPIO_InitStructure;

  /* Enable ADC1, DMA2 and GPIO clocks ****************************************/
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA2|RCC_AHB1Periph_GPIOA, ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);
   
 
  
  /* Configure PA0 - 4 to ADC1 Channel0 - 4 as analog input ******************************/
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AN;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL ;
  GPIO_Init(GPIOA, &GPIO_InitStructure);

   //ADC Common Init *********************************************************
  structADC_CommonInit.ADC_Mode = ADC_Mode_Independent;
  structADC_CommonInit.ADC_Prescaler = ADC_Prescaler_Div4;//  // 21MHZ// Since the PCLK2 = SystemClock/2, the maximum of the ADC clock should be 30MHZ;
  structADC_CommonInit.ADC_DMAAccessMode = ADC_DMAAccessMode_Disabled;
  structADC_CommonInit.ADC_TwoSamplingDelay = ADC_TwoSamplingDelay_5Cycles;
  ADC_CommonInit(&structADC_CommonInit);
  
  /* ADC32Init ****************************************************************/
  ADC_InitStructure.ADC_Resolution = ADC_Resolution_12b;
  //ADC_InitStructure.ADC_ScanConvMode =  ENABLE;//DISABLE;
  ADC_InitStructure.ADC_ScanConvMode =  ENABLE;//DISABLE;
  ADC_InitStructure.ADC_ContinuousConvMode = DISABLE;
  ADC_InitStructure.ADC_ExternalTrigConvEdge = ADC_ExternalTrigConvEdge_Rising;//ADC_ExternalTrigConvEdge_Rising;
  ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_T5_CC3;
  ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
  ADC_InitStructure.ADC_NbrOfConversion = 8;
  ADC_Init(ADC1, &ADC_InitStructure);

  /* ADC1 regular channel7 configuration *************************************/
  ADC_RegularChannelConfig(ADC1, ADC_Channel_0, 1, ADC_SampleTime_3Cycles);//ADC_SampleTime_3Cycles);
  ADC_RegularChannelConfig(ADC1, ADC_Channel_1, 2, ADC_SampleTime_3Cycles);//ADC_SampleTime_3Cycles);
  ADC_RegularChannelConfig(ADC1, ADC_Channel_2, 3, ADC_SampleTime_3Cycles);//ADC_SampleTime_3Cycles);
  ADC_RegularChannelConfig(ADC1, ADC_Channel_3, 4, ADC_SampleTime_3Cycles);//ADC_SampleTime_3Cycles);
  ADC_RegularChannelConfig(ADC1, ADC_Channel_4, 5, ADC_SampleTime_3Cycles);//ADC_SampleTime_3Cycles);
  ADC_RegularChannelConfig(ADC1, ADC_Channel_5, 6, ADC_SampleTime_3Cycles);//ADC_SampleTime_3Cycles);
  ADC_RegularChannelConfig(ADC1, ADC_Channel_6, 7, ADC_SampleTime_3Cycles);//ADC_SampleTime_3Cycles);
  ADC_RegularChannelConfig(ADC1, ADC_Channel_7, 8, ADC_SampleTime_3Cycles);//ADC_SampleTime_3Cycles);
  
  
   //ADC1_DMA_Config(gusADC1DataBuf0);
   
  ADC_EOCOnEachRegularChannelCmd(ADC1, ENABLE);
  ADC_DiscModeCmd(ADC1, ENABLE);
  
  /* Enable DMA request after last transfer (Single-ADC mode) */
  ADC_DMARequestAfterLastTransferCmd(ADC1, ENABLE);

  /* Enable ADC1 DMA */
  ADC_DMACmd(ADC1, ENABLE);

  /* Enable ADC1 */
  ADC_Cmd(ADC1, ENABLE);  
  
  
  
}

//ADC1 use DMA2 channel 0 and stream 0
void ADC1_DMA_Config(unsigned short *ptrBufStartAddr)
{
  
  DMA_InitTypeDef  DMA_InitStructure;  
  // Enable ADC1, DMA2 and GPIO clocks ***************************************
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA2|RCC_AHB1Periph_GPIOA, ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);
  
  // DMA2 Stream0 channel0 configuration *************************************
  DMA_InitStructure.DMA_Channel = DMA_Channel_0;  
  DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)ADC1_DR_ADDRESS;
  DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)ptrBufStartAddr;
  DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory;
  DMA_InitStructure.DMA_BufferSize = 10;// gstructDataGrabberInit.usSamplePeriod/TIME_BASE * 10; //250;
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
  DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
  //DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
  DMA_InitStructure.DMA_Priority = DMA_Priority_Low;
  DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable;         
  DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_HalfFull;
  DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;
  DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;
  DMA_Init(DMA2_Stream0, &DMA_InitStructure);
  
  // Enable Double Buffer Mode 
  DMA2_Stream0->CR |= (uint32_t)DMA_SxCR_DBM;//0x40000;
  // Enable Set the buffer1 Address and by default Buf0 will be started first 
  DMA2_Stream0->M1AR = (uint32_t)gusADC1DataBuf1;
  
  DMA_Cmd(DMA2_Stream0, ENABLE); 
  
  DMA_Cmd(DMA2_Stream0, DISABLE);
  
  DMA2_Stream0->NDTR = DMA_InitStructure.DMA_BufferSize;
  while((DMA2_Stream0->CR & (uint32_t)DMA_SxCR_EN) != 0)
  {
     DMA2_Stream0->NDTR = DMA_InitStructure.DMA_BufferSize;
  }  

  DMA_Cmd(DMA2_Stream0, ENABLE);  

}



//ADC2 use DMA2 channel 1 and stream 3
void ADC2_DMA_Config(unsigned short *ptrBufStartAddr)
{
  
//  DMA_InitTypeDef  DMA_InitStructure;  
//  /* Enable ADC2, DMA2 and GPIO clocks ****************************************/
//  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA2|RCC_AHB1Periph_GPIOA, ENABLE);
//  RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC2, ENABLE);   
//  
//  
//  /* DMA2 Stream3 channel1 configuration **************************************/
//  DMA_InitStructure.DMA_Channel = DMA_Channel_1;  
//  DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)ADC2_DR_ADDRESS;
//  DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)ptrBufStartAddr;
//  DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory;  
//  DMA_InitStructure.DMA_BufferSize = gstructDataGrabberInit.usSamplePeriod/TIME_BASE * 10;//250;//
//  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
//  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
//  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
//  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
//  DMA_InitStructure.DMA_Mode = DMA_Mode_Circular; 
//  DMA_InitStructure.DMA_Priority = DMA_Priority_High;
//  DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable;         
//  DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_HalfFull;
//  DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;
//  DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;
//  DMA_Init(DMA2_Stream3, &DMA_InitStructure);
//  
//  /* Enable Double Buffer Mode */
//  DMA2_Stream3->CR |= (uint32_t)DMA_SxCR_DBM;//0x40000;
//  /* Enable Set the buffer1 Address and by default Buf0 will be started first */   
//  DMA2_Stream3->M1AR = (uint32_t)gusADC2DataBuf1;
//  
//  DMA_Cmd(DMA2_Stream3, ENABLE);
//  
//  DMA_Cmd(DMA2_Stream3, DISABLE);
//  
//  DMA2_Stream3->NDTR = DMA_InitStructure.DMA_BufferSize;
//  while((DMA2_Stream3->CR & (uint32_t)DMA_SxCR_EN) != 0)
//  {
//     DMA2_Stream3->NDTR = DMA_InitStructure.DMA_BufferSize;
//  }  
//
//  DMA_Cmd(DMA2_Stream3, ENABLE);  

}


//ADC3 use DMA2 channel 2 and stream 1
void ADC3_DMA_Config(unsigned short *ptrBufStartAddr)
{
  
//  DMA_InitTypeDef  DMA_InitStructure;  
//  /* Enable ADC2, DMA2 and GPIO clocks ****************************************/
//  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA2|RCC_AHB1Periph_GPIOA, ENABLE);
//  RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC3, ENABLE); 
//    
//  /* DMA2 Stream3 channel1 configuration **************************************/
//  DMA_InitStructure.DMA_Channel = DMA_Channel_2;  
//  DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)ADC3_DR_ADDRESS;
//  DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)ptrBufStartAddr;
//  DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory;  
//  DMA_InitStructure.DMA_BufferSize = gstructDataGrabberInit.usSamplePeriod/TIME_BASE * 10; //250;//
//  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
//  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
//  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
//  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
//  DMA_InitStructure.DMA_Mode = DMA_Mode_Circular; 
//  DMA_InitStructure.DMA_Priority = DMA_Priority_High;
//  DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable;         
//  DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_HalfFull;
//  DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;
//  DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;
//  DMA_Init(DMA2_Stream1, &DMA_InitStructure);
//  
//  /* Enable Double Buffer Mode */
//  DMA2_Stream1->CR |= (uint32_t)DMA_SxCR_DBM;//0x40000;
//  /* Enable Set the buffer1 Address and by default Buf0 will be started first */   
//  DMA2_Stream1->M1AR = (uint32_t)gusADC3DataBuf1;
//  
//  DMA_Cmd(DMA2_Stream1, ENABLE);
//  
//  DMA_Cmd(DMA2_Stream1, DISABLE);
//  
//  DMA2_Stream1->NDTR = DMA_InitStructure.DMA_BufferSize;
//  while((DMA2_Stream1->CR & (uint32_t)DMA_SxCR_EN) != 0)
//  {
//     DMA2_Stream1->NDTR = DMA_InitStructure.DMA_BufferSize;
//  }  
//
//  DMA_Cmd(DMA2_Stream1, ENABLE);  

}






#define NTaps 41
// used Global Varibles:
//      1: giProcessModeInSum 
//      2. giSingleProcessIndex
//      3. gusScanDataProcess[1000]

unsigned short gusScanRawData[1000];
extern int giTxCounter;
//int giNbrOfDataToTransfer;
u32 guSumBuffer[1000];


//typedef struct
//  {
//    uint16_t numTaps;     /**< number of filter coefficients in the filter. */
//    float32_t *pState;    /**< points to the state variable array. The array is of length numTaps+blockSize-1. */
//    float32_t *pCoeffs;   /**< points to the coefficient array. The array is of length numTaps. */
//  } arm_fir_instance_f32;

//arm_fir_instance_f32 gstructFIRInput;

//float gfScanRawData[1000 + NTaps];
//float gfScanDataProcessed[1000];
//float gfState[10 + NTaps];


//int giCurrentSrcHV;  
//extern unsigned short gusPosHV_DAC_Cnt;
//extern unsigned short gusNegHV_DAC_Cnt;   // S



extern u32 uiTempNum;
extern u32 uiTempFlag;
extern u32 uiTempNum1;

// 10 ms data from ADC, sampling time is 250 uS   

//extern int giHV_InNegMode,giHV_InPosMode;

void processData(void)
{

 
}



  


                         
const static int tbliResistance0_100[11]= {344100, 204800, 126000, 79510, 51450, 34080, 23060, 15860, 11100, 7900, 5698 };// Ohm at 0,10,20 to 100 deg C                                        
                                       
 // micruVolt from -50 Deg to +300 Deg 
const static int tblimicroVolt[36]= { -1889,  -1587, -1156, -778, -392, 0, // 0 Deg
                                       397, 798, 1203, 1612, 2023,
                                       2436, 2851, 3267, 3682, 4096,      // 100 Deg
                                       4509, 4920, 5328, 5735, 6138, 
                                       6540, 6941, 7340, 7739, 8138,      // 200 Deg
                                       8539, 8940, 9343, 9747, 10153, 
                                       10561,10971,11382, 11795, 12209 }; // 300 Deg
                                   
#define LOW_RANGE_AMP_OFFSET 0

//input giChannelDC[12];  which has full scale of 40 x 10 x 4095
// Output giEngineeringValve[12]; // in unit of 0.01
//int giEngineeringValue[12]; // in unit of 0.01
//int giUpdateStatusScreenReq;
void caculateToEngineeringUnit(void)
{

}

int calculateTCTemp(u32 iDataIn)
{ 
  
  int iTempPV_Hundred;

  return iTempPV_Hundred;
}



unsigned short calculateAPT(u32 uiAPTChannelDigitalCnt)   // Unit is in KPa x 10
{

  float mfTemp;
  unsigned short musTemp;
  // APT output Voltage; // Vout = Vs(P*0.004 -0.04)   // Vs = 5000mV P is in unit of Kpa
  mfTemp = uiAPTChannelDigitalCnt/400.0*3300/4095*5/3;    // Milli Volt from APT   
    
  musTemp = (unsigned short)(100*(mfTemp/5000 + 0.040)/0.004); 
  
  return musTemp;
}


//PIDTypeDef gstructIMS_PID;
//PIDTypeDef gstructInnetPID;
//PIDTypeDef gstructDopantPID;
//PIDTypeDef gstructCalibPID;

//void controlTemperature(void)
//{
//  unsigned int iTemp;
//  
//  gstructIMS_PID.fPV = giEngineeringValue[2]*0.01;
//  PID_Heating(&gstructIMS_PID);
//  //if(gstructIMS_PID.fPID_out > 75.00)
//   // gstructIMS_PID.fPID_out = 75.00;
//  iTemp = (int)(gstructIMS_PID.fPID_out*100);
//  
//  TIM_SetCompare3(TIM4,iTemp);
//  
//  
//  gstructInnetPID.fPV = giEngineeringValue[10]*0.01;
//  PID_Heating(&gstructInnetPID);
//  iTemp = (int)(gstructInnetPID.fPID_out*100);
//  TIM_SetCompare4(TIM4,iTemp);
//  
//  gstructDopantPID.fPV = giEngineeringValue[11]*0.01;
//  PID_Heating(&gstructDopantPID);
//  iTemp = (int)(gstructDopantPID.fPID_out*100);
//  TIM_SetCompare2(TIM4,iTemp);
//  
//  gstructCalibPID.fPV = giEngineeringValue[5]*0.01;
//  PID_Heating(&gstructCalibPID);
//  iTemp = (int)(gstructCalibPID.fPID_out*100);
//  TIM_SetCompare3(TIM3,iTemp);
//  
//}
//
//
//
//PIDTypeDef gstructSamplePumpPID;
//void controlExhaustVacuumPressure(void)
//{
//  unsigned int iTemp;
//  
//  gstructSamplePumpPID.fPV = giEngineeringValue[4]*0.01;
//  PID_Cooling(&gstructSamplePumpPID);
//  iTemp = (int)(gstructSamplePumpPID.fPID_out*100);
//  TIM_SetCompare1(TIM4,iTemp);
//}
//
//PIDTypeDef gtRechargePropValve_PID;
//// PV _ Output Flow 
//void controlOutFlow(void)
//{
//  unsigned int iTemp;
//  
//  gstructIMS_PID.fPV = giEngineeringValue[2]*0.01;
//  PID_Heating(&gstructIMS_PID);
//  //if(gstructIMS_PID.fPID_out > 75.00)
//   // gstructIMS_PID.fPID_out = 75.00;
//  iTemp = (int)(gstructIMS_PID.fPID_out*100);
//  
//  TIM_SetCompare3(TIM4,iTemp);
//  
//  
//  
//}
//


void InitPorts_Timers(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    
       
    ADC_CommonInitTypeDef ADC_CommonInitStructure;
    ADC_InitTypeDef ADC_InitStructure;

    TIM_Cmd(TIM5, DISABLE);      
    TIM_Cmd(TIM1, DISABLE);
    TIM_Cmd(TIM8, DISABLE); 
    TIM_Cmd(TIM2, DISABLE);
  
    TIM_ClearITPendingBit(TIM1, TIM_IT_Update);


  
    InitPortABCForLEDDisp();
    
    //PB0, PB1  TIM3 PWM3, PWM4
  
    // PB0, PB1 PB12 for Hardware Watchdog
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
  
    // PC0 to PC3 for Motor and PC4 for Enable  6-9
    //GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_6 | GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_13;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9; 
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_Init(GPIOC, &GPIO_InitStructure);
  
  
    //GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_4 | GPIO_Pin_12 | GPIO_Pin_13;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_4 | GPIO_Pin_12 | GPIO_Pin_14 | GPIO_Pin_15;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;//GPIO_Mode_Out_PP; 
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;   // this sets the pin type to push / pull (as opposed to open drain)
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;//GPIO_PuPd_UP; //GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_DOWN;   
    GPIO_Init(GPIOD, &GPIO_InitStructure);
  
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11 | GPIO_Pin_12;   // 10- Limit switch Loading position, 11 - Home Position
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;//GPIO_Mode_Out_PP; 
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;   // this sets the pin type to push / pull (as opposed to open drain)
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL; //GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_DOWN;   
    GPIO_Init(GPIOA, &GPIO_InitStructure);
  
    // For  LED PD2-/PD3
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2 | GPIO_Pin_3;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_Init(GPIOD, &GPIO_InitStructure);

    
//    // For HV Enable PA4
//    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;
//    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
//    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
//    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
//    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
//    GPIO_Init(GPIOA, &GPIO_InitStructure);
//    
    
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);
    
    
    // ADC Channel 0 -> PA0-7

    //GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AN;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL ;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4 | GPIO_Pin_5; 
    GPIO_Init(GPIOC, &GPIO_InitStructure);
    
 
    /* ADC Common Init */
    //ADC_CommonInitStructure.ADC_Mode = ADC_Mode_Independent;
    //ADC_CommonInitStructure.ADC_Prescaler = ADC_Prescaler_Div2;
    //ADC_CommonInitStructure.ADC_DMAAccessMode = ADC_DMAAccessMode_Disabled;
    //ADC_CommonInitStructure.ADC_TwoSamplingDelay = ADC_TwoSamplingDelay_5Cycles;
    //ADC_CommonInit(&ADC_CommonInitStructure);
    
    /* ADC Common configuration *************************************************/
    ADC_CommonInitStructure.ADC_Mode = ADC_Mode_Independent;
    ADC_CommonInitStructure.ADC_Prescaler =  ADC_Prescaler_Div4;//ADC_Prescaler_Div4;//  // 21MHZ// Since the PCLK2 = SystemClock/2, the maximum of the ADC clock should be 30MHZ;
    ADC_CommonInitStructure.ADC_DMAAccessMode = ADC_DMAAccessMode_1;//ADC_DMAAccessMode_Disabled;
    ADC_CommonInitStructure.ADC_TwoSamplingDelay = ADC_TwoSamplingDelay_5Cycles;
    ADC_CommonInit(&ADC_CommonInitStructure);
 //     structADC_CommonInit.ADC_Mode = ADC_Mode_Independent;
//  structADC_CommonInit.ADC_Prescaler = ADC_Prescaler_Div4;//  // 21MHZ// Since the PCLK2 = SystemClock/2, the maximum of the ADC clock should be 30MHZ;
//  structADC_CommonInit.ADC_DMAAccessMode = ADC_DMAAccessMode_Disabled;
//  structADC_CommonInit.ADC_TwoSamplingDelay = ADC_TwoSamplingDelay_5Cycles;
    
    ADC_InitStructure.ADC_Resolution = ADC_Resolution_12b;
    ADC_InitStructure.ADC_ScanConvMode = ENABLE;//DISABLE;
    ADC_InitStructure.ADC_ContinuousConvMode = DISABLE;
    ADC_InitStructure.ADC_ExternalTrigConv = 0x0;//ADC_ExternalTrigConv_T2_TRGO
    ADC_InitStructure.ADC_ExternalTrigConvEdge = ADC_ExternalTrigConvEdge_None;
    ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
    ADC_InitStructure.ADC_NbrOfConversion = 10;//8;
    ADC_Init(ADC1, &ADC_InitStructure);
    //ADC_InitStruct->ADC_DataAlign | \
    //                    ADC_InitStruct->ADC_ExternalTrigConv |
    /*
    ADC_InitStructure.ADC_Resolution = ADC_Resolution_12b;
    ADC_InitStructure.ADC_ScanConvMode = DISABLE; // 1 Channel
    ADC_InitStructure.ADC_ContinuousConvMode = DISABLE; // Conversions Triggered
    //ADC_InitStructure.ADC_ExternalTrigConvEdge = ADC_ExternalTrigConvEdge_Rising;
    //ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_T2_TRGO;
    ADC_InitStructure.ADC_ExternalTrigConvEdge = ADC_ExternalTrigConvEdge_None;
    ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
    ADC_InitStructure.ADC_NbrOfConversion = 1;
    ADC_Init(ADC1, &ADC_InitStructure);
    */
    /* ADC1 regular channel 11 configuration */
    //ADC_RegularChannelConfig(ADC1, ADC_Channel_0, 1, ADC_SampleTime_15Cycles); // PA0
    ADC_RegularChannelConfig(ADC1, ADC_Channel_0, 1, ADC_SampleTime_15Cycles); // PA0
    ADC_RegularChannelConfig(ADC1, ADC_Channel_1, 2, ADC_SampleTime_15Cycles); // PA0
    ADC_RegularChannelConfig(ADC1, ADC_Channel_2, 3, ADC_SampleTime_15Cycles); // PA0
    ADC_RegularChannelConfig(ADC1, ADC_Channel_3, 4, ADC_SampleTime_15Cycles); // PA0
    ADC_RegularChannelConfig(ADC1, ADC_Channel_4, 5, ADC_SampleTime_15Cycles); // PA0
    ADC_RegularChannelConfig(ADC1, ADC_Channel_5, 6, ADC_SampleTime_15Cycles); // PA0
    ADC_RegularChannelConfig(ADC1, ADC_Channel_6, 7, ADC_SampleTime_15Cycles); // PA0
    ADC_RegularChannelConfig(ADC1, ADC_Channel_7, 8, ADC_SampleTime_15Cycles); // PA0
    ADC_RegularChannelConfig(ADC1, ADC_Channel_14, 9, ADC_SampleTime_15Cycles); // PC4
    ADC_RegularChannelConfig(ADC1, ADC_Channel_15, 10, ADC_SampleTime_15Cycles); // PC5
    
    ADC1_DMA_Config(gusADC1DataBuf0);
    
    ADC_EOCOnEachRegularChannelCmd(ADC1, ENABLE);
    ADC_DiscModeCmd(ADC1, ENABLE);
  
    /* Enable DMA request after last transfer (Single-ADC mode) */
    ADC_DMARequestAfterLastTransferCmd(ADC1, ENABLE);

    /* Enable ADC1 DMA */
    ADC_DMACmd(ADC1, ENABLE);

    /* Enable ADC1 */
    ADC_Cmd(ADC1, ENABLE);  
    /* Enable ADC1 */
    //ADC_Cmd(ADC1, ENABLE);
    
    
    ADC_SoftwareStartConv(ADC1);
    /* Timing Configuration  -  Scan and ADC sample Timing*/
    Timing_Config();
  
}




 extern int  giTrendX_Start;
 extern int  giTrendY_LowValue,giTrendY_HighValue;





/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
