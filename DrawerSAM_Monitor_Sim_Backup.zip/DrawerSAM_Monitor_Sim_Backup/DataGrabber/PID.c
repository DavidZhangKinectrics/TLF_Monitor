
/* Includes ------------------------------------------------------------------*/

#include "PID.h"

void PID_Cooling(PIDTypeDef *structPID) 
{ 
     
      float fIntPortionTemp;
      float fErrorTemp;
      float fPIDOutTemp;
      
     
      
      if(structPID->fKp < 0)
      structPID->fKp = 0;
      
      if(structPID->fKp > 100.0)
        structPID->fKp = 100.0;

      
      if(structPID->fKi < 0)
        structPID->fKi = 0;
      
      if(structPID->fKi > 10.0)
        structPID->fKi = 10.0;
      
      if(structPID->fKd < 0)
        structPID->fKd = 0;
      
      if(structPID->fKd > 10.0)
        structPID->fKd = 10.0;
      
      
      fErrorTemp = structPID->fPV-structPID->fSP;
         
      fIntPortionTemp = structPID->fPID_Int + fErrorTemp * structPID->fKi;
       if(fIntPortionTemp > (structPID->fHighLimit))
        fIntPortionTemp = structPID->fHighLimit;
      if(fIntPortionTemp < structPID->fLowLimit)
        fIntPortionTemp = structPID->fLowLimit;  
      
      fPIDOutTemp = fErrorTemp*structPID->fKp + fIntPortionTemp + (fErrorTemp-structPID->fPID_Pre_Err)*structPID->fKd;
      
      if(fPIDOutTemp < structPID->fLowLimit)
        fPIDOutTemp = structPID->fLowLimit;
      if(fPIDOutTemp > structPID->fHighLimit)
        fPIDOutTemp = structPID->fHighLimit;
      
      structPID->fPID_Int = fIntPortionTemp;
      structPID->fPID_Pre_Err = fErrorTemp;
      structPID->fPID_out = fPIDOutTemp;
      
      if(structPID->fDeadBand > 0) // deadband is set
      {
        if(fErrorTemp > 0)
        {
          if(fErrorTemp > structPID->fDeadBand)  // still very hot
          {   
            structPID->fPID_Int = 0;          
            structPID->fPID_out = structPID->fLowLimit;
          }
        }
      
        if(fErrorTemp < 0)
        {
          if((fErrorTemp*(-1)) > structPID->fDeadBand)  // over cooled
          {   
            structPID->fPID_Int = 0;          
            structPID->fPID_out = structPID->fLowLimit;
          }
        }
      }
}


void PID_Heating(PIDTypeDef *structPID) 
{ 
     
      float fIntPortionTemp;
      float fErrorTemp;
      float fPIDOutTemp;
      
      if(structPID->fKp < 0)
      structPID->fKp = 0;
      
      if(structPID->fKp > 100.0)
        structPID->fKp = 100.0;

     
      
      if(structPID->fKi < 0)
        structPID->fKi = 0;
      
      if(structPID->fKi > 10.0)
        structPID->fKi = 10.0;
      
      if(structPID->fKd < 0)
        structPID->fKd = 0;
      
      if(structPID->fKd > 10.0)
        structPID->fKd = 10.0;
      
  
      fErrorTemp = (structPID->fSP-structPID->fPV);      
      
         
      fIntPortionTemp = structPID->fPID_Int + fErrorTemp * structPID->fKi;
       if(fIntPortionTemp > (structPID->fHighLimit))
        fIntPortionTemp = structPID->fHighLimit;
      if(fIntPortionTemp < structPID->fLowLimit)
        fIntPortionTemp = structPID->fLowLimit;        
      
      
      fPIDOutTemp = fErrorTemp*structPID->fKp + fIntPortionTemp + (fErrorTemp-structPID->fPID_Pre_Err)*structPID->fKd;
     
      if(fPIDOutTemp < structPID->fLowLimit)  
        fPIDOutTemp = structPID->fLowLimit;
      if(fPIDOutTemp > structPID->fHighLimit)
        fPIDOutTemp = structPID->fHighLimit;
      
      structPID->fPID_Int = fIntPortionTemp;
      structPID->fPID_Pre_Err = fErrorTemp;
      structPID->fPID_out = fPIDOutTemp;
      
      if(structPID->fDeadBand > 0) // deadband is set
      {
        if(fErrorTemp > 0)
        {
          if(fErrorTemp > structPID->fDeadBand)  // still very cold
          {   
            structPID->fPID_Int = 0;          
            structPID->fPID_out = structPID->fHighLimit;
          }
        }
      
        if(fErrorTemp < 0)
        {
          if((fErrorTemp*(-1)) > structPID->fDeadBand)  // over heated
          {   
            structPID->fPID_Int = 0;          
            structPID->fPID_out = structPID->fLowLimit;
          }
        }
      }
      
}





/**********END OF FILE****/
